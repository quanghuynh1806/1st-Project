clc
clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
h = 0.1;
nDproblem = 'plane stress';
switch nDproblem
    case 'plane stress'
        gamma = 2*mu/(lamda + 2*mu);
    case 'plane strain'
        gamma = 1; 
end

hold on
%Node
% coords = [0 0; %1
%           4 1; %2
%           4 2; %3
%           0 2; %4
%           2 0.5; %5
%           4 1.5; %6
%           2 2; %7
%           0 1; %8
%           2 1.25; %9
%           ];
coords = [0 0; %1
          4 1; %2
          4 2; %3
          0 2]; %4
[numNodes,m] = size(coords);
for nodID=1:numNodes
    plot(coords(nodID,1),coords(nodID,2),'bo','MarkerSize', 10);
    text(coords(nodID,1),coords(nodID,2),sprintf('%d',nodID));
end
%Element
% ele = [1 5 9 8;
%        5 2 6 9;
%        9 6 3 7;
%        8 9 7 4];
ele = [1 2 3 4];
[numEle,m] = size(ele);

%Plot elements
for eleId = 1:numEle
xCoordsPlot = [coords(ele(eleId,1),1); coords(ele(eleId,2),1);coords(ele(eleId,3),1);coords(ele(eleId,4),1);coords(ele(eleId,1),1)];
hold on
yCoordsPlot = [coords(ele(eleId,1),2); coords(ele(eleId,2),2);coords(ele(eleId,3),2);coords(ele(eleId,4),2);coords(ele(eleId,1),2)];
plotUndeformed = plot(xCoordsPlot,yCoordsPlot,'b','LineWidth',2);
end

%Gauss Quadrature Line
GaussBilinearLine = [-0.57735 1;0.57735 1];
[nGaBiliLine, m] = size(GaussBilinearLine);

%Gauss Quadrature
GaussBilinear = [-0.57735 -0.57735 1;-0.57735 0.57735 1;0.57735 -0.57735 1;0.57735 0.57735 1];
[nGaBili, m]=size(GaussBilinear);

%Initialize the complete external load vector
Re = zeros(numNodes*2,1);

%% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);

%% External Line distributed load
qn = 100;
qt = 100;

%Nodes order must be counter-clockwise
% nodesOnLineLoad = [2 6;
%                    6 3]; 
nodesOnLineLoad = [2 3];
[numSides,m] = size(nodesOnLineLoad);

for side = 1:numSides
    
    dofsOnLineLoad = [nodesOnLineLoad(side,1)*2-1 nodesOnLineLoad(side,1)*2 nodesOnLineLoad(side,2)*2-1 nodesOnLineLoad(side,2)*2];
    rq_dofsOnLineLoad = zeros(4,1);

    for i = 1:nGaBiliLine
        a = GaussBilinearLine(i,1);
        wa = GaussBilinearLine(i,2);
        Nline = 0.5*[1-a 1+a];
        nod1 = nodesOnLineLoad(side,1);
        nod2 = nodesOnLineLoad(side,2);
        xline = Nline*[coords(nod1,1), coords(nod2,1)]';
        yline = Nline*[coords(nod1,2), coords(nod2,2)]';
        dxline = 0.5*(-coords(nod1,1)+coords(nod2,1));
        dyline = 0.5*(-coords(nod1,2)+coords(nod2,2));
        Jc = (dxline^2 + dyline^2)^(1/2);
        nx = dyline/Jc;
        ny = -dxline/Jc;
        qx = nx*qn - ny*qt;
        qy = ny*qn + nx*qt;
        Npt = [Nline(1) 0 Nline(2) 0;0 Nline(1) 0 Nline(2)]';
        rq_dofsOnLineLoad = rq_dofsOnLineLoad + wa*h*Jc*Npt*[qx qy]';
    
    end
    %% Complete external load vector
    Re(dofsOnLineLoad) = Re(dofsOnLineLoad)+rq_dofsOnLineLoad;
end
%
N1=zeros(nGaBili,1);
N2=zeros(nGaBili,1);
N3=zeros(nGaBili,1);
N4=zeros(nGaBili,1);

dN1s=zeros(nGaBili,1);
dN2s=zeros(nGaBili,1);
dN3s=zeros(nGaBili,1);
dN4s=zeros(nGaBili,1);

dN1t=zeros(nGaBili,1);
dN2t=zeros(nGaBili,1);
dN3t=zeros(nGaBili,1);
dN4t=zeros(nGaBili,1);


%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaBili
    
    % Shape functions evaluated at Gauss point
    N1(i) = 0.25*(GaussBilinear(i,1)-1)*(GaussBilinear(i,2)-1);
    N2(i) = -0.25*(GaussBilinear(i,1)+1)*(GaussBilinear(i,2)-1);
    N3(i) = 0.25*(GaussBilinear(i,1)+1)*(GaussBilinear(i,2)+1);
    N4(i) = -0.25*(GaussBilinear(i,1)-1)*(GaussBilinear(i,2)+1);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1s(i) = 0.25*(GaussBilinear(i,2)-1);
    dN2s(i) = -0.25*(GaussBilinear(i,2)-1);
    dN3s(i) = 0.25*(GaussBilinear(i,2)+1);
    dN4s(i) = -0.25*(GaussBilinear(i,2)+1);
    %
    dN1t(i) = 0.25*(GaussBilinear(i,1)-1);
    dN2t(i) = -0.25*(GaussBilinear(i,1)+1);
    dN3t(i) = 0.25*(GaussBilinear(i,1)+1);
    dN4t(i) = -0.25*(GaussBilinear(i,1)-1);
    
end

%% Load increments for Newton Raphson solution
numLoadIncr = 1;
lamdaIncr = 1/numLoadIncr;

%% Initial guess for the first load step
coordsCur = coords;
for loadIncr = 1:numLoadIncr
    ReIncr = loadIncr*lamdaIncr*Re;
    %% Later on the the loop for Newton Raphson is added here
    conv = 1;
    numIter = 0;
    
    while conv > 0.005 &  numIter < 100

        numIter = numIter+1;
        %Initialization of the variables
        %displacement increment
        du = zeros(length(coords)*2,1);
        dcoords = reshape(du, [], numNodes)';
        %mapping from initial to master
        Jfem = zeros(2);
        %mapping from current to master
        JfemCur = zeros(2);
        %planar deformation gradient tensor
        Fp = zeros(2);
        %deformation gradient matrix in FEM style
        Fbar = zeros(3,4);
        %strain matrix
        BT = zeros(4,8);
        %current/material stiffness matrix
        kc = zeros(8);
        %stress/geometric stiffness matrix
        ks = zeros(8);
        %tangent stiffness matrix
        k = zeros(8);
        %internal force vector
        ri = zeros(8,1);
        %internal force vector for residual check
        riRes = zeros(8,1);
        %Initializa the structural matrix and vector
        Ri = zeros(numNodes*2,1);
        Kt = zeros(numNodes*2,numNodes*2);

        for eleID = 1:numEle
            for i = 1:nGaBili

                % Shape functions evaluated at Gauss point i
                N = [N1(i) N2(i) N3(i) N4(i)];

                % Partial derivatives of the shape functions evaluated at Gauss point
                dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i)];
                dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i)];

                % Initial Configuration's quantities evaluated at Gauss point
                % The FEM mapping
                Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1)]';
                Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2)]';

                x0 = N*Xcoords;
                y0 = N*Ycoords;

                Jfem11 = dNs*Xcoords;
                Jfem12 = dNt*Xcoords;
                Jfem21 = dNs*Ycoords;
                Jfem22 = dNt*Ycoords;

                Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];

                detJfem = det(Jfem);
                %Current Configuration's quantites evaluted at Gauss point
                %% For the first iteration, take the values of the initial config for the initial guess of the Current Configuration's quantites
                XcoordsCur = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1)]';
                YcoordsCur = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2)]';

                xCur = N*XcoordsCur;
                yCur = N*YcoordsCur;

                Jfem11Cur = dNs*XcoordsCur;
                Jfem12Cur = dNt*XcoordsCur;
                Jfem21Cur = dNs*YcoordsCur;
                Jfem22Cur = dNt*YcoordsCur;
                JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
                detJfemCur = det(JfemCur);

                %calculate Fp & Fbar
                Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
                Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
                Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
                Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
                Fp = [Fp11 Fp12;Fp21 Fp22];
                Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
                detFp = det(Fp);

                %calculate BT
                dN1x0y0 = [Jfem22*dN1s(i) - Jfem21*dN1t(i);-Jfem12*dN1s(i) + Jfem11*dN1t(i)];
                dN2x0y0 = [Jfem22*dN2s(i) - Jfem21*dN2t(i);-Jfem12*dN2s(i) + Jfem11*dN2t(i)];
                dN3x0y0 = [Jfem22*dN3s(i) - Jfem21*dN3t(i);-Jfem12*dN3s(i) + Jfem11*dN3t(i)];
                dN4x0y0 = [Jfem22*dN4s(i) - Jfem21*dN4t(i);-Jfem12*dN4s(i) + Jfem11*dN4t(i)];

                BT = (1/detJfem)*[dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1) 0;dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2) 0;0 dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1);0 dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2)];

                %right Cauchy-Green tensor
                c = Fp'*Fp;
                cInv = inv(c);

                %Planar 2nd PK stress tensor
                SHatp = lamda*(log(detFp^gamma))*cInv + mu*(eye(2) - cInv);
                %Planar 2nd PK stress vector
                switch nDproblem
                    case 'plane stress'
                        Szz = 0;
                    case 'plane strain'
                        Szz = lamda*(log(detFp)); 
                end
                S = [SHatp(1,1) SHatp(2,2) SHatp(1,2)]';
                %2nd PK stress matrix in FEM style
                Sbar = [SHatp zeros(2);zeros(2) SHatp];

                %Constitutive tensor
                C11 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,1)^2;
                C12 = (2*mu - 2*log(detFp^gamma)*lamda)*cInv(1,2)^2 + lamda*cInv(1,1)*cInv(2,2);
                C21 = C12;
                C22 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(2,2)^2;
                C13 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(1,1);
                C31 = C13;
                C23 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(2,2);
                C32 = C23;
                C33 = (-log(detFp^gamma)*lamda + lamda + mu)*cInv(1,2)^2 + (mu - log(detFp^gamma)*lamda)*cInv(1,1)*cInv(2,2);
                C = [C11 C12 C13; C21 C22 C23;C31 C32 C33];

                %Stiffness matrix and internal loadvector
                kc = kc + h*(BT')*(Fbar')*C*Fbar*BT*detJfem*GaussBilinear(i,3);
                ks = ks + h*(BT')*Sbar*BT*detJfem*GaussBilinear(i,3);
                ri = ri + -h*(BT')*(Fbar')*S*detJfem*GaussBilinear(i,3);
            end
            k = kc + ks
            ri
            % Add the elemental matrix & vector into the structural ones
            indx = [ele(eleID,1)*2-1 ele(eleID,1)*2 ele(eleID,2)*2-1 ele(eleID,2)*2 ele(eleID,3)*2-1 ele(eleID,3)*2 ele(eleID,4)*2-1 ele(eleID,4)*2];
            Kt(indx,indx) = Kt(indx,indx) + k;
            Ri(indx) = Ri(indx) + ri;
        end
%
    %% Boundary condition
    %Fix both vertical & horizontal displacements
%     DirNodes = [1 4 8];
    DirNodes = [1 4];
    DirDofs = zeros(1, length(DirNodes)*2);
    for i = 1:length(DirNodes)

        DirDofs(i*2-1) = DirNodes(i)*2-1;
        DirDofs(i*2) = DirNodes(i)*2;

    end

    %Apply BCs
    allDofs = [1:numNodes*2];
    NonDirDofs = setdiff(allDofs,DirDofs);
    
    %% Simplify tangent stiffness matrix after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        for j = i:length(NonDirDofs)

            KtNonDir(i,j) = Kt(NonDirDofs(i),NonDirDofs(j));
            KtNonDir(j,i) = Kt(NonDirDofs(i),NonDirDofs(j));

        end

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        RiNonDir(i) = Ri(NonDirDofs(i));    
        ReIncrNonDir(i) = ReIncr(NonDirDofs(i));
        
    end

    %% Solution
    duNonDir = KtNonDir\(ReIncrNonDir+RiNonDir)';
    
    %% Get back a complete vector du after the iteration
    for i = 1:length(NonDirDofs)

        du(NonDirDofs(i)) = duNonDir(i);

    end
    
    %% Update the current coordinates
    dcoords = reshape(du, [], numNodes)';
    coordsCur = coordsCur + dcoords
    
    RiRes = zeros(numNodes*2,1);
%% Check the residual after the completion of the latest iteration
    for eleID = 1:numEle
        for i = 1:nGaBili

            % Shape functions evaluated at Gauss point i
            N = [N1(i) N2(i) N3(i) N4(i)];
            w = GaussBilinear(i,3);
            % Partial derivatives of the shape functions evaluated at Gauss point
            dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i)];
            dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i)];
            % Partial derivatives of the shape functions evaluated at Gauss point
            Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1)]';
            Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2)]';

            Jfem11 = dNs*Xcoords;
            Jfem12 = dNt*Xcoords;
            Jfem21 = dNs*Ycoords;
            Jfem22 = dNt*Ycoords;

            Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];

            detJfem = det(Jfem);

            %% Update the position of the current configuration
            XcoordsCur = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1)]';
            YcoordsCur = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2)]';

            xCur = N*XcoordsCur;
            yCur = N*YcoordsCur;

            Jfem11Cur = dNs*XcoordsCur;
            Jfem12Cur = dNt*XcoordsCur;
            Jfem21Cur = dNs*YcoordsCur;
            Jfem22Cur = dNt*YcoordsCur;
            JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
            detJfemCur = det(JfemCur);

            %calculate Fp & Fbar
            Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
            Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
            Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
            Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
            Fp = [Fp11 Fp12;Fp21 Fp22];
            Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
            detFp = det(Fp);

            %current thickness
            hCur = h*detFp^(gamma-1);

            %left Cauchy Green tensor
            b = Fp*Fp';

            %plannar Cauchy stress tensor
            sigmaHatp = (lamda/detFp^gamma)*log(detFp^gamma)*eye(2)+ (mu/detFp^gamma)*(b-eye(2));
            %Planar Cauchy stress vector
            switch nDproblem
                case 'plane stress'
                    sigmazz = 0;
                case 'plane strain'
                    sigmazz = (lamda/detFp)*(log(detFp)); 
            end
            sigma = [sigmaHatp(1,1) sigmaHatp(2,2) sigmaHatp(1,2)]';

            %calculate BLT
            dN1xCuryCur = [Jfem22Cur*dN1s(i) - Jfem21Cur*dN1t(i);-Jfem12Cur*dN1s(i) + Jfem11Cur*dN1t(i)];
            dN2xCuryCur = [Jfem22Cur*dN2s(i) - Jfem21Cur*dN2t(i);-Jfem12Cur*dN2s(i) + Jfem11Cur*dN2t(i)];
            dN3xCuryCur = [Jfem22Cur*dN3s(i) - Jfem21Cur*dN3t(i);-Jfem12Cur*dN3s(i) + Jfem11Cur*dN3t(i)];
            dN4xCuryCur = [Jfem22Cur*dN4s(i) - Jfem21Cur*dN4t(i);-Jfem12Cur*dN4s(i) + Jfem11Cur*dN4t(i)];

            BLT = (1/detJfemCur)*[dN1xCuryCur(1) 0 dN2xCuryCur(1) 0 dN3xCuryCur(1) 0 dN4xCuryCur(1) 0;0 dN1xCuryCur(2) 0 dN2xCuryCur(2) 0 dN3xCuryCur(2) 0 dN4xCuryCur(2);dN1xCuryCur(2) dN1xCuryCur(1)  dN2xCuryCur(2) dN2xCuryCur(1)  dN3xCuryCur(2) dN3xCuryCur(1)  dN4xCuryCur(2) dN4xCuryCur(1)];

            riRes = riRes + (BLT')*sigma*detJfemCur*hCur*w;

        end
        %Add the elemental internal load vector to structural one
        indx = [ele(eleID,1)*2-1 ele(eleID,1)*2 ele(eleID,2)*2-1 ele(eleID,2)*2 ele(eleID,3)*2-1 ele(eleID,3)*2 ele(eleID,4)*2-1 ele(eleID,4)*2];
        RiRes(indx) = RiRes(indx) + riRes;
    end
    
    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        RiResNonDir(i) = RiRes(NonDirDofs(i));    

    end
    
    %% Calculation of the convergence parameter
    normRes = norm(RiResNonDir-ReIncrNonDir);
    conv = (normRes)/(1+norm(ReIncrNonDir));
end
end

%Plot elements and nodes
% xCoordsCurPlot = [coordsCur(1,1);coordsCur(5,1);coordsCur(2,1);coordsCur(6,1);coordsCur(3,1);coordsCur(7,1);coordsCur(4,1);coordsCur(8,1);coordsCur(1,1)];
% yCoordsCurPlot = [coordsCur(1,2);coordsCur(5,2);coordsCur(2,2);coordsCur(6,2);coordsCur(3,2);coordsCur(7,2);coordsCur(4,2);coordsCur(8,2);coordsCur(1,2)];
xCoordsCurPlot = [coordsCur(1:4,1);coordsCur(1,1)];
yCoordsCurPlot = [coordsCur(1:4,2);coordsCur(2,2)];
plotDeformedBili = plot(xCoordsCurPlot,yCoordsCurPlot,'--m','LineWidth',2);
hold on
for i=1:numNodes
    plot(coordsCur(i,1),coordsCur(i,2),'mo','MarkerSize', 10);
    text(coordsCur(i,1),coordsCur(i,2),sprintf('%d',i));
end
legend([plotUndeformed plotDeformedBili],'Undeformed','Deformed - Bilinear')
xlim auto
ylim auto

ReIncrNonDir
normRes
conv
