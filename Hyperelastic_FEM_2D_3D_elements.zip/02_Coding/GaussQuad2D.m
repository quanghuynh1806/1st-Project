function [N,dNs,dNt] = GaussQuad2D()

%% Gauss Quadrature 2D
GaussBiquadratic = [-0.774597 -0.774597 0.308642;-0.774597 0 0.493827;-0.774597 0.774597 0.308642; 0 -0.774597 0.493827; 0 0 0.790123; 0 0.774597 0.493827; 0.774597 -0.774597 0.308642; 0.774597 0 0.493827; 0.774597 0.774597 0.308642];
[nGaBiQuad, m]=size(GaussBiquadratic);

%% Initialization of shape functions and partial derivatives
N1=zeros(nGaBiQuad,1);
N2=zeros(nGaBiQuad,1);
N3=zeros(nGaBiQuad,1);
N4=zeros(nGaBiQuad,1);
N5=zeros(nGaBiQuad,1);
N6=zeros(nGaBiQuad,1);
N7=zeros(nGaBiQuad,1);
N8=zeros(nGaBiQuad,1);
N9=zeros(nGaBiQuad,1);
%
dN1s=zeros(nGaBiQuad,1);
dN2s=zeros(nGaBiQuad,1);
dN3s=zeros(nGaBiQuad,1);
dN4s=zeros(nGaBiQuad,1);
dN5s=zeros(nGaBiQuad,1);
dN6s=zeros(nGaBiQuad,1);
dN7s=zeros(nGaBiQuad,1);
dN8s=zeros(nGaBiQuad,1);
dN9s=zeros(nGaBiQuad,1);
%
dN1t=zeros(nGaBiQuad,1);
dN2t=zeros(nGaBiQuad,1);
dN3t=zeros(nGaBiQuad,1);
dN4t=zeros(nGaBiQuad,1);
dN5t=zeros(nGaBiQuad,1);
dN6t=zeros(nGaBiQuad,1);
dN7t=zeros(nGaBiQuad,1);
dN8t=zeros(nGaBiQuad,1);
dN9t=zeros(nGaBiQuad,1);

%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaBiQuad
    
    s = GaussBiquadratic(i,1);
    t = GaussBiquadratic(i,2);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.25*s*t*(s-1)*(t-1);
    N2(i) = 0.25*s*t*(s+1)*(t-1);
    N3(i) = 0.25*s*t*(s+1)*(t+1);
    N4(i) = 0.25*s*t*(s-1)*(t+1);
    N5(i) = 0.5*t*(1-s^2)*(t-1);
    N6(i) = 0.5*s*(1+s)*(1-t^2);
    N7(i) = 0.5*t*(1-s^2)*(t+1);
    N8(i) = 0.5*s*(s-1)*(1-t^2);  
    N9(i) = (1-s^2)*(1-t^2);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1s(i) = 0.25*(-1+2*s)*(-1+t)*t;
    dN2s(i) = 0.25*(1+2*s)*(-1+t)*t;
    dN3s(i) = 0.25*(1+2*s)*t*(1+t);
    dN4s(i) = 0.25*(-1+2*s)*t*(1+t);
    dN5s(i) = -s*(-1+t)*t;
    dN6s(i) = -(1/2)*(1+2*s)*(-1+t^2);
    dN7s(i) = -s*t*(1+t);
    dN8s(i) = -(1/2)*(-1+2*s)*(-1+t^2);
    dN9s(i) = 2*s*(-1+t^2);
    %
    dN1t(i) = 0.25*(-1+s)*s*(-1+2*t);
    dN2t(i) = 0.25*s*(1+s)*(-1+2*t);
    dN3t(i) = 0.25*s*(1+s)*(1+2*t);
    dN4t(i) = 0.25*(-1+s)*s*(1+2*t);
    dN5t(i) = -(1/2)*(-1+s^2)*(-1+2*t);
    dN6t(i) = -s*(1+s)*t;
    dN7t(i) = -(1/2)*(-1+s^2)*(1+2*t);
    dN8t(i) = -((-1+s)*s*t);
    dN9t(i) = 2*(-1+s^2)*t;
end

end