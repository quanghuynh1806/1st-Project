clc
clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
h = 0.1;
%
nDproblem = 'plane stress';
switch nDproblem
    case 'plane stress'
        gamma = 2*mu/(lamda + 2*mu);
    case 'plane strain'
        gamma = 1; 
end

%Node
coords = [0 0;4 1;4 2;0 2;2 0.5;4 1.5;2 2;0 1;2 1.25];
[numNodes,m] = size(coords);
%Element
ele = [1 2 3 4];
%Plot elements and nodes
xCoordsPlot = [coords(1:4,1);coords(1,1)];
yCoordsPlot = [coords(1:4,2);coords(1,2)];
plotUndeformed = plot(xCoordsPlot,yCoordsPlot,'b','LineWidth',2)
hold on
for i=1:numNodes
    plot(coords(i,1),coords(i,2),'bo','MarkerSize', 10);
    text(coords(i,1),coords(i,2),sprintf('%d',i));
end

%Gauss Quadrature Line
GaussBilinearLine = [-0.57735 1;0.57735 1];
[nGaBiliLine, m] = size(GaussBilinearLine);
%Gauss Quadrature 2D
GaussBiquadratic = [-0.774597 -0.774597 0.308642;-0.774597 0 0.493827;-0.774597 0.774597 0.308642; 0 -0.774597 0.493827; 0 0 0.790123; 0 0.774597 0.493827; 0.774597 -0.774597 0.308642; 0.774597 0 0.493827; 0.774597 0.774597 0.308642];
[nGaBiQuad, m]=size(GaussBiquadratic);

%Initialize the complete external load vector
re = zeros(18,1);
%% External concentrated (nodal) load vector
rC = zeros(9*2,1);
% factor = 1;
% Dir = 0;
% rC(2*2-Dir) = -0.75*factor;
% rC(6*2-Dir) = -1.5*factor;
% rC(3*2-Dir) = -0.75*factor;
%% External Line distributed load
qn = 0;
qt = 100;
nodesOnLineLoad = [2 3 6]; %Nodes order must be counter-clockwise but the mid-node must be at the end
dofsOnLineLoad = [nodesOnLineLoad(1)*2-1 nodesOnLineLoad(1)*2 nodesOnLineLoad(2)*2-1 nodesOnLineLoad(2)*2 nodesOnLineLoad(3)*2-1 nodesOnLineLoad(3)*2];
rq = zeros(6,1);
for i = 1:nGaBiliLine
    a = GaussBilinearLine(i,1);
    Nline = 0.5*[a*(a-1) a*(a+1) 2*(1-a^2)];
    nod1 = nodesOnLineLoad(1);
    nod2 = nodesOnLineLoad(2);
    nod3 = nodesOnLineLoad(3);
    xline = Nline*[coords(nod1,1) coords(nod2,1) coords(nod3,1)]';
    yline = Nline*[coords(nod1,2) coords(nod2,2) coords(nod3,2)]';

    dxline = 0.5*((2*a-1)*coords(nod1,1)+(2*a+1)*coords(nod2,1) - 4*a*coords(nod3,1));
    dyline = 0.5*((2*a-1)*coords(nod1,2)+(2*a+1)*coords(nod2,2) - 4*a*coords(nod3,2));
    Jc = (dxline^2 + dyline^2)^(1/2);
    nx = dyline/Jc;
    ny = -dxline/Jc;
    qx = nx*qn - ny*qt;
    qy = ny*qn + nx*qt;
    Npt = [Nline(1) 0 Nline(2) 0 Nline(3) 0;0 Nline(1) 0 Nline(2) 0 Nline(3)]';
    rq = rq + h*Jc*Npt*[qx qy]'; %This is still second order => 2 Gauss points are enough
    
end
rq;
%
%% Complete external load vector
re = re + rC;
re(dofsOnLineLoad) = re(dofsOnLineLoad)+rq;

%% Initialization of shape functions and partial derivatives
N1=zeros(nGaBiQuad,1);
N2=zeros(nGaBiQuad,1);
N3=zeros(nGaBiQuad,1);
N4=zeros(nGaBiQuad,1);
N5=zeros(nGaBiQuad,1);
N6=zeros(nGaBiQuad,1);
N7=zeros(nGaBiQuad,1);
N8=zeros(nGaBiQuad,1);
N9=zeros(nGaBiQuad,1);
%
dN1s=zeros(nGaBiQuad,1);
dN2s=zeros(nGaBiQuad,1);
dN3s=zeros(nGaBiQuad,1);
dN4s=zeros(nGaBiQuad,1);
dN5s=zeros(nGaBiQuad,1);
dN6s=zeros(nGaBiQuad,1);
dN7s=zeros(nGaBiQuad,1);
dN8s=zeros(nGaBiQuad,1);
dN9s=zeros(nGaBiQuad,1);
%
dN1t=zeros(nGaBiQuad,1);
dN2t=zeros(nGaBiQuad,1);
dN3t=zeros(nGaBiQuad,1);
dN4t=zeros(nGaBiQuad,1);
dN5t=zeros(nGaBiQuad,1);
dN6t=zeros(nGaBiQuad,1);
dN7t=zeros(nGaBiQuad,1);
dN8t=zeros(nGaBiQuad,1);
dN9t=zeros(nGaBiQuad,1);

%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaBiQuad
    
    s = GaussBiquadratic(i,1);
    t = GaussBiquadratic(i,2);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.25*s*t*(s-1)*(t-1);
    N2(i) = 0.25*s*t*(s+1)*(t-1);
    N3(i) = 0.25*s*t*(s+1)*(t+1);
    N4(i) = 0.25*s*t*(s-1)*(t+1);
    N5(i) = 0.5*t*(1-s^2)*(t-1);
    N6(i) = 0.5*s*(1+s)*(1-t^2);
    N7(i) = 0.5*t*(1-s^2)*(t+1);
    N8(i) = 0.5*s*(s-1)*(1-t^2);  
    N9(i) = (1-s^2)*(1-t^2);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1s(i) = 0.25*(-1+2*s)*(-1+t)*t;
    dN2s(i) = 0.25*(1+2*s)*(-1+t)*t;
    dN3s(i) = 0.25*(1+2*s)*t*(1+t);
    dN4s(i) = 0.25*(-1+2*s)*t*(1+t);
    dN5s(i) = -s*(-1+t)*t;
    dN6s(i) = -(1/2)*(1+2*s)*(-1+t^2);
    dN7s(i) = -s*t*(1+t);
    dN8s(i) = -(1/2)*(-1+2*s)*(-1+t^2);
    dN9s(i) = 2*s*(-1+t^2);
    %
    dN1t(i) = 0.25*(-1+s)*s*(-1+2*t);
    dN2t(i) = 0.25*s*(1+s)*(-1+2*t);
    dN3t(i) = 0.25*s*(1+s)*(1+2*t);
    dN4t(i) = 0.25*(-1+s)*s*(1+2*t);
    dN5t(i) = -(1/2)*(-1+s^2)*(-1+2*t);
    dN6t(i) = -s*(1+s)*t;
    dN7t(i) = -(1/2)*(-1+s^2)*(1+2*t);
    dN8t(i) = -((-1+s)*s*t);
    dN9t(i) = 2*(-1+s^2)*t;
end

%% Later on the loop for assembly of global stiffness matrix is added here

%% Load increments for Newton Raphson solution
numLoadIncr = 10;
lamdaIncr = 1/numLoadIncr;
coordsCur = coords; %initial guess for the first load step
for loadIncr = 1:numLoadIncr
reIncr = loadIncr*lamdaIncr*re;
%% Loop over gauss points, calculate and add up the matrices and solve the equation for displacement increment
%% Later on the the loop for Newton Raphson is added here
conv = 1;
n = 0;
maxIter = 20;
k=0;
while conv > 0.005 & n <= maxIter
    n=n+1;
    %Initialization of the variables
    %displacement increment
    du = zeros(length(coords)*2,1);
    dcoords = [du(1) du(2);du(3) du(4);du(5) du(6);du(7) du(8);du(9) du(10);du(11) du(12);du(13) du(14);du(15) du(16);du(17) du(18)];
    %mapping from initial to master
    Jfem = zeros(2);
    %mapping from current to master
    JfemCur = zeros(2);
    %planar deformation gradient tensor
    Fp = zeros(2);
    %deformation gradient matrix in FEM style
    Fbar = zeros(3,4);
    %strain matrix
    BT = zeros(4,18);
    %current/material stiffness matrix
    kc = zeros(18);
    %stress/geometric stiffness matrix
    ks = zeros(18);
    %tangent stiffness matrix
    k = zeros(18);
    %internal force vector
    ri = zeros(18,1);
    %internal force vector for residual check
    riRes = zeros(18,1);
    
    for i = 1:nGaBiQuad

        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i)];
        w = GaussBiquadratic(i,3);
        % Partial derivatives of the shape functions evaluated at Gauss point
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i)];

        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(1,1) coords(2,1) coords(3,1) coords(4,1) coords(5,1) coords(6,1) coords(7,1) coords(8,1) coords(9,1)]';
        Ycoords = [coords(1,2) coords(2,2) coords(3,2) coords(4,2) coords(5,2) coords(6,2) coords(7,2) coords(8,2) coords(9,2)]';
        
        x0 = N*Xcoords;
        y0 = N*Ycoords;

        Jfem11 = dNs*Xcoords;
        Jfem12 = dNt*Xcoords;
        Jfem21 = dNs*Ycoords;
        Jfem22 = dNt*Ycoords;
        Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];
        detJfem = det(Jfem);

        %Current Configuration's quantites evaluted at Gauss point
        %% For the first iteration, take the values of the initial config for the initial guess of the Current Configuration's quantites
        XcoordsCur = [coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1) coordsCur(5,1) coordsCur(6,1) coordsCur(7,1) coordsCur(8,1) coordsCur(9,1)]';
        YcoordsCur = [coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2) coordsCur(5,2) coordsCur(6,2) coordsCur(7,2) coordsCur(8,2) coordsCur(9,2)]';
        xCur = N*XcoordsCur;
        yCur = N*YcoordsCur;

        Jfem11Cur = dNs*XcoordsCur;
        Jfem12Cur = dNt*XcoordsCur;
        Jfem21Cur = dNs*YcoordsCur;
        Jfem22Cur = dNt*YcoordsCur;
        JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
        detJfemCur = det(JfemCur);

        %calculate Fp & Fbar
        Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
        Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
        Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
        Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
        Fp = [Fp11 Fp12;Fp21 Fp22];
        Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
        detFp = det(Fp);

        %calculate BT
        dN1x0y0 = [Jfem22*dN1s(i) - Jfem21*dN1t(i);-Jfem12*dN1s(i) + Jfem11*dN1t(i)];
        dN2x0y0 = [Jfem22*dN2s(i) - Jfem21*dN2t(i);-Jfem12*dN2s(i) + Jfem11*dN2t(i)];
        dN3x0y0 = [Jfem22*dN3s(i) - Jfem21*dN3t(i);-Jfem12*dN3s(i) + Jfem11*dN3t(i)];
        dN4x0y0 = [Jfem22*dN4s(i) - Jfem21*dN4t(i);-Jfem12*dN4s(i) + Jfem11*dN4t(i)];
        dN5x0y0 = [Jfem22*dN5s(i) - Jfem21*dN5t(i);-Jfem12*dN5s(i) + Jfem11*dN5t(i)];
        dN6x0y0 = [Jfem22*dN6s(i) - Jfem21*dN6t(i);-Jfem12*dN6s(i) + Jfem11*dN6t(i)];
        dN7x0y0 = [Jfem22*dN7s(i) - Jfem21*dN7t(i);-Jfem12*dN7s(i) + Jfem11*dN7t(i)];
        dN8x0y0 = [Jfem22*dN8s(i) - Jfem21*dN8t(i);-Jfem12*dN8s(i) + Jfem11*dN8t(i)];
        dN9x0y0 = [Jfem22*dN9s(i) - Jfem21*dN9t(i);-Jfem12*dN9s(i) + Jfem11*dN9t(i)];

        BT = (1/detJfem)*[dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1) 0 dN5x0y0(1) 0 dN6x0y0(1) 0 dN7x0y0(1) 0 dN8x0y0(1) 0 dN9x0y0(1) 0;
                          dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2) 0 dN5x0y0(2) 0 dN6x0y0(2) 0 dN7x0y0(2) 0 dN8x0y0(2) 0 dN9x0y0(2) 0;
                          0 dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1) 0 dN5x0y0(1) 0 dN6x0y0(1) 0 dN7x0y0(1) 0 dN8x0y0(1) 0 dN9x0y0(1);
                          0 dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2) 0 dN5x0y0(2) 0 dN6x0y0(2) 0 dN7x0y0(2) 0 dN8x0y0(2) 0 dN9x0y0(2)];

        %right Cauchy-Green tensor
        c = Fp'*Fp;
        cInv = inv(c);

        %Planar 2nd PK stress tensor
        SHatp = lamda*(log(detFp^gamma))*cInv + mu*(eye(2) - cInv);
        %Planar 2nd PK stress vector
        switch nDproblem
            case 'plane stress'
                Szz = 0;
            case 'plane strain'
                Szz = lamda*(log(detFp)); 
        end
        S = [SHatp(1,1) SHatp(2,2) SHatp(1,2)]';
        %2nd PK stress matrix in FEM style
        Sbar = [SHatp zeros(2);zeros(2) SHatp];

        %Constitutive tensor
        C11 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,1)^2;
        C12 = (2*mu - 2*log(detFp^gamma)*lamda)*cInv(1,2)^2 + lamda*cInv(1,1)*cInv(2,2);
        C21 = C12;
        C22 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(2,2)^2;
        C13 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(1,1);
        C31 = C13;
        C23 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(2,2);
        C32 = C23;
        C33 = (-log(detFp^gamma)*lamda + lamda + mu)*cInv(1,2)^2 + (mu - log(detFp^gamma)*lamda)*cInv(1,1)*cInv(2,2);
        C = [C11 C12 C13; C21 C22 C23;C31 C32 C33];

        %Stiffness matrix and internal loadvector
        kc = kc + h*(BT')*(Fbar')*C*Fbar*BT*detJfem*w;
        ks = ks + h*(BT')*Sbar*BT*detJfem*w;
        ri = ri + -h*(BT')*(Fbar')*S*detJfem*w;
     end
    k = kc + ks
    %
    %% Boundary condition
    %Fix both vertical & horizontal displacements
    DirNodes = [1 4 8];
    DirDofs = zeros(1, length(DirNodes)*2);
    for i = 1:length(DirNodes)

        DirDofs(i*2-1) = DirNodes(i)*2-1;
        DirDofs(i*2) = DirNodes(i)*2;

    end

    %Apply BCs
    allDofs = [1:length(coords)*2];
    NonDirDofs = setdiff(allDofs,DirDofs);
    %% Simplify tangent stiffness matrix after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        for j = i:length(NonDirDofs)

            kNonDir(i,j) = k(NonDirDofs(i),NonDirDofs(j));
            kNonDir(j,i) = k(NonDirDofs(i),NonDirDofs(j));

        end

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        riNonDir(i) = ri(NonDirDofs(i));    
        reIncrNonDir(i) = reIncr(NonDirDofs(i));

    end
    
    %% Solution
    duNonDir = kNonDir\(reIncrNonDir+riNonDir)';

    %% Get back a complete vector du after the iteration
    for i = 1:length(NonDirDofs)

        du(NonDirDofs(i)) = duNonDir(i);

    end

    dcoords = [du(1) du(2);du(3) du(4);du(5) du(6);du(7) du(8);du(9) du(10);du(11) du(12);du(13) du(14);du(15) du(16);du(17) du(18)];
    coordsCur = coordsCur + dcoords; 
    %% The current config coordsCur is updated for:
    % 1. Entering the residual procedure:
         %If unsatisfied 
            % => used for the next iteration with the same loadstep
         %Otherwise 
            % => used as the initial guess for the next loadstep
      
    %% Check the residual after the completion of the latest iteration
    for i = 1:nGaBiQuad
        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i)];
        w = GaussBiquadratic(i,3);
        % Partial derivatives of the shape functions evaluated at Gauss point
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i)];

        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(1,1) coords(2,1) coords(3,1) coords(4,1) coords(5,1) coords(6,1) coords(7,1) coords(8,1) coords(9,1)]';
        Ycoords = [coords(1,2) coords(2,2) coords(3,2) coords(4,2) coords(5,2) coords(6,2) coords(7,2) coords(8,2) coords(9,2)]';
        x0 = N*Xcoords;
        y0 = N*Ycoords;

        Jfem11 = dNs*Xcoords;
        Jfem12 = dNt*Xcoords;
        Jfem21 = dNs*Ycoords;
        Jfem22 = dNt*Ycoords;

        Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];

        detJfem = det(Jfem);

        %% Update the position of the current configuration
        XcoordsCur = [coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1) coordsCur(5,1) coordsCur(6,1) coordsCur(7,1) coordsCur(8,1) coordsCur(9,1)]';
        YcoordsCur = [coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2) coordsCur(5,2) coordsCur(6,2) coordsCur(7,2) coordsCur(8,2) coordsCur(9,2)]';
        xCur = N*XcoordsCur;
        yCur = N*YcoordsCur;

        Jfem11Cur = dNs*XcoordsCur;
        Jfem12Cur = dNt*XcoordsCur;
        Jfem21Cur = dNs*YcoordsCur;
        Jfem22Cur = dNt*YcoordsCur;
        JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
        detJfemCur = det(JfemCur);

        %calculate Fp & Fbar
        Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
        Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
        Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
        Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
        Fp = [Fp11 Fp12;Fp21 Fp22];
        Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
        detFp = det(Fp);

        %current thickness
        hCur = h*detFp^(gamma-1);

        %left Cauchy Green tensor
        b = Fp*Fp';

        %plannar Cauchy stress tensor
        sigmaHatp = (lamda/detFp^gamma)*log(detFp^gamma)*eye(2)+ (mu/detFp^gamma)*(b-eye(2));
        %Planar Cauchy stress vector
        switch nDproblem
            case 'plane stress'
                sigmazz = 0;
            case 'plane strain'
                sigmazz = (lamda/detFp)*(log(detFp)); 
        end
        sigma = [sigmaHatp(1,1) sigmaHatp(2,2) sigmaHatp(1,2)]';

        %calculate BLT
        dN1xCuryCur = [Jfem22Cur*dN1s(i) - Jfem21Cur*dN1t(i);-Jfem12Cur*dN1s(i) + Jfem11Cur*dN1t(i)];
        dN2xCuryCur = [Jfem22Cur*dN2s(i) - Jfem21Cur*dN2t(i);-Jfem12Cur*dN2s(i) + Jfem11Cur*dN2t(i)];
        dN3xCuryCur = [Jfem22Cur*dN3s(i) - Jfem21Cur*dN3t(i);-Jfem12Cur*dN3s(i) + Jfem11Cur*dN3t(i)];
        dN4xCuryCur = [Jfem22Cur*dN4s(i) - Jfem21Cur*dN4t(i);-Jfem12Cur*dN4s(i) + Jfem11Cur*dN4t(i)];
        dN5xCuryCur = [Jfem22Cur*dN5s(i) - Jfem21Cur*dN5t(i);-Jfem12Cur*dN5s(i) + Jfem11Cur*dN5t(i)];
        dN6xCuryCur = [Jfem22Cur*dN6s(i) - Jfem21Cur*dN6t(i);-Jfem12Cur*dN6s(i) + Jfem11Cur*dN6t(i)];
        dN7xCuryCur = [Jfem22Cur*dN7s(i) - Jfem21Cur*dN7t(i);-Jfem12Cur*dN7s(i) + Jfem11Cur*dN7t(i)];
        dN8xCuryCur = [Jfem22Cur*dN8s(i) - Jfem21Cur*dN8t(i);-Jfem12Cur*dN8s(i) + Jfem11Cur*dN8t(i)];   
        dN9xCuryCur = [Jfem22Cur*dN9s(i) - Jfem21Cur*dN9t(i);-Jfem12Cur*dN9s(i) + Jfem11Cur*dN9t(i)];

        BLT = (1/detJfemCur)*[dN1xCuryCur(1) 0 dN2xCuryCur(1) 0 dN3xCuryCur(1) 0 dN4xCuryCur(1) 0 dN5xCuryCur(1) 0 dN6xCuryCur(1) 0 dN7xCuryCur(1) 0 dN8xCuryCur(1) 0 dN9xCuryCur(1) 0;
                              0 dN1xCuryCur(2) 0 dN2xCuryCur(2) 0 dN3xCuryCur(2) 0 dN4xCuryCur(2) 0 dN5xCuryCur(2) 0 dN6xCuryCur(2) 0 dN7xCuryCur(2) 0 dN8xCuryCur(2) 0 dN9xCuryCur(2);
                              dN1xCuryCur(2) dN1xCuryCur(1)  dN2xCuryCur(2) dN2xCuryCur(1)  dN3xCuryCur(2) dN3xCuryCur(1)  dN4xCuryCur(2) dN4xCuryCur(1)  dN5xCuryCur(2) dN5xCuryCur(1)  dN6xCuryCur(2) dN6xCuryCur(1)  dN7xCuryCur(2) dN7xCuryCur(1)  dN8xCuryCur(2) dN8xCuryCur(1)  dN9xCuryCur(2) dN9xCuryCur(1)];

        riRes = riRes + (BLT')*sigma*detJfemCur*hCur*w;

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        riResNonDir(i) = riRes(NonDirDofs(i));    

    end
    normRes = norm(riResNonDir-reIncrNonDir);
    conv = (normRes)/(1+norm(reIncrNonDir));
end
%
end

conv
coordsCur-coords
coordsCur

%Plot elements and nodes
xCoordsCurPlot = [coordsCur(1,1);coordsCur(5,1);coordsCur(2,1);coordsCur(6,1);coordsCur(3,1);coordsCur(7,1);coordsCur(4,1);coordsCur(8,1);coordsCur(1,1)];
yCoordsCurPlot = [coordsCur(1,2);coordsCur(5,2);coordsCur(2,2);coordsCur(6,2);coordsCur(3,2);coordsCur(7,2);coordsCur(4,2);coordsCur(8,2);coordsCur(1,2)];
plotDeformedBiqua = plot(xCoordsCurPlot,yCoordsCurPlot,'--r','LineWidth',2)
legend([plotUndeformed plotDeformedBiqua],'Undeformed','Deformed - Biquadratic')
hold on
for i=1:numNodes
    plot(coordsCur(i,1),coordsCur(i,2),'ro','MarkerSize', 10);
    text(coordsCur(i,1),coordsCur(i,2),sprintf('%d',i));
end
xlim auto
ylim auto



