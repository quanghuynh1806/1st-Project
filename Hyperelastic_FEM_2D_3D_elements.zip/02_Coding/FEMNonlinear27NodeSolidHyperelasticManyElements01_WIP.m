clc
clear all
%% Material's properties
E = 1000;
nu = 0.25;
MAT = 'NeoHookean';
% MAT = 'StVenant';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Geometry & Mesh & Dirichlet and Neumann nodes
%Node
h = 0.2;
coords = [0 0 0; %1
          4 1 0; %2
          4 2 0; %3
          0 2 0; %4
          0 0 h; %5
          4 1 h; %6
          4 2 h; %7
          0 2 h; %8
          2 0.5 0; %9
          4 1.5 0; %10
          2 2 0;   %11
          0 1 0;   %12
          2 0.5 h; %13
          4 1.5 h; %14
          2 2 h;   %15
          0 1 h;   %16
          0 0 h/2; %17
          4 1 h/2; %18
          4 2 h/2; %19
          0 2 h/2; %20
          2 1.25 0; %21
          2 1.25 h; %22
          2 0.5 h/2; %23
          4 1.5 h/2; %24
          2 2 h/2; %25
          0 1 h/2; %26
          2 1.25 h/2 %27
          ];

[numNodes,m] = size(coords);
%Element
ele = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27];
[numEle,m] = size(ele);
%% External Line distributed load
nodesOnFaceLoad = [2,3,7,6,10,19,14,18,24]; %Nodes order must be counter-clockwise but the mid-node must be at the end
[numFaces,m] = size(nodesOnFaceLoad);
% Dirichlet
DirNodes = [1 4 8 5 12 20 16 17 26];
GeomMeshBcNodes = struct('coords',coords,'ele',ele,'nodesOnFaceLoad',nodesOnFaceLoad,'DirNodes',DirNodes,'numNodes',numNodes,'numEle',numEle);

%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
Re = zeros(numNodes*3,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*3,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
qx = 0;
qy = 100;
qz = 0;
% compute and then add the external distributed load vector into the
% external
Re = rqFaceLoad(Re,qx,qy,qz,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*3);
for i = 1:length(DirNodes)

    DirDofs(i*3-2) = DirNodes(i)*3-2;
    DirDofs(i*3-1) = DirNodes(i)*3-1;
    DirDofs(i*3) = DirNodes(i)*3;

end
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 10;
tol = 0.00001;
maxIter = 10;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement3D(matProps,GeomMeshBcNodes,Load_n_BCs,NewtonSolParam);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

% %% Overlay of the initial and final configuration
% figure('Name','Undeformed vs Deformed Configurations')
% subplot(2,2,1)

%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw3D(coords,ele,'bo','b')

%% Plot nodes and elements in the deformed state
% [plotLineDeformed, plotPointDeformed] = MeshDraw3D(coordsCur,ele,'go','--g')
