clc
clear all
%% Material's properties
Bulk = 120.291; % Bulk modulus
Shear = 80.194; % Shear modulus
nu = (3*Bulk-2*Shear)/(2*Shear + 6*Bulk);
E = 3*Bulk*(1-2*nu);
MAT = 'NeoHookean';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Analysis type
nDproblem = 'plane stress'; % or 'plane strain'
% Initial thickness
h = 1;
    % For the plane strain problem, h must be 1 - the representative thickness. 
    % In case of plane stress, h can be the real thickness
AnalysisType = struct('Problem',nDproblem,'Thickness',h);

%% Geometry & Mesh & Dirichlet and Neumann nodes
Vertices = [0 0;
           48 44;
           48 60;
           0 44];
numNodesSide = 21;
% Generation of the mesh from the Cook's membrane geometry and related quantites
GeomMeshBcNodes = CookMembraneMesh(Vertices,numNodesSide);
    % Left edge: nodes on Dirichlet BCs 
    % Right edge : nodes on the line of distributed load
    
%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
% Global external nodal load vector
Re = zeros(numNodes*2,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
qn = 0;
qt = 24;
% compute the nodal equivalent load vector and 
% add it into the global load vector
Re = rqLineLoad(Re,qn,qt,AnalysisType,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*2);
for i = 1:length(DirNodes)

    DirDofs(i*2-1) = DirNodes(i)*2-1;
    DirDofs(i*2) = DirNodes(i)*2;

end
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 30;
tol = 0.001;
maxIter = 15;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;
% Choosing the node to be compared in terms of force-displacement curve
node4plot = ele(numEle,3);
% Data of Cook's membrane from the paper 
% "An efficient reduced basis approach using enhanced meshfree and combined approximation for large deformation"
PaperDataReactionForce = [0	1.5234375	2.8515625	4.140625	5.3515625	6.484375	7.5390625	8.4765625	9.375	10.234375	11.015625	11.7578125	12.4609375	13.0859375	13.75	14.296875	14.84375	15.4296875	15.9375	16.40625	16.875	17.34375	17.7734375	18.203125	18.6328125	19.0234375	19.4140625	19.8046875	20.1953125	20.546875	20.8984375;
                          0.831600832	13.25493763	25.68477131	38.11590437	51.38123701	64.6491684	77.08809771	90.36252599	102.8066528	116.0836798	128.5317048	141.8126299	155.0948545	167.5480769	180.8316008	192.4558212	205.7432432	218.1977651	230.6548857	243.9449064	256.4033264	268.8617464	282.1530665	295.4443867	307.904106	321.1967256	333.6577443	346.118763	359.4113825	371.0420998	384.3360187];
%
ToComparison = struct('node4plot',node4plot,'PaperData',PaperDataReactionForce);

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement(matProps,GeomMeshBcNodes,AnalysisType,Load_n_BCs,NewtonSolParam,ToComparison);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')
subplot(2,2,1)

%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw(coords,ele,'bo','b')

%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')

%% Graph's properties
legend([plotLineUndeformed plotLineDeformed],'Undeformed','Deformed - Biquadratic')
xlim ([0.8*min([min(coords(:,1)) min(coordsCur(:,1))]) 1.2*max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([0.8*min([min(coords(:,2)) min(coordsCur(:,2))]) 1.2*max([max(coords(:,2)) max(coordsCur(:,2))])])

%% Plot the field of resultant displacement
subplot(2,2,2)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'resultant')

%% Plot the field of displacement u
subplot(2,2,3)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'x')

%% Plot the field of displacement v
subplot(2,2,4)
plotDisplacementV = drawDisplacement(coords, coordsCur, ele, 'y')

%%
figure('Name','Nodal stresses extrapolated from Gauss points')
[plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,E,nu,nDproblem,MAT)

numIntervals = numNodesSide-1;
disp(['The maximum vertical displacement is at the top right corner : v = ', num2str(coordsCur(ele(numIntervals*numIntervals,3),2) - coords(ele(numIntervals*numIntervals,3),2)),' mm']);

