%% Description: draw displacement fields of one component
%% Variable description
%% Input
    % coords: coordinates of nodes in the UNDEFORMED state
    % coordsCur: coordinates of nodes in the DEFORMED state
    % ele: a matrix with each row containing the ids of all nodes belonged
         % to the element. The row index is also the element id.
    % option: the displacement component (x/y/z) that its field being drawn
%% Output
    % plotDisplacement: a plot containing a colorized displacement field
function plot = drawDisplacement3D(coords, coordsCur, ele, option)
    
    dcoords = coordsCur - coords;
    XcoordsCur = coordsCur(:,1);
    YcoordsCur = coordsCur(:,2);
    ZcoordsCur = coordsCur(:,3);
    
    % X displacement of nodes
    if option == 'x'
        uAll = dcoords(:,1);
        Min = min(uAll);
        Max = max(uAll);
    
    % Y displacement of nodes
    elseif option == 'y'
        vAll = dcoords(:,2);
        Min = min(vAll);
        Max = max(vAll);
    % Z displacement of nodes
    elseif option == 'z'
        wAll = dcoords(:,3);    
        Min = min(wAll);
        Max = max(wAll);
    % Resultant displacement of nodes
    elseif option == 'resultant'
        uAll = dcoords(:,1);
        vAll = dcoords(:,2);
        wAll = dcoords(:,3);
        resAll = (uAll.^2 + vAll.^2 + wAll.^2).^(1/2)
        Min = min(resAll);
        Max = max(resAll);
    end
    
    [numEle,m] = size(ele);
    
    %% Filling color in the deformed configuration based on nodal displacement values
    hold on
    for eleID=1:numEle
        %
		XCoordsCurEleFace1 = [XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,9)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,10)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,11)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,12)) XcoordsCur(ele(eleID,1))];
        YCoordsCurEleFace1 = [YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,9)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,10)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,11)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,12)) YcoordsCur(ele(eleID,1))];
        ZCoordsCurEleFace1 = [ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,9)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,10)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,11)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,12)) ZcoordsCur(ele(eleID,1))];        
        %
        XCoordsCurEleFace2 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,13)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,14)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,15)) XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,16)) XcoordsCur(ele(eleID,5))];
        YCoordsCurEleFace2 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,13)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,14)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,15)) YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,16)) YcoordsCur(ele(eleID,5))];
        ZCoordsCurEleFace2 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,13)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,14)) ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,15)) ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,16)) ZcoordsCur(ele(eleID,5))];
        %
		XCoordsCurEleFace3 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,13)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,18)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,9)) XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,17)) XcoordsCur(ele(eleID,5))];
        YCoordsCurEleFace3 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,13)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,18)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,9)) YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,17)) YcoordsCur(ele(eleID,5))];
        ZCoordsCurEleFace3 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,13)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,18)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,9)) ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,17)) ZcoordsCur(ele(eleID,5))];
        %
		XCoordsCurEleFace4 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,16)) XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,20)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,12)) XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,17)) XcoordsCur(ele(eleID,5))];
        YCoordsCurEleFace4 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,16)) YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,20)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,12)) YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,17)) YcoordsCur(ele(eleID,5))];
        ZCoordsCurEleFace4 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,16)) ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,20)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,12)) ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,17)) ZcoordsCur(ele(eleID,5))];
        %
		XCoordsCurEleFace5 = [XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,15)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,19)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,11)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,20)) XcoordsCur(ele(eleID,8))];
        YCoordsCurEleFace5 = [YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,15)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,19)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,11)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,20)) YcoordsCur(ele(eleID,8))];
        ZCoordsCurEleFace5 = [ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,15)) ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,19)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,11)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,20)) ZcoordsCur(ele(eleID,8))];
        %
		XCoordsCurEleFace6 = [XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,14)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,18)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,10)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,19)) XcoordsCur(ele(eleID,7))];
        YCoordsCurEleFace6 = [YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,14)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,18)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,10)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,19)) YcoordsCur(ele(eleID,7))];
        ZCoordsCurEleFace6 = [ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,14)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,18)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,10)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,19)) ZcoordsCur(ele(eleID,7))];
        %
        if option == 'x'
            uEleFace1 = [uAll(ele(eleID,1)) uAll(ele(eleID,9)) uAll(ele(eleID,2)) uAll(ele(eleID,10)) uAll(ele(eleID,3)) uAll(ele(eleID,11)) uAll(ele(eleID,4)) uAll(ele(eleID,12)) uAll(ele(eleID,1))];
            plotDisplacementFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,uEleFace1);
            %
            uEleFace2 = [uAll(ele(eleID,5)) uAll(ele(eleID,13)) uAll(ele(eleID,6)) uAll(ele(eleID,14)) uAll(ele(eleID,7)) uAll(ele(eleID,15)) uAll(ele(eleID,8)) uAll(ele(eleID,16)) uAll(ele(eleID,5))];
            plotDisplacementFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,uEleFace2);
            %
            uEleFace3 = [uAll(ele(eleID,5)) uAll(ele(eleID,13)) uAll(ele(eleID,6)) uAll(ele(eleID,18)) uAll(ele(eleID,2)) uAll(ele(eleID,9)) uAll(ele(eleID,1)) uAll(ele(eleID,17)) uAll(ele(eleID,5))];
            plotDisplacementFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,uEleFace3);
            %
            uEleFace4 = [uAll(ele(eleID,5)) uAll(ele(eleID,16)) uAll(ele(eleID,8)) uAll(ele(eleID,20)) uAll(ele(eleID,4)) uAll(ele(eleID,12)) uAll(ele(eleID,1)) uAll(ele(eleID,17)) uAll(ele(eleID,5))];
            plotDisplacementFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,uEleFace4);
            %
            uEleFace5 = [uAll(ele(eleID,8)) uAll(ele(eleID,15)) uAll(ele(eleID,7)) uAll(ele(eleID,19)) uAll(ele(eleID,3)) uAll(ele(eleID,11)) uAll(ele(eleID,4)) uAll(ele(eleID,20)) uAll(ele(eleID,8))];
            plotDisplacementFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,uEleFace5);
            %
            uEleFace6 = [uAll(ele(eleID,7)) uAll(ele(eleID,14)) uAll(ele(eleID,6)) uAll(ele(eleID,18)) uAll(ele(eleID,2)) uAll(ele(eleID,10)) uAll(ele(eleID,3)) uAll(ele(eleID,19)) uAll(ele(eleID,7))];
            plotDisplacementFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,uEleFace6);
        elseif option == 'y'
            vEleFace1 = [vAll(ele(eleID,1)) vAll(ele(eleID,9)) vAll(ele(eleID,2)) vAll(ele(eleID,10)) vAll(ele(eleID,3)) vAll(ele(eleID,11)) vAll(ele(eleID,4)) vAll(ele(eleID,12)) vAll(ele(eleID,1))];
            plotDisplacementFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,vEleFace1);
            %
            vEleFace2 = [vAll(ele(eleID,5)) vAll(ele(eleID,13)) vAll(ele(eleID,6)) vAll(ele(eleID,14)) vAll(ele(eleID,7)) vAll(ele(eleID,15)) vAll(ele(eleID,8)) vAll(ele(eleID,16)) vAll(ele(eleID,5))];
            plotDisplacementFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,vEleFace2);
            %
            vEleFace3 = [vAll(ele(eleID,5)) vAll(ele(eleID,13)) vAll(ele(eleID,6)) vAll(ele(eleID,18)) vAll(ele(eleID,2)) vAll(ele(eleID,9)) vAll(ele(eleID,1)) vAll(ele(eleID,17)) vAll(ele(eleID,5))];
            plotDisplacementFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,vEleFace3);
            %
            vEleFace4 = [vAll(ele(eleID,5)) vAll(ele(eleID,16)) vAll(ele(eleID,8)) vAll(ele(eleID,20)) vAll(ele(eleID,4)) vAll(ele(eleID,12)) vAll(ele(eleID,1)) vAll(ele(eleID,17)) vAll(ele(eleID,5))];
            plotDisplacementFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,vEleFace4);
            %
            vEleFace5 = [vAll(ele(eleID,8)) vAll(ele(eleID,15)) vAll(ele(eleID,7)) vAll(ele(eleID,19)) vAll(ele(eleID,3)) vAll(ele(eleID,11)) vAll(ele(eleID,4)) vAll(ele(eleID,20)) vAll(ele(eleID,8))];
            plotDisplacementFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,vEleFace5);
            %
            vEleFace6 = [vAll(ele(eleID,7)) vAll(ele(eleID,14)) vAll(ele(eleID,6)) vAll(ele(eleID,18)) vAll(ele(eleID,2)) vAll(ele(eleID,10)) vAll(ele(eleID,3)) vAll(ele(eleID,19)) vAll(ele(eleID,7))];
            plotDisplacementFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,vEleFace6);
        elseif option == 'z'
            wEleFace1 = [wAll(ele(eleID,1)) wAll(ele(eleID,9)) wAll(ele(eleID,2)) wAll(ele(eleID,10)) wAll(ele(eleID,3)) wAll(ele(eleID,11)) wAll(ele(eleID,4)) wAll(ele(eleID,12)) wAll(ele(eleID,1))];
            plotDisplacementFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,wEleFace1);
            %
            wEleFace2 = [wAll(ele(eleID,5)) wAll(ele(eleID,13)) wAll(ele(eleID,6)) wAll(ele(eleID,14)) wAll(ele(eleID,7)) wAll(ele(eleID,15)) wAll(ele(eleID,8)) wAll(ele(eleID,16)) wAll(ele(eleID,5))];
            plotDisplacementFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,wEleFace2);
            %
            wEleFace3 = [wAll(ele(eleID,5)) wAll(ele(eleID,13)) wAll(ele(eleID,6)) wAll(ele(eleID,18)) wAll(ele(eleID,2)) wAll(ele(eleID,9)) wAll(ele(eleID,1)) wAll(ele(eleID,17)) wAll(ele(eleID,5))];
            plotDisplacementFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,wEleFace3);
            %
            wEleFace4 = [wAll(ele(eleID,5)) wAll(ele(eleID,16)) wAll(ele(eleID,8)) wAll(ele(eleID,20)) wAll(ele(eleID,4)) wAll(ele(eleID,12)) wAll(ele(eleID,1)) wAll(ele(eleID,17)) wAll(ele(eleID,5))];
            plotDisplacementFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,wEleFace4);
            %
            wEleFace5 = [wAll(ele(eleID,8)) wAll(ele(eleID,15)) wAll(ele(eleID,7)) wAll(ele(eleID,19)) wAll(ele(eleID,3)) wAll(ele(eleID,11)) wAll(ele(eleID,4)) wAll(ele(eleID,20)) wAll(ele(eleID,8))];
            plotDisplacementFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,wEleFace5);
            %
            wEleFace6 = [wAll(ele(eleID,7)) wAll(ele(eleID,14)) wAll(ele(eleID,6)) wAll(ele(eleID,18)) wAll(ele(eleID,2)) wAll(ele(eleID,10)) wAll(ele(eleID,3)) wAll(ele(eleID,19)) wAll(ele(eleID,7))];
            plotDisplacementFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,wEleFace6);
        elseif option == 'resultant'
            resEleFace1 = [resAll(ele(eleID,1)) resAll(ele(eleID,9)) resAll(ele(eleID,2)) resAll(ele(eleID,10)) resAll(ele(eleID,3)) resAll(ele(eleID,11)) resAll(ele(eleID,4)) resAll(ele(eleID,12)) resAll(ele(eleID,1))];
            plotDisplacementFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,resEleFace1);
            %
            resEleFace2 = [resAll(ele(eleID,5)) resAll(ele(eleID,13)) resAll(ele(eleID,6)) resAll(ele(eleID,14)) resAll(ele(eleID,7)) resAll(ele(eleID,15)) resAll(ele(eleID,8)) resAll(ele(eleID,16)) resAll(ele(eleID,5))];
            plotDisplacementFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,resEleFace2);
            %
            resEleFace3 = [resAll(ele(eleID,5)) resAll(ele(eleID,13)) resAll(ele(eleID,6)) resAll(ele(eleID,18)) resAll(ele(eleID,2)) resAll(ele(eleID,9)) resAll(ele(eleID,1)) resAll(ele(eleID,17)) resAll(ele(eleID,5))];
            plotDisplacementFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,resEleFace3);
            %
            resEleFace4 = [resAll(ele(eleID,5)) resAll(ele(eleID,16)) resAll(ele(eleID,8)) resAll(ele(eleID,20)) resAll(ele(eleID,4)) resAll(ele(eleID,12)) resAll(ele(eleID,1)) resAll(ele(eleID,17)) resAll(ele(eleID,5))];
            plotDisplacementFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,resEleFace4);
            %
            resEleFace5 = [resAll(ele(eleID,8)) resAll(ele(eleID,15)) resAll(ele(eleID,7)) resAll(ele(eleID,19)) resAll(ele(eleID,3)) resAll(ele(eleID,11)) resAll(ele(eleID,4)) resAll(ele(eleID,20)) resAll(ele(eleID,8))];
            plotDisplacementFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,resEleFace5);
            %
            resEleFace6 = [resAll(ele(eleID,7)) resAll(ele(eleID,14)) resAll(ele(eleID,6)) resAll(ele(eleID,18)) resAll(ele(eleID,2)) resAll(ele(eleID,10)) resAll(ele(eleID,3)) resAll(ele(eleID,19)) resAll(ele(eleID,7))];
            plotDisplacementFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,resEleFace6);
        end
        plot = [plotDisplacementFace1 plotDisplacementFace2 plotDisplacementFace3 plotDisplacementFace4 plotDisplacementFace5 plotDisplacementFace6];
        
    end
    title(sprintf('%s displacement',option));
    h  =colorbar;
    colormap jet
    h.Limits = [Min,Max];
    h.Label.String = sprintf('Min = %f, Max = %f',Min,Max);
    %% Plot nodes and elements in the deformed state
%     [plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')
%     xlim ([min([min(coords(:,1)) min(coordsCur(:,1))]) max([max(coords(:,1)) max(coordsCur(:,1))])])
%     ylim ([min([min(coords(:,2)) min(coordsCur(:,2))]) max([max(coords(:,2)) max(coordsCur(:,2))])])
end