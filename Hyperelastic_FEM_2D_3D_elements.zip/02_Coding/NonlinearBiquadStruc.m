%% Description: assembly of the structural tangent stiffness matrix, internal load vector and then apply the Dirichlet boundary conditions
%% Variable description
%% Input
        % coords: a matix with each row containing x & y coordinates of the
                % node in the undeformed state. The row index is also the node id
        % ReIncr: the external load vector at one specific increment
        % DirDofs: nodes on Dirichlet BC
        % ele: a matrix with each row containing the ids of all nodes belonged
                % to the element. The row index is also the element id.
        % coordsCur: a matix with each row containing x & y coordinates of the
                % node in the DEFORMED state. The row index is also the node id
        % nDproblem: specify 'plane stress' or 'plane strain'
%% Output
        % KtNonDir: the simplified stiffness matrix after applying
                % Dirichlet BC
        % RiNonDir: the simplified internal load vector after applying
                % Dirichlet BC
        % ReIncrNonDir :the simplified external load vector after applying
                % Dirichlet BC
        % Kt: the full global tangent stiffness matrix
        % Ri : the full global internal load vector

function [KtNonDir,RiNonDir,ReIncrNonDir,Kt,Ri] = NonlinearBiquadStruc(ReIncr,DirDofs,ele,coords,coordsCur,E,nu,nDproblem,h,MAT)

[numNodes,m] = size(coords);
[numEle,m] = size(ele);
allDofs = [1:numNodes*2];
NonDirDofs = setdiff(allDofs,DirDofs);

%% Assembly of the structural matrices and vector
%Initialize the structural matrix and vector
Ri = zeros(numNodes*2,1);
Kt = zeros(numNodes*2,numNodes*2);

for eleID = 1:numEle
    [kc,ks,ri,indx] = NonlinearBiquadEle(eleID,ele,coords,coordsCur,E,nu,nDproblem,h,MAT);
    % add elemental stiffness matrices into the global one
    Kt(indx,indx) = Kt(indx,indx) + kc + ks;
    Ri(indx) = Ri(indx) + ri;
end

%% Apply Dirichlet boudary condition to matrix and vector
[KtNonDir,RiNonDir,ReIncrNonDir] = ApplyDirichletBCs4Struc(DirDofs,NonDirDofs,Kt,Ri,ReIncr);

end