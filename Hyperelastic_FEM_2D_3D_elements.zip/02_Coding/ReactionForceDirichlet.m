function ReIncrDir = ReactionForceDirichlet(DirDofs,Kt,Ri,ReIncr,du)

%     ReIncrDir = zeros(length(ReIncr) - length(DirDofs),1);
    
    for i = 1:length(DirDofs)

        RiDir(i) = Ri(DirDofs(i));    

        for j = i:length(DirDofs)

            KtDir(i,j) = Kt(DirDofs(i),DirDofs(j));
            KtDir(j,i) = Kt(DirDofs(i),DirDofs(j));

        end

    end

    
    
end