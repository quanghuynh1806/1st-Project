clc
clear all
%% Material's properties
Bulk = 120.291;
Shear = 80.194;
nu = (3*Bulk-2*Shear)/(2*Shear + 6*Bulk);
E = 3*Bulk*(1-2*nu);
MAT = 'NeoHookean';
% MAT = 'StVenant';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Geometry & Mesh & Dirichlet and Neumann nodes
h = 1;
% R1 and R2 which define the geometry of the curve beam
R1 = 9;
R2 = 10;
% number of nodes on circumferencial and radial directions
numNodesCir = 5;
numNodesThic = 3;
GeomMeshBcNodes = CurveBeamMesh3D(R1,R2,h,numNodesCir,numNodesThic);
%
%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
Re = zeros(numNodes*3,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*3,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
qx = 0.5/sqrt(2);
qy = -0.5/sqrt(2);
qz = 0;
% compute and then add the external distributed load vector into the
% external
Re = rqFaceLoad(Re,qx,qy,qz,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*3);
for i = 1:length(DirNodes)

    DirDofs(i*3-2) = DirNodes(i)*3-2;
    DirDofs(i*3-1) = DirNodes(i)*3-1;
    DirDofs(i*3) = DirNodes(i)*3;

end
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 50;
tol = 0.00001;
maxIter = 10;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement3D(matProps,GeomMeshBcNodes,Load_n_BCs,NewtonSolParam);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

% %% Overlay of the initial and final configuration
% figure('Name','Undeformed vs Deformed Configurations')
% subplot(2,2,1)
figure()
%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw3D(coords,ele,'bo','b')

%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw3D(coordsCur,ele,'go','--g')
