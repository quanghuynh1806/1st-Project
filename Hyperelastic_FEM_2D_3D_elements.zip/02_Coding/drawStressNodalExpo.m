%% Description: draw stress fields
%% Variable description
%% Input
    % coords: coordinates of nodes in the UNDEFORMED state
    % coordsCur: coordinates of nodes in the DEFORMED state
    % ele: a matrix with each row containing the ids of all nodes belonged
         % to the element. The row index is also the element id.
%% Output
    % plotStressNodalExpoXX + YY + XY : plots contain Cauchy stress fields:
    % XX / YY / XY
function [plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,E,nu,nDproblem,MAT)
[lamda, mu, gamma] = elasticProps2D(E,nu,nDproblem);
[numEle,m] = size(ele);
%% X and Y coordinates of all nodes
XcoordsCur = coordsCur(:,1);
YcoordsCur = coordsCur(:,2);

%% Gauss Quadrature 2D
GaussBiquadratic = [-0.774597 -0.774597 0.308642;-0.774597 0 0.493827;-0.774597 0.774597 0.308642; 0 -0.774597 0.493827; 0 0 0.790123; 0 0.774597 0.493827; 0.774597 -0.774597 0.308642; 0.774597 0 0.493827; 0.774597 0.774597 0.308642];
[nGaBiQuad, m]=size(GaussBiquadratic);

%% Initialization of shape functions and partial derivatives
N1=zeros(nGaBiQuad,1);
N2=zeros(nGaBiQuad,1);
N3=zeros(nGaBiQuad,1);
N4=zeros(nGaBiQuad,1);
N5=zeros(nGaBiQuad,1);
N6=zeros(nGaBiQuad,1);
N7=zeros(nGaBiQuad,1);
N8=zeros(nGaBiQuad,1);
N9=zeros(nGaBiQuad,1);
%
dN1s=zeros(nGaBiQuad,1);
dN2s=zeros(nGaBiQuad,1);
dN3s=zeros(nGaBiQuad,1);
dN4s=zeros(nGaBiQuad,1);
dN5s=zeros(nGaBiQuad,1);
dN6s=zeros(nGaBiQuad,1);
dN7s=zeros(nGaBiQuad,1);
dN8s=zeros(nGaBiQuad,1);
dN9s=zeros(nGaBiQuad,1);
%
dN1t=zeros(nGaBiQuad,1);
dN2t=zeros(nGaBiQuad,1);
dN3t=zeros(nGaBiQuad,1);
dN4t=zeros(nGaBiQuad,1);
dN5t=zeros(nGaBiQuad,1);
dN6t=zeros(nGaBiQuad,1);
dN7t=zeros(nGaBiQuad,1);
dN8t=zeros(nGaBiQuad,1);
dN9t=zeros(nGaBiQuad,1);

%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaBiQuad
    
    s = GaussBiquadratic(i,1);
    t = GaussBiquadratic(i,2);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.25*s*t*(s-1)*(t-1);
    N2(i) = 0.25*s*t*(s+1)*(t-1);
    N3(i) = 0.25*s*t*(s+1)*(t+1);
    N4(i) = 0.25*s*t*(s-1)*(t+1);
    N5(i) = 0.5*t*(1-s^2)*(t-1);
    N6(i) = 0.5*s*(1+s)*(1-t^2);
    N7(i) = 0.5*t*(1-s^2)*(t+1);
    N8(i) = 0.5*s*(s-1)*(1-t^2);  
    N9(i) = (1-s^2)*(1-t^2);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1s(i) = 0.25*(-1+2*s)*(-1+t)*t;
    dN2s(i) = 0.25*(1+2*s)*(-1+t)*t;
    dN3s(i) = 0.25*(1+2*s)*t*(1+t);
    dN4s(i) = 0.25*(-1+2*s)*t*(1+t);
    dN5s(i) = -s*(-1+t)*t;
    dN6s(i) = -(1/2)*(1+2*s)*(-1+t^2);
    dN7s(i) = -s*t*(1+t);
    dN8s(i) = -(1/2)*(-1+2*s)*(-1+t^2);
    dN9s(i) = 2*s*(-1+t^2);
    %
    dN1t(i) = 0.25*(-1+s)*s*(-1+2*t);
    dN2t(i) = 0.25*s*(1+s)*(-1+2*t);
    dN3t(i) = 0.25*s*(1+s)*(1+2*t);
    dN4t(i) = 0.25*(-1+s)*s*(1+2*t);
    dN5t(i) = -(1/2)*(-1+s^2)*(-1+2*t);
    dN6t(i) = -s*(1+s)*t;
    dN7t(i) = -(1/2)*(-1+s^2)*(1+2*t);
    dN8t(i) = -((-1+s)*s*t);
    dN9t(i) = 2*(-1+s^2)*t;
end
%Initialization of the variables
%mapping from initial to master
Jfem = zeros(2);
%mapping from current to master
JfemCur = zeros(2);
%planar deformation gradient tensor
Fp = zeros(2);
%deformation gradient matrix in FEM style
Fbar = zeros(3,4);
%strain matrix
BT = zeros(4,18);
%internal force vector for residual check
riRes = zeros(18,1);
%stresses at Gauss points
sigmaEleGpt = zeros(9,3);
%% Preparation for the extrapolation of stresses from Gauss points to nodes
% Extrapolation functions associated with gauss points
Ngpt1=zeros(nGaBiQuad,1);
Ngpt2=zeros(nGaBiQuad,1);
Ngpt3=zeros(nGaBiQuad,1);
Ngpt4=zeros(nGaBiQuad,1);
Ngpt5=zeros(nGaBiQuad,1);
Ngpt6=zeros(nGaBiQuad,1);
Ngpt7=zeros(nGaBiQuad,1);
Ngpt8=zeros(nGaBiQuad,1);
Ngpt9=zeros(nGaBiQuad,1);
%
sGptMax = (1/0.774597);
tGptMax = (1/0.774597);
sigmaXXatNodes = zeros(9,1);
sigmaYYatNodes = zeros(9,1);
sigmaXYatNodes = zeros(9,1);
%% Natural coordinates of nodes in Gauss-element coordinate system
NodesByGpt = [-sGptMax -tGptMax;
               sGptMax -tGptMax;
               sGptMax  tGptMax;
              -sGptMax  tGptMax;
               0       -tGptMax;
               sGptMax  0;
               0        tGptMax;
              -sGptMax  0;
               0        0];
[nNodesByGpt,m] = size(NodesByGpt);

for i = 1:nNodesByGpt
    
    sGptNode = NodesByGpt(i,1);
    tGptNode = NodesByGpt(i,2);
    
    % Gauss-point-based extrapolation functions 
    % associated with Gauss points
    % evaluated at Nodes
    Ngpt1(i) = 0.25*sGptNode*tGptNode*(sGptNode-1)*(tGptNode-1);
    Ngpt2(i) = 0.5*sGptNode*(sGptNode-1)*(1-tGptNode^2);
    Ngpt3(i) = 0.25*sGptNode*tGptNode*(sGptNode-1)*(tGptNode+1);
    Ngpt4(i) = 0.5*tGptNode*(1-sGptNode^2)*(tGptNode-1);
    Ngpt5(i) = (1-sGptNode^2)*(1-tGptNode^2);
    Ngpt6(i) = 0.5*tGptNode*(1-sGptNode^2)*(tGptNode+1);
    Ngpt7(i) = 0.25*sGptNode*tGptNode*(sGptNode+1)*(tGptNode-1);
    Ngpt8(i) = 0.5*sGptNode*(1+sGptNode)*(1-tGptNode^2);  
    Ngpt9(i) = 0.25*sGptNode*tGptNode*(sGptNode+1)*(tGptNode+1);

end

for eleID = 1:numEle
    for i = 1:nGaBiQuad
        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i)];
        w = GaussBiquadratic(i,3);

        % Partial derivatives of the shape functions evaluated at Gauss point
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i)];

        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1) coords(ele(eleID,5),1) coords(ele(eleID,6),1) coords(ele(eleID,7),1) coords(ele(eleID,8),1) coords(ele(eleID,9),1)]';
        Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2) coords(ele(eleID,5),2) coords(ele(eleID,6),2) coords(ele(eleID,7),2) coords(ele(eleID,8),2) coords(ele(eleID,9),2)]';
        x0 = N*Xcoords;
        y0 = N*Ycoords;

        Jfem11 = dNs*Xcoords;
        Jfem12 = dNt*Xcoords;
        Jfem21 = dNs*Ycoords;
        Jfem22 = dNt*Ycoords;

        Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];

        detJfem = det(Jfem);

        %% Update the position of the current configuration
        XcoordsCurEle = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1) coordsCur(ele(eleID,5),1) coordsCur(ele(eleID,6),1) coordsCur(ele(eleID,7),1) coordsCur(ele(eleID,8),1) coordsCur(ele(eleID,9),1)]';
        YcoordsCurEle = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2) coordsCur(ele(eleID,5),2) coordsCur(ele(eleID,6),2) coordsCur(ele(eleID,7),2) coordsCur(ele(eleID,8),2) coordsCur(ele(eleID,9),2)]';
        xCur = N*XcoordsCurEle;
        yCur = N*YcoordsCurEle;

        Jfem11Cur = dNs*XcoordsCurEle;
        Jfem12Cur = dNt*XcoordsCurEle;
        Jfem21Cur = dNs*YcoordsCurEle;
        Jfem22Cur = dNt*YcoordsCurEle;
        JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
        detJfemCur = det(JfemCur);

        %calculate Fp & Fbar
        Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
        Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
        Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
        Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
        Fp = [Fp11 Fp12;Fp21 Fp22];
        Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
        detFp = det(Fp);

        %left Cauchy Green tensor
        b = Fp*Fp';
        if strcmp(MAT,'NeoHookean') == 1
        %% Hyperelastic
        % plannar Cauchy stress tensor for compressible Neohookean material
            sigmaHatp = (lamda/detFp^gamma)*log(detFp^gamma)*eye(2)+ (mu/detFp^gamma)*(b-eye(2));
        elseif strcmp(MAT,'StVenant') == 1
        %% St-Venant
            cp = Fp'*Fp;
            [S, SHatp, Sbar, C] = VenantKirchhoff(cp,E,nu);
            sigmaHatp = (1/detFp^gamma)*Fp*SHatp*Fp';
        end
        %Note: the stresses are evaluated at Gauss point i
        sigmaEleGpt(i,:) = [sigmaHatp(1,1) sigmaHatp(2,2) sigmaHatp(1,2)];

    end
    
    %Rearrange stress tensor at 9 Gauss points in vector form: sigmaXX, sigmaYY sigmaXY
    sigmaXXatGpt = sigmaEleGpt(:,1);
    sigmaYYatGpt = sigmaEleGpt(:,2);
    sigmaXYatGpt = sigmaEleGpt(:,3);
    plotStressNodalExpoXX=[];
    plotStressNodalExpoYY=[];
    plotStressNodalExpoXY=[];
    %% Calculation of stress at nodes, following the node-order
    for i = 1:nNodesByGpt

        Ngpt = [Ngpt1(i) Ngpt2(i) Ngpt3(i) Ngpt4(i) Ngpt5(i) Ngpt6(i) Ngpt7(i) Ngpt8(i) Ngpt9(i)];
        sigmaXXatNodes(i) = Ngpt*sigmaXXatGpt;
        sigmaYYatNodes(i) = Ngpt*sigmaYYatGpt;
        sigmaXYatNodes(i) = Ngpt*sigmaXYatGpt;

    end
    %Plot
    XCoordsCurElePlot = [XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,8))];
    YCoordsCurElePlot = [YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,8))];
    sigmaXXatNodesPlot = [sigmaXXatNodes(1) sigmaXXatNodes(5) sigmaXXatNodes(2) sigmaXXatNodes(6) sigmaXXatNodes(3) sigmaXXatNodes(7) sigmaXXatNodes(4) sigmaXXatNodes(8)];
    sigmaYYatNodesPlot = [sigmaYYatNodes(1) sigmaYYatNodes(5) sigmaYYatNodes(2) sigmaYYatNodes(6) sigmaYYatNodes(3) sigmaYYatNodes(7) sigmaYYatNodes(4) sigmaYYatNodes(8)];
    sigmaXYatNodesPlot = [sigmaXYatNodes(1) sigmaXYatNodes(5) sigmaXYatNodes(2) sigmaXYatNodes(6) sigmaXYatNodes(3) sigmaXYatNodes(7) sigmaXYatNodes(4) sigmaXYatNodes(8)];
    %
    
    subplot(1,3,1)
    hold on
    plotStressNodalExpoXX = fill(XCoordsCurElePlot,YCoordsCurElePlot,sigmaXXatNodesPlot);
    colorbar
    colormap jet
    
    subplot(1,3,2)
    hold on
    plotStressNodalExpoYY = fill(XCoordsCurElePlot,YCoordsCurElePlot,sigmaYYatNodesPlot);
    colorbar
    colormap jet
    
    subplot(1,3,3)
    hold on
    plotStressNodalExpoXY = fill(XCoordsCurElePlot,YCoordsCurElePlot,sigmaXYatNodesPlot);
    colorbar
    colormap jet
end
end