clc
clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
nDproblem = 'plane stress';
[lamda, mu, gamma] = elasticProps2D(E,nu,nDproblem);
hold on
%% Node
coords = [0 0; %1
          4 1; %2
          4 2; %3
          0 2; %4
          2 0.5; %5
          4 1.5; %6
          2 2; %7
          0 1; %8
          2 1.25; %9
          1 0.25; %10
          3 0.75; %11
          4 1.25; %12
          4 1.75; %13
          3 2; %14
          1 2; %15
          0 1.5; %16
          0 0.5; %17
          2 0.875; %18
          2 1.625; %19
          1 1.125; %20
          3 1.375; %21
          1 0.6875; %22
          1 1.5625; %23
          3 1.0625; %24
          3 1.6875; %25
          ];
[numNodes,m] = size(coords);
%% Element
ele = [1 5 9 8 10 18 20 17 22;
       5 2 6 9 11 12 21 18 24;
       9 6 3 7 21 13 14 19 25;
       8 9 7 4 20 19 15 16 23];
[numEle,m] = size(ele);
%% Initial thickness
h = 0.1;
%% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);
%
%% Initializa the structural matrix and vector
Re = zeros(numNodes*2,1);
Re = Re + RC;
%% External Line distributed load - independent of displacements
qn = 400;
qt = 0;
%Nodes order must be counter-clockwise but the mid-node must be at the end
nodesOnLineLoad = [2 6 12; % Edge 1
                    6 3 13];% Edge 2 
%        
Re = rqLineLoad(Re,qn,qt,h,nodesOnLineLoad,coords);
%% Dirichlet nodes and corresponding Dofs
DirNodes = [1 17 8 16 4];
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirDofs = zeros(1, length(DirNodes)*2);
for i = 1:length(DirNodes)

    DirDofs(i*2-1) = DirNodes(i)*2-1;
    DirDofs(i*2) = DirNodes(i)*2;

end

%% Load increments for Newton Raphson solution
numLoadIncr = 100;
tol = 0.0000005;
maxIter = 1000;
[conv,coordsCur] = NewtonLoadIncrement(Re,numLoadIncr,DirDofs,coords,ele,tol,maxIter,lamda,gamma,mu,h)

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')
subplot(2,2,1)
%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw(coords,ele,'bo','b')
%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')
%% Graph's properties
legend([plotLineUndeformed plotLineDeformed],'Undeformed','Deformed - Biquadratic')
xlim ([0.8*min([min(coords(:,1)) min(coordsCur(:,1))]) 1.2*max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([0.8*min([min(coords(:,2)) min(coordsCur(:,2))]) 1.2*max([max(coords(:,2)) max(coordsCur(:,2))])])
%% Plot the field of displacement u
subplot(2,2,3)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'x')

%% Plot the field of displacement v
subplot(2,2,4)
plotDisplacementV = drawDisplacement(coords, coordsCur, ele, 'y')

%%
figure('Name','Nodal stresses extrapolated from Gauss points')
[plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,lamda,gamma,mu)

%%
figure('Name','Nodal stresses directly computed from displacement field')
[plotStressNodesCalXX,plotStressNodesCalYY,plotStressNodesCalXY] = drawStressNodalCal(coords, coordsCur, ele,lamda,gamma,mu)