%% Description: calculation of the constitutive tensor for the compressible NeoHookean material
% cInv: the inverse of the right Cauchy-Green strain tensor
% detFp: determinant of the planar deformation gradient matrix
function [S, Sbar, C] = NeoHookeanCompressibleMatertial(detFp, cp, lamda,gamma,mu)
    cpInv = inv(cp);
    % 2nd Piola Kirchhoff stress tensor
    SHatp = lamda*(log(detFp^gamma))*cpInv + mu*(eye(2) - cpInv);
    % Voight's notation vector
    S = [SHatp(1,1) SHatp(2,2) SHatp(1,2)]';
    % FEM notation matrix
    Sbar = [SHatp zeros(2);zeros(2) SHatp];
    
    % Constitutive tensor's components
    C11 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cpInv(1,1)^2;
    C12 = (2*mu - 2*log(detFp^gamma)*lamda)*cpInv(1,2)^2 + lamda*cpInv(1,1)*cpInv(2,2);
    C21 = C12;
    C22 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cpInv(2,2)^2;
    C13 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cpInv(1,2)*cpInv(1,1);
    C31 = C13;
    C23 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cpInv(1,2)*cpInv(2,2);
    C32 = C23;
    C33 = (-log(detFp^gamma)*lamda + lamda + mu)*cpInv(1,2)^2 + (mu - log(detFp^gamma)*lamda)*cpInv(1,1)*cpInv(2,2);
    C = [C11 C12 C13; C21 C22 C23;C31 C32 C33];

end