%% Description: draw displacement fields of one component
%% Variable description
%% Input
    % coords: coordinates of nodes in the UNDEFORMED state
    % coordsCur: coordinates of nodes in the DEFORMED state
    % ele: a matrix with each row containing the ids of all nodes belonged
         % to the element. The row index is also the element id.
    % option: the displacement component (x/y) that its field being drawn
%% Output
    % plotDisplacement: a plot containing a colorized displacement field
function plotDisplacement = drawDisplacement(coords, coordsCur, ele, option)
    
    dcoords = coordsCur - coords;
    XcoordsCur = coordsCur(:,1);
    YcoordsCur = coordsCur(:,2);
    
    % Horizontal displacement of nodes
    if option == 'x'
        uAll = dcoords(:,1);
    
    % Vertical displacement of nodes
    elseif option == 'y'
        vAll = dcoords(:,2);
    
    % Resultant displacement of nodes
    elseif option == 'resultant'
        uAll = dcoords(:,1);
        vAll = dcoords(:,2);
        resAll = (uAll.^2 + vAll.^2).^(1/2)
    end
    
    [numEle,m] = size(ele);
    
    %% Filling color in the deformed configuration based on nodal displacement values
    hold on
    for eleID=1:numEle

        XCoordsCurEle = [XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,8))];
        YCoordsCurEle = [YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,8))];
        if option == 'x'
            uEle = [uAll(ele(eleID,1)) uAll(ele(eleID,5)) uAll(ele(eleID,2)) uAll(ele(eleID,6)) uAll(ele(eleID,3)) uAll(ele(eleID,7)) uAll(ele(eleID,4)) uAll(ele(eleID,8))];
            plotDisplacement = fill(XCoordsCurEle,YCoordsCurEle,uEle);
        elseif option == 'y'
            vEle = [vAll(ele(eleID,1)) vAll(ele(eleID,5)) vAll(ele(eleID,2)) vAll(ele(eleID,6)) vAll(ele(eleID,3)) vAll(ele(eleID,7)) vAll(ele(eleID,4)) vAll(ele(eleID,8))];
            plotDisplacement = fill(XCoordsCurEle,YCoordsCurEle,vEle);
        elseif option == 'resultant'
            resEle = [resAll(ele(eleID,1)) resAll(ele(eleID,5)) resAll(ele(eleID,2)) resAll(ele(eleID,6)) resAll(ele(eleID,3)) resAll(ele(eleID,7)) resAll(ele(eleID,4)) resAll(ele(eleID,8))];
            plotDisplacement = fill(XCoordsCurEle,YCoordsCurEle,resEle);
        end
        
    end
    title(sprintf('%s displacement',option));
    colorbar
    colormap jet
    %% Plot nodes and elements in the deformed state
%     [plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')
%     xlim ([min([min(coords(:,1)) min(coordsCur(:,1))]) max([max(coords(:,1)) max(coordsCur(:,1))])])
%     ylim ([min([min(coords(:,2)) min(coordsCur(:,2))]) max([max(coords(:,2)) max(coordsCur(:,2))])])
end