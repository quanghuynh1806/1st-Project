clc
clear all
%% Material's properties
E = 1000;
nu = 0.25;
MAT = 'NeoHookean';
% MAT = 'StVenant';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Geometry & Mesh & Dirichlet and Neumann nodes
%Node
h = 0.2;
coords = [0 0 0; %1
          4 1 0; %2
          4 2 0; %3
          0 2 0; %4
          0 0 h; %5
          4 1 h; %6
          4 2 h; %7
          0 2 h; %8
          2 0.5 0; %9
          4 1.5 0; %10
          2 2 0;   %11
          0 1 0;   %12
          2 0.5 h; %13
          4 1.5 h; %14
          2 2 h;   %15
          0 1 h;   %16
          0 0 h/2; %17
          4 1 h/2; %18
          4 2 h/2; %19
          0 2 h/2; %20
          2 1.25 0; %21
          2 1.25 h; %22
          2 0.5 h/2; %23
          4 1.5 h/2; %24
          2 2 h/2; %25
          0 1 h/2; %26
          2 1.25 h/2 %27
          ];
coords = [coords;
          (coords(1,:)+coords(9,:))/2; %28
          (coords(2,:)+coords(9,:))/2; %29
          (coords(2,:)+coords(10,:))/2;%30
          (coords(3,:)+coords(10,:))/2;%31
          (coords(3,:)+coords(11,:))/2;%32
          (coords(4,:)+coords(11,:))/2;%33
          (coords(4,:)+coords(12,:))/2;%34
          (coords(1,:)+coords(12,:))/2;%35
          (coords(5,:)+coords(13,:))/2;%36
          (coords(6,:)+coords(13,:))/2;%37
          (coords(6,:)+coords(14,:))/2;%38
          (coords(7,:)+coords(14,:))/2;%39
          (coords(7,:)+coords(15,:))/2;%40
          (coords(8,:)+coords(15,:))/2;%41
          (coords(8,:)+coords(16,:))/2;%42
          (coords(5,:)+coords(16,:))/2;%43
          (coords(17,:)+coords(23,:))/2;%44
          (coords(18,:)+coords(23,:))/2;%45
          (coords(18,:)+coords(24,:))/2;%46
          (coords(19,:)+coords(24,:))/2;%47
          (coords(19,:)+coords(25,:))/2;%48
          (coords(20,:)+coords(25,:))/2;%49
          (coords(20,:)+coords(26,:))/2;%50
          (coords(17,:)+coords(26,:))/2;%51
          (coords(26,:)+coords(27,:))/2;%52
          (coords(24,:)+coords(27,:))/2;%53
          (coords(16,:)+coords(22,:))/2;%54
          (coords(14,:)+coords(22,:))/2;%55
          (coords(12,:)+coords(21,:))/2;%56
          (coords(10,:)+coords(21,:))/2];%57
          
coords = [ coords;
          (coords(44,:)+coords(52,:))/2;%58
          (coords(49,:)+coords(52,:))/2;%59
          (coords(28,:)+coords(56,:))/2;%60
          (coords(33,:)+coords(56,:))/2;%61
          (coords(9,:)+coords(21,:))/2;%62
          (coords(11,:)+coords(21,:))/2;%63
          (coords(29,:)+coords(57,:))/2;%64
          (coords(32,:)+coords(57,:))/2;%65
          (coords(23,:)+coords(27,:))/2;%66
          (coords(25,:)+coords(27,:))/2;%67
          (coords(45,:)+coords(53,:))/2;%68
          (coords(48,:)+coords(53,:))/2;%69
          (coords(36,:)+coords(54,:))/2;%70
          (coords(41,:)+coords(54,:))/2;%71
          (coords(13,:)+coords(22,:))/2;%72
          (coords(15,:)+coords(22,:))/2;%73
          (coords(37,:)+coords(55,:))/2;%74
          (coords(40,:)+coords(55,:))/2%75
          ];
[numNodes,m] = size(coords);
%Element

ele = [1 9 21 12 5 13 22 16 28 62 56 35 36 72 54 43 17 23 27 26 60 70 44 66 52 51 58;
       9 2 10 21 13 6 14 22 29 30 57 62 37 38 55 72 23 18 24 27 64 74 45 46 53 66 68;
       21 10 3 11 22 14 7 15 57 31 32 63 55 39 40 73 27 24 19 25 65 75 53 47 48 67 69;
       12 21 11 4 16 22 15 8 56 63 33 34 54 73 41 42 26 27 25 20 61 71 52 67 49 50 59];
[numEle,m] = size(ele);
%% External Line distributed load
nodesOnFaceLoad = [2 10 14 6 30 24 38 18 46;
                   10 3 7 14 31 19 39 24 47]; %Nodes order must be counter-clockwise but the mid-node must be at the end
[numFaces,m] = size(nodesOnFaceLoad);
% Dirichlet
DirNodes = [1 35 12 34 4 17 51 26 50 20 5 43 16 42 8];
GeomMeshBcNodes = struct('coords',coords,'ele',ele,'nodesOnFaceLoad',nodesOnFaceLoad,'DirNodes',DirNodes,'numNodes',numNodes,'numEle',numEle);

%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
Re = zeros(numNodes*3,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*3,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
qx = 0;
qy = -100;
qz = 0;
% compute and then add the external distributed load vector into the
% external
Re = rqFaceLoad(Re,qx,qy,qz,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*3);
for i = 1:length(DirNodes)

    DirDofs(i*3-2) = DirNodes(i)*3-2;
    DirDofs(i*3-1) = DirNodes(i)*3-1;
    DirDofs(i*3) = DirNodes(i)*3;

end
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 50;
tol = 0.00001;
maxIter = 10;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement3D(matProps,GeomMeshBcNodes,Load_n_BCs,NewtonSolParam);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

% %% Overlay of the initial and final configuration
% figure('Name','Undeformed vs Deformed Configurations')
% subplot(2,2,1)

%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw3D(coords,ele,'bo','b')

%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw3D(coordsCur,ele,'go','--g')
