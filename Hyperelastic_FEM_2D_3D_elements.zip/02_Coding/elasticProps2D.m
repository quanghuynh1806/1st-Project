function [lamda, mu, gamma] = elasticProps2D(E,nu,nDproblem)
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
%
switch nDproblem
    case 'plane stress'
        gamma = 2*mu/(lamda + 2*mu);
    case 'plane strain'
        gamma = 1; 
end
end