clc
clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
nDproblem = 'plane stress';
% MAT = 'NeoHookean';
MAT = 'StVenant';
% [lamda, mu, gamma] = elasticProps2D(E,nu,nDproblem);
hold on
%% Node
coords = [0 0; %1
          4 1; %2
          4 2; %3
          0 2; %4
          2 0.5; %5
          4 1.5; %6
          2 2; %7
          0 1; %8
          2 1.25; %9
          1 0.25; %10
          3 0.75; %11
          4 1.25; %12
          4 1.75; %13
          3 2; %14
          1 2; %15
          0 1.5; %16
          0 0.5; %17
          2 0.875; %18
          2 1.625; %19
          1 1.125; %20
          3 1.375; %21
          1 0.6875; %22
          1 1.5625; %23
          3 1.0625; %24
          3 1.6875; %25
          ];
[numNodes,m] = size(coords);
%% Element
ele = [1 5 9 8 10 18 20 17 22;
       5 2 6 9 11 12 21 18 24;
       9 6 3 7 21 13 14 19 25;
       8 9 7 4 20 19 15 16 23];
[numEle,m] = size(ele);
%% Initial thickness
h = 0.1;
%% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);
%
%% Initializa the structural matrix and vector
Re = zeros(numNodes*2,1);
Re = Re + RC;
%% External Line distributed load - independent of displacements
qn = 400;
qt = 0;
%Nodes order must be counter-clockwise but the mid-node must be at the end
nodesOnLineLoad = [2 6 12; % Edge 1
                    6 3 13];% Edge 2 
%        
Re = rqLineLoad(Re,qn,qt,h,nodesOnLineLoad,coords);
%% Dirichlet nodes and corresponding Dofs
DirNodes = [1 17 8 16 4];
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirDofs = zeros(1, length(DirNodes)*2);
for i = 1:length(DirNodes)

    DirDofs(i*2-1) = DirNodes(i)*2-1;
    DirDofs(i*2) = DirNodes(i)*2;

end

%% Load increments for Newton Raphson solution
numLoadIncr = 100;
tol = 0.0000005;
maxIter = 1000;
node4plot = 6;
% Data of Cook's membrane
PaperDataReactionForce = [0	1.5234375	2.8515625	4.140625	5.3515625	6.484375	7.5390625	8.4765625	9.375	10.234375	11.015625	11.7578125	12.4609375	13.0859375	13.75	14.296875	14.84375	15.4296875	15.9375	16.40625	16.875	17.34375	17.7734375	18.203125	18.6328125	19.0234375	19.4140625	19.8046875	20.1953125	20.546875	20.8984375;
                          0.831600832	13.25493763	25.68477131	38.11590437	51.38123701	64.6491684	77.08809771	90.36252599	102.8066528	116.0836798	128.5317048	141.8126299	155.0948545	167.5480769	180.8316008	192.4558212	205.7432432	218.1977651	230.6548857	243.9449064	256.4033264	268.8617464	282.1530665	295.4443867	307.904106	321.1967256	333.6577443	346.118763	359.4113825	371.0420998	384.3360187];

[conv,coordsCur] = NewtonLoadIncrement(Re,numLoadIncr,DirDofs,coords,ele,tol,maxIter,E,nu,nDproblem,MAT,h,node4plot,PaperDataReactionForce);

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')
subplot(2,2,1)
%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw(coords,ele,'bo','b')
%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')
%% Graph's properties
legend([plotLineUndeformed plotLineDeformed],'Undeformed','Deformed - Biquadratic')
xlim ([0.8*min([min(coords(:,1)) min(coordsCur(:,1))]) 1.2*max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([0.8*min([min(coords(:,2)) min(coordsCur(:,2))]) 1.2*max([max(coords(:,2)) max(coordsCur(:,2))])])
%% Plot the field of resultant displacement
subplot(2,2,2)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'resultant')

%% Plot the field of displacement u
subplot(2,2,3)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'x')

%% Plot the field of displacement v
subplot(2,2,4)
plotDisplacementV = drawDisplacement(coords, coordsCur, ele, 'y')

%%
figure('Name','Nodal stresses extrapolated from Gauss points')
[plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,E,nu,nDproblem,MAT)

% %%
% figure('Name','Nodal stresses directly computed from displacement field')
% [plotStressNodesCalXX,plotStressNodesCalYY,plotStressNodesCalXY] = drawStressNodalCal(coords, coordsCur, ele,E,nu,nDproblem)