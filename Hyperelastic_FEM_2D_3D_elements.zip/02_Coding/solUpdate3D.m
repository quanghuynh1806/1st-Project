%% Description: calculation of displacement increment for one iteration and then add it into the current coordinates of nodes determined from previous step.
%% Variable description
%% Input
    % KtNonDir,ReIncrNonDir, RiNonDir : Structural tangent stiffness matrix, structural external loadstep increment, structural internal loadvector after imposing Dirichlet
%                                   boundary conditions
%% Output: 
    % coordsCur => the updated current coordinates of all nodes
function [coordsCur,du] = solUpdate3D(coordsCur,KtNonDir,ReIncrNonDir,RiNonDir,NonDirDofs)
[numNodes,m] = size(coordsCur);
%% Solution
% Initialize displacement increment
du = zeros(numNodes*3,1);
dcoords = reshape(du, [], numNodes)';
duNonDir = KtNonDir\(ReIncrNonDir+RiNonDir)';

%% Get back a complete vector du after the iteration
for i = 1:length(NonDirDofs)
    du(NonDirDofs(i)) = duNonDir(i);
end

%% Update the current coordinates
dcoords = reshape(du, [], numNodes)';
coordsCur = coordsCur + dcoords; 

end