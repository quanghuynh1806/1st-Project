function [S, SHatp, Sbar, C] = VenantKirchhoff(cp,E,nu)

%     C = E/((1+nu)*(1-2*nu))*[1-nu nu 0;
%                              nu 1-nu 0;
%                              0 0 (1-2*nu)/2];
    C = E/((1-nu^2))*[1 nu 0;
                      nu 1 0;
                      0 0 (1-nu)/2];
    %% Green Larange strain
    % Tensor
    eHatp = 0.5*(cp - eye(2));
    % Vector
    e = [eHatp(1,1) eHatp(2,2) 2*eHatp(1,2)]';
    
    %% 2nd Piola Kirchhoff stress
    % Voight
    S = C*e; %[S11 S22 S12]'
    % Tensor
    SHatp = [S(1) S(3);S(3) S(2)];
    % FEM matrix
    Sbar = [SHatp zeros(2);zeros(2) SHatp];
    
end