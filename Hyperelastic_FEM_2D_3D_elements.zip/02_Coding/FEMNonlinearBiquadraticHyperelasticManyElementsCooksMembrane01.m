clc
clear all
%2D problem & Material's properties
Bulk = 120.291;
Shear = 80.194;
nu = (3*Bulk-2*Shear)/(2*Shear + 6*Bulk);
E = 3*Bulk*(1-2*nu);
nDproblem = 'plane stress';
% [lamda, mu, gamma] = elasticProps2D(E,nu,nDproblem);
%% Initial thickness
% For the plane strain problem, h must be 1 - the representative thickness. In case of plane stress, h can
% be the real thickness
h = 1;
%% Node & Elements & Nodes on line-load
hold on
% 4 corners which define the geometry of the cook membrane
Corners = [0 0;
           48 44;
           48 60;
           0 44];
% number of nodes on each edge of the membrane
numNodesSide = 11;
% nodes on Dirichlet BCs (left edge)and 
% nodes on the line of distributed load (right edge) 
% are also determined
[coords,ele,nodesOnLineLoad,DirNodes] = CookMembraneMesh(Corners,numNodesSide);
%
[numNodes,m] = size(coords);
[numEle,m] = size(ele);
%% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);
%
%% Initializa the structural matrix and vector
Re = zeros(numNodes*2,1);
Re = Re + RC;
%% External Line distributed load - independent of displacements
qn = 0;
qt = 24;    
Re = rqLineLoad(Re,qn,qt,h,nodesOnLineLoad,coords);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirDofs = zeros(1, length(DirNodes)*2);
for i = 1:length(DirNodes)

    DirDofs(i*2-1) = DirNodes(i)*2-1;
    DirDofs(i*2) = DirNodes(i)*2;

end

%% Load increments for Newton Raphson solution
numLoadIncr = 30;
tol = 0.001;
maxIter = 200;
node4plot = ele(numEle,3);
[conv,coordsCur] = NewtonLoadIncrement(Re,numLoadIncr,DirDofs,coords,ele,tol,maxIter,E,nu,nDproblem,h,node4plot);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')
subplot(2,2,1)
%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw(coords,ele,'bo','b')
%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')
%% Graph's properties
legend([plotLineUndeformed plotLineDeformed],'Undeformed','Deformed - Biquadratic')
xlim ([0.8*min([min(coords(:,1)) min(coordsCur(:,1))]) 1.2*max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([0.8*min([min(coords(:,2)) min(coordsCur(:,2))]) 1.2*max([max(coords(:,2)) max(coordsCur(:,2))])])
%% Plot the field of resultant displacement
subplot(2,2,2)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'resultant')
%% Plot the field of displacement u
subplot(2,2,3)
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'x')
%% Plot the field of displacement v
subplot(2,2,4)
plotDisplacementV = drawDisplacement(coords, coordsCur, ele, 'y')

%%
figure('Name','Nodal stresses extrapolated from Gauss points')
[plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,E,nu,nDproblem)

% %%
% figure('Name','Nodal stresses directly computed from displacement field')
% [plotStressNodesCalXX,plotStressNodesCalYY,plotStressNodesCalXY] = drawStressNodalCal(coords, coordsCur, ele,E,nu,nDproblem)

numIntervals = numNodesSide-1;
disp(['The maximum vertical displacement is at the top right corner : v = ', num2str(coordsCur(ele(numIntervals*numIntervals,3),2) - coords(ele(numIntervals*numIntervals,3),2)),' mm'])