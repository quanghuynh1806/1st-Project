clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
h = 0.2;
%Node
coords = [0 0 0; %1
          4 1 0; %2
          4 2 0; %3
          0 2 0; %4
          0 0 h; %5
          4 1 h; %6
          4 2 h; %7
          0 2 h; %8
          2 0.5 0; %9
          4 1.5 0; %10
          2 2 0;   %11
          0 1 0;   %12
          2 0.5 h; %13
          4 1.5 h; %14
          2 2 h;   %15
          0 1 h;   %16
          0 0 h/2; %17
          4 1 h/2; %18
          4 2 h/2; %19
          0 2 h/2; %20
          2 1.25 0; %21
          2 1.25 h; %22
          2 0.5 h/2; %23
          4 1.5 h/2; %24
          2 2 h/2; %25
          0 1 h/2; %26
          2 1.25 h/2 %27
          ];
[numNodes,m] = size(coords);
%Element
ele = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27];
%Plot elements and nodes
[plotLine, plotPoint] = MeshDraw3D(coords,ele,'bsquare','-.b');

%Gauss Quadrature 2D
GaussBiquadratic = [-0.774597 -0.774597 0.308642;%1
                    -0.774597  0        0.493827;%2
                    -0.774597  0.774597 0.308642;%3
                     0        -0.774597 0.493827;%4
                     0         0        0.790123;%5
                     0         0.774597 0.493827;%6
                     0.774597 -0.774597 0.308642;%7
                     0.774597  0        0.493827;%8
                     0.774597  0.774597 0.308642];%9
[nGaBiQuad, m]=size(GaussBiquadratic);
%Gauss Quadrature 3D
GaussQuadraticSolid = [-0.774597 -0.774597 -0.774597 0.171468; %1
                       -0.774597 -0.774597  0        0.274348; %2
                       -0.774597 -0.774597  0.774597 0.171468; %3
                       -0.774597  0        -0.774597 0.274348; %4
                       -0.774597  0         0        0.438957; %5
                       -0.774597  0         0.774597 0.274348; %6
                       -0.774597  0.774597 -0.774597 0.171468; %7
                       -0.774597  0.774597  0        0.274348; %8
                       -0.774597  0.774597  0.774597 0.171468; %9
                        0        -0.774597 -0.774597 0.274348; %10
                        0        -0.774597  0        0.438957; %11
                        0        -0.774597  0.774597 0.274348; %12
                        0         0        -0.774597 0.438957; %13
                        0         0         0        0.702332; %14
                        0         0         0.774597 0.438957; %15
                        0         0.774597 -0.774597 0.274348; %16
                        0         0.774597  0        0.438957; %17
                        0         0.774597  0.774597 0.274348; %18
                        0.774597 -0.774597 -0.774597 0.171468; %19
                        0.774597 -0.774597  0        0.274348; %20
                        0.774597 -0.774597  0.774597 0.171468; %21
                        0.774597  0        -0.774597 0.274348; %22
                        0.774597  0         0        0.438957; %23
                        0.774597  0         0.774597 0.274348; %24
                        0.774597  0.774597 -0.774597 0.171468; %25
                        0.774597  0.774597  0        0.274348; %26
                        0.774597  0.774597  0.774597 0.171468  %27
                       ];
[nGaQuadSolid, m]=size(GaussQuadraticSolid);
% figure()
% for GptID=1:nGaQuadSolid
%         hold on
%         plotPoint = plot3(GaussQuadraticSolid(GptID,1),GaussQuadraticSolid(GptID,2),GaussQuadraticSolid(GptID,3),'*','MarkerSize', 10);
%         text(GaussQuadraticSolid(GptID,1),GaussQuadraticSolid(GptID,2),GaussQuadraticSolid(GptID,3),sprintf('%d',GptID));
% end
%Initialize the complete external load vector
re = zeros(27*3,1);
%% External concentrated (nodal) load vector
rC = zeros(27*3,1);
% factor = 1/4;
% Dir = 1;
% rC(2*3-Dir) = -0.75*factor;
% rC(18*3-Dir) = -1.5*factor;
% rC(6*3-Dir) = -0.75*factor;
% rC(3*3-Dir) = -0.75*factor;
% rC(19*3-Dir) = -1.5*factor;
% rC(7*3-Dir) = -0.75*factor;
% rC(10*3-Dir) = -1.5*factor;
% rC(24*3-Dir) = -3.0*factor;
% rC(14*3-Dir) = -1.5*factor;
%% External Line distributed load
qx = 0;
qy = 100;
qz = 0;
nodesOnFaceLoad = [2,3,7,6,10,19,14,18,24]; %Nodes order must be counter-clockwise but the mid-node must be at the end
[numFaces,m] = size(nodesOnFaceLoad);

for face = 1:numFaces
    dofsOnFaceLoad = [nodesOnFaceLoad(face,1)*3-2 nodesOnFaceLoad(face,1)*3-1 nodesOnFaceLoad(face,1)*3 nodesOnFaceLoad(face,2)*3-2 nodesOnFaceLoad(face,2)*3-1 nodesOnFaceLoad(face,2)*3 nodesOnFaceLoad(face,3)*3-2 nodesOnFaceLoad(face,3)*3-1 nodesOnFaceLoad(face,3)*3 nodesOnFaceLoad(face,4)*3-2 nodesOnFaceLoad(face,4)*3-1 nodesOnFaceLoad(face,4)*3 nodesOnFaceLoad(face,5)*3-2 nodesOnFaceLoad(face,5)*3-1 nodesOnFaceLoad(face,5)*3 nodesOnFaceLoad(face,6)*3-2 nodesOnFaceLoad(face,6)*3-1 nodesOnFaceLoad(face,6)*3 nodesOnFaceLoad(face,7)*3-2 nodesOnFaceLoad(face,7)*3-1 nodesOnFaceLoad(face,7)*3 nodesOnFaceLoad(face,8)*3-2 nodesOnFaceLoad(face,8)*3-1 nodesOnFaceLoad(face,8)*3 nodesOnFaceLoad(face,9)*3-2 nodesOnFaceLoad(face,9)*3-1 nodesOnFaceLoad(face,9)*3];
    rq_dofsOnFaceLoad = zeros(9*3,1);
    for i = 1:nGaBiQuad
        a = GaussBiquadratic(i,1);
        b = GaussBiquadratic(i,2);
        w = GaussBiquadratic(i,3);
        % Shape functions vector after the substitution of a and b and
        % rearrangement according to the order of nodes on solid's face
        Nface = [0.25*(-1+a)*a*(-1+b)*b;
                 0.25*a*(1+a)*(-1+b)*b;
                 0.25*a*(1+a)*b*(1+b);
                 0.25*(-1+a)*a*b*(1+b);
                 0.5*(1-a^2)*(-1+b)*b;
                 0.5*a*(1+a)*(1-b^2);
                 0.5*(1-a^2)*b*(1+b);
                 0.5*(-1+a)*a*(1-b^2);
                 1.*(1-a^2)*(1-b^2)];
        dNfaceda = [
                0.5*(-0.5+1*a)*(-1+b)*b;
                0.5*(0.5+1*a)*(-1+b)*b;
                0.5*(0.5+1*a)*b*(1+b);
                0.5*(-0.5+1*a)*b*(1+b);
                -1*a*(-1+b)*b;
                0.5-0.5*b^2+a*(1-1*b^2);
                -1*a*b*(1+b);
                -0.5+0.5*b^2+a*(1-1*b^2);
                2.*a*(-1+b^2)
                    ];

        dNfacedb = [
                0.5*(-1+a)*a*(-0.5+1*b);
                0.5*a*(1+a)*(-0.5+1*b);
                0.5*a*(1+a)*(0.5+1*b);
                0.5*(-1+a)*a*(0.5+1*b);
                -0.5+a^2*(0.5-1*b)+1*b;
                -1*a*(1+a)*b;
                0.5+a^2*(-0.5-1*b)+1*b;
                -1*(-1+a)*a*b;
                2.*(-1+a^2)*b
                    ];
    
        nod1 = nodesOnFaceLoad(face,1);
        nod2 = nodesOnFaceLoad(face,2);
        nod3 = nodesOnFaceLoad(face,3);
        nod4 = nodesOnFaceLoad(face,4);
        nod5 = nodesOnFaceLoad(face,5);
        nod6 = nodesOnFaceLoad(face,6);
        nod7 = nodesOnFaceLoad(face,7);
        nod8 = nodesOnFaceLoad(face,8);
        nod9 = nodesOnFaceLoad(face,9);
        
        XcoordsFace = [coords(nod1,1) coords(nod2,1) coords(nod3,1) coords(nod4,1) coords(nod5,1) coords(nod6,1) coords(nod7,1) coords(nod8,1) coords(nod9,1)]';
        YcoordsFace = [coords(nod1,2) coords(nod2,2) coords(nod3,2) coords(nod4,2) coords(nod5,2) coords(nod6,2) coords(nod7,2) coords(nod8,2) coords(nod9,2)]';        
        ZcoordsFace = [coords(nod1,3) coords(nod2,3) coords(nod3,3) coords(nod4,3) coords(nod5,3) coords(nod6,3) coords(nod7,3) coords(nod8,3) coords(nod9,3)]';
        
        dxFaceda = dNfaceda'*XcoordsFace;
        dxFacedb = dNfacedb'*XcoordsFace;
        dyFaceda = dNfaceda'*YcoordsFace;
        dyFacedb = dNfacedb'*YcoordsFace;
        dzFaceda = dNfaceda'*ZcoordsFace;
        dzFacedb = dNfacedb'*ZcoordsFace;
        
        v1 = [dxFaceda dyFaceda dzFaceda]';
        v2 = [dxFacedb dyFacedb dzFacedb]';
        
        Js = norm(cross(v1,v2),2);
       
        NfacePt = [Nface(1) 0           0;
                   0        Nface(1)    0;
                   0        0           Nface(1);
                   Nface(2) 0           0;
                   0        Nface(2)    0;
                   0        0           Nface(2);
                   Nface(3) 0           0;
                   0        Nface(3)    0;
                   0        0           Nface(3);
                   Nface(4) 0           0;
                   0        Nface(4)    0;
                   0        0           Nface(4);
                   Nface(5) 0           0;
                   0        Nface(5)    0;
                   0        0           Nface(5);
                   Nface(6) 0           0;
                   0        Nface(6)    0;
                   0        0           Nface(6);
                   Nface(7) 0           0;
                   0        Nface(7)    0;
                   0        0           Nface(7);
                   Nface(8) 0           0;
                   0        Nface(8)    0;
                   0        0           Nface(8);
                   Nface(9) 0           0;
                   0        Nface(9)    0;
                   0        0           Nface(9)];
               
        rq_dofsOnFaceLoad = rq_dofsOnFaceLoad + w*Js*NfacePt*[qx qy qz]';

    end

    re(dofsOnFaceLoad) = re(dofsOnFaceLoad) + rq_dofsOnFaceLoad;

end
%% Complete external load vector
re = re + rC;
% re(dofsOnLineLoad) = re(dofsOnLineLoad)+rq;

%% Initialization of shape functions and partial derivatives
N1=zeros(nGaQuadSolid,1);
N2=zeros(nGaQuadSolid,1);
N3=zeros(nGaQuadSolid,1);
N4=zeros(nGaQuadSolid,1);
N5=zeros(nGaQuadSolid,1);
N6=zeros(nGaQuadSolid,1);
N7=zeros(nGaQuadSolid,1);
N8=zeros(nGaQuadSolid,1);
N9=zeros(nGaQuadSolid,1);
N10=zeros(nGaQuadSolid,1);
N11=zeros(nGaQuadSolid,1);
N12=zeros(nGaQuadSolid,1);
N13=zeros(nGaQuadSolid,1);
N14=zeros(nGaQuadSolid,1);
N15=zeros(nGaQuadSolid,1);
N16=zeros(nGaQuadSolid,1);
N17=zeros(nGaQuadSolid,1);
N18=zeros(nGaQuadSolid,1);
N19=zeros(nGaQuadSolid,1);
N20=zeros(nGaQuadSolid,1);
N21=zeros(nGaQuadSolid,1);
N22=zeros(nGaQuadSolid,1);
N23=zeros(nGaQuadSolid,1);
N24=zeros(nGaQuadSolid,1);
N25=zeros(nGaQuadSolid,1);
N26=zeros(nGaQuadSolid,1);
N27=zeros(nGaQuadSolid,1);
%
dN1r=zeros(nGaQuadSolid,1);
dN2r=zeros(nGaQuadSolid,1);
dN3r=zeros(nGaQuadSolid,1);
dN4r=zeros(nGaQuadSolid,1);
dN5r=zeros(nGaQuadSolid,1);
dN6r=zeros(nGaQuadSolid,1);
dN7r=zeros(nGaQuadSolid,1);
dN8r=zeros(nGaQuadSolid,1);
dN9r=zeros(nGaQuadSolid,1);
dN10r=zeros(nGaQuadSolid,1);
dN11r=zeros(nGaQuadSolid,1);
dN12r=zeros(nGaQuadSolid,1);
dN13r=zeros(nGaQuadSolid,1);
dN14r=zeros(nGaQuadSolid,1);
dN15r=zeros(nGaQuadSolid,1);
dN16r=zeros(nGaQuadSolid,1);
dN17r=zeros(nGaQuadSolid,1);
dN18r=zeros(nGaQuadSolid,1);
dN19r=zeros(nGaQuadSolid,1);
dN20r=zeros(nGaQuadSolid,1);
dN21r=zeros(nGaQuadSolid,1);
dN22r=zeros(nGaQuadSolid,1);
dN23r=zeros(nGaQuadSolid,1);
dN24r=zeros(nGaQuadSolid,1);
dN25r=zeros(nGaQuadSolid,1);
dN26r=zeros(nGaQuadSolid,1);
dN27r=zeros(nGaQuadSolid,1);
%
dN1s=zeros(nGaQuadSolid,1);
dN2s=zeros(nGaQuadSolid,1);
dN3s=zeros(nGaQuadSolid,1);
dN4s=zeros(nGaQuadSolid,1);
dN5s=zeros(nGaQuadSolid,1);
dN6s=zeros(nGaQuadSolid,1);
dN7s=zeros(nGaQuadSolid,1);
dN8s=zeros(nGaQuadSolid,1);
dN9s=zeros(nGaQuadSolid,1);
dN10s=zeros(nGaQuadSolid,1);
dN11s=zeros(nGaQuadSolid,1);
dN12s=zeros(nGaQuadSolid,1);
dN13s=zeros(nGaQuadSolid,1);
dN14s=zeros(nGaQuadSolid,1);
dN15s=zeros(nGaQuadSolid,1);
dN16s=zeros(nGaQuadSolid,1);
dN17s=zeros(nGaQuadSolid,1);
dN18s=zeros(nGaQuadSolid,1);
dN19s=zeros(nGaQuadSolid,1);
dN20s=zeros(nGaQuadSolid,1);
dN21s=zeros(nGaQuadSolid,1);
dN22s=zeros(nGaQuadSolid,1);
dN23s=zeros(nGaQuadSolid,1);
dN24s=zeros(nGaQuadSolid,1);
dN25s=zeros(nGaQuadSolid,1);
dN26s=zeros(nGaQuadSolid,1);
dN27s=zeros(nGaQuadSolid,1);
%
dN1t=zeros(nGaQuadSolid,1);
dN2t=zeros(nGaQuadSolid,1);
dN3t=zeros(nGaQuadSolid,1);
dN4t=zeros(nGaQuadSolid,1);
dN5t=zeros(nGaQuadSolid,1);
dN6t=zeros(nGaQuadSolid,1);
dN7t=zeros(nGaQuadSolid,1);
dN8t=zeros(nGaQuadSolid,1);
dN9t=zeros(nGaQuadSolid,1);
dN10t=zeros(nGaQuadSolid,1);
dN11t=zeros(nGaQuadSolid,1);
dN12t=zeros(nGaQuadSolid,1);
dN13t=zeros(nGaQuadSolid,1);
dN14t=zeros(nGaQuadSolid,1);
dN15t=zeros(nGaQuadSolid,1);
dN16t=zeros(nGaQuadSolid,1);
dN17t=zeros(nGaQuadSolid,1);
dN18t=zeros(nGaQuadSolid,1);
dN19t=zeros(nGaQuadSolid,1);
dN20t=zeros(nGaQuadSolid,1);
dN21t=zeros(nGaQuadSolid,1);
dN22t=zeros(nGaQuadSolid,1);
dN23t=zeros(nGaQuadSolid,1);
dN24t=zeros(nGaQuadSolid,1);
dN25t=zeros(nGaQuadSolid,1);
dN26t=zeros(nGaQuadSolid,1);
dN27t=zeros(nGaQuadSolid,1);
%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaQuadSolid
    
    r = GaussQuadraticSolid(i,1);
    s = GaussQuadraticSolid(i,2);
    t = GaussQuadraticSolid(i,3);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.125*r*(r-1)*s*(s-1)*t*(t-1); 
    N2(i) = 0.125*r*(r+1)*s*(s-1)*t*(t-1); 
    N3(i) = 0.125*r*(r+1)*s*(s+1)*t*(t-1); 
    N4(i) = 0.125*r*(r-1)*s*(s+1)*t*(t-1);
    N5(i) = 0.125*r*(r-1)*s*(s-1)*t*(t+1);
    N6(i) = 0.125*r*(r+1)*s*(s-1)*t*(t+1);
    N7(i) = 0.125*r*(r+1)*s*(s+1)*t*(t+1);
    N8(i) = 0.125*r*(r-1)*s*(s+1)*t*(t+1);
    N9(i) = 0.25*(1-r^2)*s*(s-1)*t*(t-1);
    N10(i) = 0.25*r*(r+1)*(1-s^2)*t*(t-1);
    N11(i) = 0.25*(1-r^2)*s*(s+1)*t*(t-1);
    N12(i) = 0.25*r*(r-1)*(1-s^2)*t*(t-1);
    N13(i) = 0.25*(1-r^2)*s*(s-1)*t*(t+1);
    N14(i) = 0.25*r*(r+1)*(1-s^2)*t*(t+1);
    N15(i) = 0.25*(1-r^2)*s*(s+1)*t*(t+1);
    N16(i) = 0.25*r*(r-1)*(1-s^2)*t*(t+1);
    N17(i) = 0.25*r*(r-1)*s*(s-1)*(1-t^2);
    N18(i) = 0.25*r*(r+1)*s*(s-1)*(1-t^2);
    N19(i) = 0.25*r*(r+1)*s*(s+1)*(1-t^2);
    N20(i) = 0.25*r*(r-1)*s*(s+1)*(1-t^2);
    N21(i) = 0.5*(1-r^2)*(1-s^2)*t*(t-1);
    N22(i) = 0.5*(1-r^2)*(1-s^2)*t*(t+1);
    N23(i) = 0.5*(1-r^2)*s*(s-1)*(1-t^2);
    N24(i) = 0.5*r*(r+1)*(1-s^2)*(1-t^2);
    N25(i) = 0.5*(1-r^2)*s*(s+1)*(1-t^2);
    N26(i) = 0.5*r*(r-1)*(1-s^2)*(1-t^2);
    N27(i) = (1-r^2)*(1-s^2)*(1-t^2);
    % Partial derivatives of the shape functions evaluated at Gauss point
%     dN1r(i) = 0.125*(2*r-1)*s*(s-1)*t*(t-1);
%     dN2r(i) = 0.125*(2*r+1)*s*(s-1)*t*(t-1);
%     dN3r(i) = 0.125*(2*r+1)*s*(s+1)*t*(t-1);
%     dN4r(i) = 0.125*(2*r-1)*s*(s+1)*t*(t-1);
%     dN5r(i) = 0.125*(2*r-1)*s*(s-1)*t*(t+1);
%     dN6r(i) = 0.125*(2*r+1)*s*(s-1)*t*(t+1);
%     dN7r(i) = 0.125*(2*r+1)*s*(s+1)*t*(t+1);
%     dN8r(i) = 0.125*(2*r-1)*s*(s+1)*t*(t+1);
%     dN9r(i) = 0.25*(-2*r)*s*(s-1)*t*(t-1);
%     dN10r(i) = 0.25*(2*r+1)*(1-s^2)*t*(t-1);
%     dN11r(i) = 0.25*(-2*r)*s*(s+1)*t*(t-1);
%     dN12r(i) = 0.25*(2*r-1)*(1-s^2)*t*(t-1);
%     dN13r(i) = 0.25*(-2*r)*s*(s-1)*t*(t+1);
%     dN14r(i) = 0.25*(2*r+1)*(1-s^2)*t*(t+1);
%     dN15r(i) = 0.25*(-2*r)*s*(s+1)*t*(t+1);
%     dN16r(i) = 0.25*(2*r-1)*(1-s^2)*t*(t+1);
%     dN17r(i) = 0.25*(2*r-1)*s*(s-1)*(1-t^2);
%     dN18r(i) = 0.25*(2*r+1)*s*(s-1)*(1-t^2);
%     dN19r(i) = 0.25*(2*r+1)*s*(s+1)*(1-t^2);
%     dN20r(i) = 0.25*(2*r-1)*s*(s+1)*(1-t^2);
%     dN21r(i) = 0.5*(-2*r)*(1-s^2)*t*(t-1);
%     dN22r(i) = 0.5*(-2*r)*(1-s^2)*t*(t+1);
%     dN23r(i) = 0.5*(-2*r)*s*(s-1)*(1-t^2);
%     dN24r(i) = 0.5*(2*r+1)*(1-s^2)*(1-t^2);
%     dN25r(i) = 0.5*(-2*r)*s*(s+1)*(1-t^2);
%     dN26r(i) = 0.5*(2*r-1)*(1-s^2)*(1-t^2);
%     dN27r(i) = (-2*r)*(1-s^2)*(1-t^2);
    dN1r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN2r(i) = 0.25*(0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN3r(i) = 0.25*(0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN4r(i) = 0.25*(-0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN5r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*t*(1+t);
    dN6r(i) = 0.25*(0.5+1*r)*(-1+s)*s*t*(1+t);
    dN7r(i) = 0.25*(0.5+1*r)*s*(1+s)*t*(1+t);
    dN8r(i) = 0.25*(-0.5+1*r)*s*(1+s)*t*(1+t);
    dN9r(i) = -0.5*r*(-1+s)*s*(-1+t)*t;
    dN10r(i) = -0.5*(0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN11r(i) = -0.5*r*s*(1+s)*(-1+t)*t;
    dN12r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN13r(i) = -0.5*r*(-1+s)*s*t*(1+t);
    dN14r(i) = -0.5*(0.5+1*r)*(-1+s^2)*t*(1+t);
    dN15r(i) = -0.5*r*s*(1+s)*t*(1+t);
    dN16r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*t*(1+t);
    dN17r(i) = -0.5*(-0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN18r(i) = -0.5*(0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN19r(i) = -0.5*(0.5+1*r)*s*(1+s)*(-1+t^2);
    dN20r(i) = -0.5*(-0.5+1*r)*s*(1+s)*(-1+t^2);
    dN21r(i) = 1*r*(-1+s^2)*(-1+t)*t;
    dN22r(i) = 1*r*(-1+s^2)*t*(1+t);
    dN23r(i) = 1*r*(-1+s)*s*(-1+t^2);
    dN24r(i) = 1*(0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN25r(i) = 1*r*s*(1+s)*(-1+t^2);
    dN26r(i) = 1*(-0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN27r(i) = -2*r*(-1+s^2)*(-1+t^2);
    %
%     dN1s(i) = 0.125*r*(r-1)*(2*s-1)*t*(t-1);
%     dN2s(i) = 0.125*r*(r+1)*(2*s-1)*t*(t-1);
%     dN3s(i) = 0.125*r*(r+1)*(2*s+1)*t*(t-1);
%     dN4s(i) = 0.125*r*(r-1)*(2*s+1)*t*(t-1);
%     dN5s(i) = 0.125*r*(r-1)*(2*s-1)*t*(t+1);
%     dN6s(i) = 0.125*r*(r+1)*(2*s-1)*t*(t+1);
%     dN7s(i) = 0.125*r*(r+1)*(2*s+1)*t*(t+1);
%     dN8s(i) = 0.125*r*(r-1)*(2*s+1)*t*(t+1);
%     dN9s(i) = 0.25*(1-r^2)*(2*s-1)*t*(t-1);
%     dN10s(i) = 0.25*r*(r+1)*(-2*s)*t*(t-1);
%     dN11s(i) = 0.25*(1-r^2)*(2*s+1)*t*(t-1);
%     dN12s(i) = 0.25*r*(r-1)*(-2*s)*t*(t-1);
%     dN13s(i) = 0.25*(1-r^2)*(2*s-1)*t*(t+1);
%     dN14s(i) = 0.25*r*(r+1)*(-2*s)*t*(t+1);
%     dN15s(i) = 0.25*(1-r^2)*(2*s+1)*t*(t+1);
%     dN16s(i) = 0.25*r*(r-1)*(-2*s)*t*(t+1);
%     dN17s(i) = 0.25*r*(r-1)*(2*s-1)*(1-t^2);
%     dN18s(i) = 0.25*r*(r+1)*(2*s-1)*(1-t^2);
%     dN19s(i) = 0.25*r*(r+1)*(2*s+1)*(1-t^2);
%     dN20s(i) = 0.25*r*(r-1)*(2*s+1)*(1-t^2);
%     dN21s(i) = 0.5*(1-r^2)*(-2*s)*t*(t-1);
%     dN22s(i) = 0.5*(1-r^2)*(-2*s)*t*(t+1);
%     dN23s(i) = 0.5*(1-r^2)*(2*s-1)*(1-t^2);
%     dN24s(i) = 0.5*r*(r+1)*(-2*s)*(1-t^2);
%     dN25s(i) = 0.5*(1-r^2)*(2*s+1)*(1-t^2);
%     dN26s(i) = 0.5*r*(r-1)*(-2*s)*(1-t^2);
%     dN27s(i) = (1-r^2)*(-2*s)*(1-t^2);
    dN1s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*(-1+t)*t;
    dN2s(i) = 0.25*r*(1+r)*(-0.5+1*s)*(-1+t)*t;
    dN3s(i) = 0.25*r*(1+r)*(0.5+1*s)*(-1+t)*t;
    dN4s(i) = 0.25*(-1+r)*r*(0.5+1*s)*(-1+t)*t;
    dN5s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*t*(1+t);
    dN6s(i) = 0.25*r*(1+r)*(-0.5+1*s)*t*(1+t);
    dN7s(i) = 0.25*r*(1+r)*(0.5+1*s)*t*(1+t);
    dN8s(i) = 0.25*(-1+r)*r*(0.5+1*s)*t*(1+t);
    dN9s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*(-1+t)*t;
    dN10s(i) = -0.5*r*(1+r)*s*(-1+t)*t;
    dN11s(i) = -0.5*(-1+r^2)*(0.5+1*s)*(-1+t)*t;
    dN12s(i) = -0.5*(-1+r)*r*s*(-1+t)*t;
    dN13s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*t*(1+t);
    dN14s(i) = -0.5*r*(1+r)*s*t*(1+t);
    dN15s(i) = -0.5*(-1+r^2)*(0.5+1*s)*t*(1+t);
    dN16s(i) = -0.5*(-1+r)*r*s*t*(1+t);
    dN17s(i) = -0.5*(-1+r)*r*(-0.5+1*s)*(-1+t^2);
    dN18s(i) = -0.5*r*(1+r)*(-0.5+1*s)*(-1+t^2);
    dN19s(i) = -0.5*r*(1+r)*(0.5+1*s)*(-1+t^2);
    dN20s(i) = -0.5*(-1+r)*r*(0.5+1*s)*(-1+t^2);
    dN21s(i) = 1*(-1+r^2)*s*(-1+t)*t;
    dN22s(i) = 1*(-1+r^2)*s*t*(1+t);
    dN23s(i) = 1*(-1+r^2)*(-0.5+1*s)*(-1+t^2);
    dN24s(i) = 1*r*(1+r)*s*(-1+t^2);
    dN25s(i) = 1*(-1+r^2)*(0.5+1*s)*(-1+t^2);
    dN26s(i) = 1*(-1+r)*r*s*(-1+t^2);
    dN27s(i) = -2*(-1+r^2)*s*(-1+t^2);
    %
%     dN1t(i) = 0.125*r*(r-1)*s*(s-1)*(2*t-1);
%     dN2t(i) = 0.125*r*(r+1)*s*(s-1)*(2*t-1);
%     dN3t(i) = 0.125*r*(r+1)*s*(s+1)*(2*t-1);
%     dN4t(i) = 0.125*r*(r-1)*s*(s+1)*(2*t-1);
%     dN5t(i) = 0.125*r*(r-1)*s*(s-1)*(2*t+1);
%     dN6t(i) = 0.125*r*(r+1)*s*(s-1)*(2*t+1);
%     dN7t(i) = 0.125*r*(r+1)*s*(s+1)*(2*t+1);
%     dN8t(i) = 0.125*r*(r-1)*s*(s+1)*(2*t+1);
%     dN9t(i) = 0.25*(1-r^2)*s*(s-1)*(2*t-1);
%     dN10t(i) = 0.25*r*(r+1)*(1-s^2)*(2*t-1);
%     dN11t(i) = 0.25*(1-r^2)*s*(s+1)*(2*t-1);
%     dN12t(i) = 0.25*r*(r-1)*(1-s^2)*(2*t-1);
%     dN13t(i) = 0.25*(1-r^2)*s*(s-1)*(2*t+1);
%     dN14t(i) = 0.25*r*(r+1)*(1-s^2)*(2*t+1);
%     dN15t(i) = 0.25*(1-r^2)*s*(s+1)*(2*t+1);
%     dN16t(i) = 0.25*r*(r-1)*(1-s^2)*(2*t+1);
%     dN17t(i) = 0.25*r*(r-1)*s*(s-1)*(-2*t);
%     dN18t(i) = 0.25*r*(r+1)*s*(s-1)*(-2*t);
%     dN19t(i) = 0.25*r*(r+1)*s*(s+1)*(-2*t);
%     dN20t(i) = 0.25*r*(r-1)*s*(s+1)*(-2*t);
%     dN21t(i) = 0.5*(1-r^2)*(1-s^2)*(2*t-1);
%     dN22t(i) = 0.5*(1-r^2)*(1-s^2)*(2*t+1);
%     dN23t(i) = 0.5*(1-r^2)*s*(s-1)*(-2*t);
%     dN24t(i) = 0.5*r*(r+1)*(1-s^2)*(-2*t);
%     dN25t(i) = 0.5*(1-r^2)*s*(s+1)*(-2*t);
%     dN26t(i) = 0.5*r*(r-1)*(1-s^2)*(-2*t);
%     dN27t(i) = (1-r^2)*(1-s^2)*(-2*t);
    dN1t(i) = 0.25*(-1+r)*r*(-1+s)*s*(-0.5+1*t);
    dN2t(i) = 0.25*r*(1+r)*(-1+s)*s*(-0.5+1*t);
    dN3t(i) = 0.25*r*(1+r)*s*(1+s)*(-0.5+1*t);
    dN4t(i) = 0.25*(-1+r)*r*s*(1+s)*(-0.5+1*t);
    dN5t(i) = 0.25*(-1+r)*r*(-1+s)*s*(0.5+1*t);
    dN6t(i) = 0.25*r*(1+r)*(-1+s)*s*(0.5+1*t);
    dN7t(i) = 0.25*r*(1+r)*s*(1+s)*(0.5+1*t);
    dN8t(i) = 0.25*(-1+r)*r*s*(1+s)*(0.5+1*t);
    dN9t(i) = -0.5*(-1+r^2)*(-1+s)*s*(-0.5+1*t);
    dN10t(i) = -0.5*r*(1+r)*(-1+s^2)*(-0.5+1*t);
    dN11t(i) = -0.5*(-1+r^2)*s*(1+s)*(-0.5+1*t);
    dN12t(i) = -0.5*(-1+r)*r*(-1+s^2)*(-0.5+1*t);
    dN13t(i) = -0.5*(-1+r^2)*(-1+s)*s*(0.5+1*t);
    dN14t(i) = -0.5*r*(1+r)*(-1+s^2)*(0.5+1*t);
    dN15t(i) = -0.5*(-1+r^2)*s*(1+s)*(0.5+1*t);
    dN16t(i) = -0.5*(-1+r)*r*(-1+s^2)*(0.5+1*t);
    dN17t(i) = -0.5*(-1+r)*r*(-1+s)*s*t;
    dN18t(i) = -0.5*r*(1+r)*(-1+s)*s*t;
    dN19t(i) = -0.5*r*(1+r)*s*(1+s)*t;
    dN20t(i) = -0.5*(-1+r)*r*s*(1+s)*t;
    dN21t(i) = 1*(-1+r^2)*(-1+s^2)*(-0.5+1*t);
    dN22t(i) = 1*(-1+r^2)*(-1+s^2)*(0.5+1*t);
    dN23t(i) = 1*(-1+r^2)*(-1+s)*s*t;
    dN24t(i) = 1*r*(1+r)*(-1+s^2)*t;
    dN25t(i) = 1*(-1+r^2)*s*(1+s)*t;
    dN26t(i) = 1*(-1+r)*r*(-1+s^2)*t;
    dN27t(i) = -2*(-1+r^2)*(-1+s^2)*t;
end

%% Later on the loop for assembly of global stiffness matrix is added here

%% Load increments for Newton Raphson solution
numLoadIncr = 10;
lamdaIncr = 1/numLoadIncr;
coordsCur = coords; %initial guess for the first load step
for loadIncr = 1:numLoadIncr
reIncr = loadIncr*lamdaIncr*re;
%% Loop over gauss points, calculate and add up the matrices and solve the equation for displacement increment
%% Later on the the loop for Newton Raphson is added here
conv = 1;
convDis = 1;
numIter = 0;
eleID = 1;
maxIter = 20;
% conv > 0.005 &&
% convDis > 10^-3
while ( conv > 0.00005) && numIter <= maxIter
    numIter=numIter+1;
    %Initialization of the variables
    %displacement increment
    du = zeros(length(coords)*3,1);
    dcoords = reshape(du, [], numNodes)';
    %mapping from initial to master
    Jfem = zeros(3);
    %mapping from current to master
    JfemCur = zeros(3);
    %planar deformation gradient tensor
    F = zeros(3);
    %deformation gradient matrix in FEM style
    Fbar = zeros(6,9);
    %strain matrix
    BT = zeros(9,27*3);
    %current/material stiffness matrix
    kc = zeros(27*3);
    %stress/geometric stiffness matrix
    ks = zeros(27*3);
    %tangent stiffness matrix
    k = zeros(27*3);
    %internal force vector
    ri = zeros(27*3,1);
    %internal force vector for residual check
    riRes = zeros(27*3,1);
    
    for i = 1:nGaQuadSolid

        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i) N10(i) N11(i) N12(i) N13(i) N14(i) N15(i) N16(i) N17(i) N18(i) N19(i) N20(i) N21(i) N22(i) N23(i) N24(i) N25(i) N26(i) N27(i)];
        w = GaussQuadraticSolid(i,4);
        % Partial derivatives of the shape functions evaluated at Gauss point
        dNr = [dN1r(i) dN2r(i) dN3r(i) dN4r(i) dN5r(i) dN6r(i) dN7r(i) dN8r(i) dN9r(i) dN10r(i) dN11r(i) dN12r(i) dN13r(i) dN14r(i) dN15r(i) dN16r(i) dN17r(i) dN18r(i) dN19r(i) dN20r(i) dN21r(i) dN22r(i) dN23r(i) dN24r(i) dN25r(i) dN26r(i) dN27r(i)];
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i) dN10s(i) dN11s(i) dN12s(i) dN13s(i) dN14s(i) dN15s(i) dN16s(i) dN17s(i) dN18s(i) dN19s(i) dN20s(i) dN21s(i) dN22s(i) dN23s(i) dN24s(i) dN25s(i) dN26s(i) dN27s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i) dN10t(i) dN11t(i) dN12t(i) dN13t(i) dN14t(i) dN15t(i) dN16t(i) dN17t(i) dN18t(i) dN19t(i) dN20t(i) dN21t(i) dN22t(i) dN23t(i) dN24t(i) dN25t(i) dN26t(i) dN27t(i)];
      
        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1) coords(ele(eleID,5),1) coords(ele(eleID,6),1) coords(ele(eleID,7),1) coords(ele(eleID,8),1) coords(ele(eleID,9),1) coords(ele(eleID,10),1) coords(ele(eleID,11),1) coords(ele(eleID,12),1) coords(ele(eleID,13),1) coords(ele(eleID,14),1) coords(ele(eleID,15),1) coords(ele(eleID,16),1) coords(ele(eleID,17),1) coords(ele(eleID,18),1) coords(ele(eleID,19),1) coords(ele(eleID,20),1) coords(ele(eleID,21),1) coords(ele(eleID,22),1) coords(ele(eleID,23),1) coords(ele(eleID,24),1) coords(ele(eleID,25),1) coords(ele(eleID,26),1) coords(ele(eleID,27),1)]';
        Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2) coords(ele(eleID,5),2) coords(ele(eleID,6),2) coords(ele(eleID,7),2) coords(ele(eleID,8),2) coords(ele(eleID,9),2) coords(ele(eleID,10),2) coords(ele(eleID,11),2) coords(ele(eleID,12),2) coords(ele(eleID,13),2) coords(ele(eleID,14),2) coords(ele(eleID,15),2) coords(ele(eleID,16),2) coords(ele(eleID,17),2) coords(ele(eleID,18),2) coords(ele(eleID,19),2) coords(ele(eleID,20),2) coords(ele(eleID,21),2) coords(ele(eleID,22),2) coords(ele(eleID,23),2) coords(ele(eleID,24),2) coords(ele(eleID,25),2) coords(ele(eleID,26),2) coords(ele(eleID,27),2)]';        
        Zcoords = [coords(ele(eleID,1),3) coords(ele(eleID,2),3) coords(ele(eleID,3),3) coords(ele(eleID,4),3) coords(ele(eleID,5),3) coords(ele(eleID,6),3) coords(ele(eleID,7),3) coords(ele(eleID,8),3) coords(ele(eleID,9),3) coords(ele(eleID,10),3) coords(ele(eleID,11),3) coords(ele(eleID,12),3) coords(ele(eleID,13),3) coords(ele(eleID,14),3) coords(ele(eleID,15),3) coords(ele(eleID,16),3) coords(ele(eleID,17),3) coords(ele(eleID,18),3) coords(ele(eleID,19),3) coords(ele(eleID,20),3) coords(ele(eleID,21),3) coords(ele(eleID,22),3) coords(ele(eleID,23),3) coords(ele(eleID,24),3) coords(ele(eleID,25),3) coords(ele(eleID,26),3) coords(ele(eleID,27),3)]';
        x0 = N*Xcoords;
        y0 = N*Ycoords;
        z0 = N*Zcoords;

        Jfem11 = dNr*Xcoords;
        Jfem12 = dNs*Xcoords;
        Jfem13 = dNt*Xcoords;
        Jfem21 = dNr*Ycoords;
        Jfem22 = dNs*Ycoords;
        Jfem23 = dNt*Ycoords;
        Jfem31 = dNr*Zcoords;
        Jfem32 = dNs*Zcoords;
        Jfem33 = dNt*Zcoords;
        
        Jfem = [Jfem11 Jfem12 Jfem13;
                Jfem21 Jfem22 Jfem23;
                Jfem31 Jfem32 Jfem33];
        detJfem = det(Jfem);

        %Current Configuration's quantites evaluted at Gauss point
        %% For the first iteration, take the values of the initial config for the initial guess of the Current Configuration's quantites
        XcoordsCur = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1) coordsCur(ele(eleID,5),1) coordsCur(ele(eleID,6),1) coordsCur(ele(eleID,7),1) coordsCur(ele(eleID,8),1) coordsCur(ele(eleID,9),1) coordsCur(ele(eleID,10),1) coordsCur(ele(eleID,11),1) coordsCur(ele(eleID,12),1) coordsCur(ele(eleID,13),1) coordsCur(ele(eleID,14),1) coordsCur(ele(eleID,15),1) coordsCur(ele(eleID,16),1) coordsCur(ele(eleID,17),1) coordsCur(ele(eleID,18),1) coordsCur(ele(eleID,19),1) coordsCur(ele(eleID,20),1) coordsCur(ele(eleID,21),1) coordsCur(ele(eleID,22),1) coordsCur(ele(eleID,23),1) coordsCur(ele(eleID,24),1) coordsCur(ele(eleID,25),1) coordsCur(ele(eleID,26),1) coordsCur(ele(eleID,27),1)]';
        YcoordsCur = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2) coordsCur(ele(eleID,5),2) coordsCur(ele(eleID,6),2) coordsCur(ele(eleID,7),2) coordsCur(ele(eleID,8),2) coordsCur(ele(eleID,9),2) coordsCur(ele(eleID,10),2) coordsCur(ele(eleID,11),2) coordsCur(ele(eleID,12),2) coordsCur(ele(eleID,13),2) coordsCur(ele(eleID,14),2) coordsCur(ele(eleID,15),2) coordsCur(ele(eleID,16),2) coordsCur(ele(eleID,17),2) coordsCur(ele(eleID,18),2) coordsCur(ele(eleID,19),2) coordsCur(ele(eleID,20),2) coordsCur(ele(eleID,21),2) coordsCur(ele(eleID,22),2) coordsCur(ele(eleID,23),2) coordsCur(ele(eleID,24),2) coordsCur(ele(eleID,25),2) coordsCur(ele(eleID,26),2) coordsCur(ele(eleID,27),2)]';        
        ZcoordsCur = [coordsCur(ele(eleID,1),3) coordsCur(ele(eleID,2),3) coordsCur(ele(eleID,3),3) coordsCur(ele(eleID,4),3) coordsCur(ele(eleID,5),3) coordsCur(ele(eleID,6),3) coordsCur(ele(eleID,7),3) coordsCur(ele(eleID,8),3) coordsCur(ele(eleID,9),3) coordsCur(ele(eleID,10),3) coordsCur(ele(eleID,11),3) coordsCur(ele(eleID,12),3) coordsCur(ele(eleID,13),3) coordsCur(ele(eleID,14),3) coordsCur(ele(eleID,15),3) coordsCur(ele(eleID,16),3) coordsCur(ele(eleID,17),3) coordsCur(ele(eleID,18),3) coordsCur(ele(eleID,19),3) coordsCur(ele(eleID,20),3) coordsCur(ele(eleID,21),3) coordsCur(ele(eleID,22),3) coordsCur(ele(eleID,23),3) coordsCur(ele(eleID,24),3) coordsCur(ele(eleID,25),3) coordsCur(ele(eleID,26),3) coordsCur(ele(eleID,27),3)]';
        xCur = N*XcoordsCur;
        yCur = N*YcoordsCur;
        zCur = N*ZcoordsCur;

        Jfem11Cur = dNr*XcoordsCur; %dxCur/dr
        Jfem12Cur = dNs*XcoordsCur; %dxCur/ds
        Jfem13Cur = dNt*XcoordsCur; %dxCur/dt
        Jfem21Cur = dNr*YcoordsCur;
        Jfem22Cur = dNs*YcoordsCur;
        Jfem23Cur = dNt*YcoordsCur;
        Jfem31Cur = dNr*ZcoordsCur;
        Jfem32Cur = dNs*ZcoordsCur;
        Jfem33Cur = dNt*ZcoordsCur;
        
        JfemCur = [Jfem11Cur Jfem12Cur Jfem13Cur;
                   Jfem21Cur Jfem22Cur Jfem23Cur;
                   Jfem31Cur Jfem32Cur Jfem33Cur];
        detJfemCur = det(JfemCur);

        %calculate Fp & Fbar
        dxCurdx0dy0dz0 = inv(Jfem)'*[Jfem11Cur Jfem12Cur Jfem13Cur]';
        dyCurdx0dy0dz0 = inv(Jfem)'*[Jfem21Cur Jfem22Cur Jfem23Cur]';
        dzCurdx0dy0dz0 = inv(Jfem)'*[Jfem31Cur Jfem32Cur Jfem33Cur]';
        %deformation gradient
        F = [dxCurdx0dy0dz0';
             dyCurdx0dy0dz0';
             dzCurdx0dy0dz0'];
        Fbar = [diag(dxCurdx0dy0dz0)                  diag(dyCurdx0dy0dz0)                  diag(dzCurdx0dy0dz0);
                dxCurdx0dy0dz0(2) dxCurdx0dy0dz0(1) 0 dyCurdx0dy0dz0(2) dyCurdx0dy0dz0(1) 0 dzCurdx0dy0dz0(2) dzCurdx0dy0dz0(1) 0;
                0 dxCurdx0dy0dz0(3) dxCurdx0dy0dz0(2) 0 dyCurdx0dy0dz0(3) dyCurdx0dy0dz0(2) 0 dzCurdx0dy0dz0(3) dzCurdx0dy0dz0(2);
                dxCurdx0dy0dz0(3) 0 dxCurdx0dy0dz0(1) dyCurdx0dy0dz0(3) 0 dyCurdx0dy0dz0(1) dzCurdx0dy0dz0(3) 0 dzCurdx0dy0dz0(1)];
        detF = det(F);

        %calculate BT
        BT = [];
        for Nid = 1:27
            dNidx0dy0dz0 = inv(Jfem)'*[dNr(Nid) dNs(Nid) dNt(Nid)]';
            BT = [BT [dNidx0dy0dz0 zeros(3,1) zeros(3,1);zeros(3,1) dNidx0dy0dz0 zeros(3,1); zeros(3,1) zeros(3,1) dNidx0dy0dz0]]; 
        end
   
        %right Cauchy-Green tensor
        c = F'*F;
        cInv = inv(c);
        
        %Constitutive tensor
        C11 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,1)^2;
        C12 = (2*mu - 2*log(detF)*lamda)*cInv(1,2)^2 + lamda*cInv(1,1)*cInv(2,2);
        C13 = (2*mu - 2*log(detF)*lamda)*cInv(3,1)^2 + lamda*cInv(1,1)*cInv(3,3);
        C14 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(1,1);
        C15 = lamda*cInv(1,1)*cInv(2,3) + 2*(mu - log(detF)*lamda)*cInv(1,2)*cInv(3,1);
        C16 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,1)*cInv(3,1);
        %
        C21 = C12;
        C22 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,2)^2;
        C23 = (2*mu - 2*log(detF)*lamda)*cInv(2,3)^2 + lamda*cInv(2,2)*cInv(3,3);
        C24 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(2,2);
        C25 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,2)*cInv(2,3);
        C26 = 2*(mu - log(detF)*lamda)*cInv(1,2)*cInv(2,3) + lamda*cInv(2,2)*cInv(3,1);
        %
        C31 = C13;
        C32 = C23;
        C33 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(3,3)^2;
        C34 = 2*(mu - log(detF)*lamda)*cInv(2,3)*cInv(3,1) + lamda*cInv(1,2)*cInv(3,3);
        C35 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,3)*cInv(3,3);
        C36 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(3,1)*cInv(3,3);
        %
        C41 = C14;
        C42 = C24;
        C43 = C34;
        C44 = (-log(detF)*lamda + lamda + mu)*cInv(1,2)^2 + (mu - log(detF)*lamda)*cInv(1,1)*cInv(2,2);
        C45 = (-log(detF)*lamda + lamda + mu)*cInv(1,2)*cInv(2,3) + (mu - log(detF)*lamda)*cInv(2,2)*cInv(3,1);
        C46 = (mu - log(detF)*lamda)*cInv(1,1)*cInv(2,3) + (-log(detF)*lamda + lamda + mu)*cInv(1,2)*cInv(3,1);
        %
        C51 = C15;
        C52 = C25;
        C53 = C35;
        C54 = C45;
        C55 = (-log(detF)*lamda + lamda + mu)*cInv(2,3)^2 + (mu - log(detF)*lamda)*cInv(2,2)*cInv(3,3);
        C56 = (-log(detF)*lamda + lamda + mu)*cInv(2,3)*cInv(3,1) + (mu - log(detF)*lamda)*cInv(1,2)*cInv(3,3);
        %
        C61 = C16;
        C62 = C26;
        C63 = C36;
        C64 = C46;
        C65 = C56;
        C66 = (-log(detF)*lamda + lamda + mu)*cInv(3,1)^2 + (mu - log(detF)*lamda)*cInv(1,1)*cInv(3,3);
        %
        C = [C11 C12 C13 C14 C15 C16;
             C21 C22 C23 C24 C25 C26;
             C31 C32 C33 C34 C35 C36;
             C41 C42 C43 C44 C45 C46;
             C51 C52 C53 C54 C55 C56;
             C61 C62 C63 C64 C65 C66];
        
        %Green Larange strain tensor
        EGLHat = 0.5*(c - eye(3));
        EGL = [EGLHat(1,1) EGLHat(2,2) EGLHat(3,3) 2*EGLHat(1,2) 2*EGLHat(2,3) 2*EGLHat(3,1)]';
        
        %Planar 2nd PK stress tensor
%         S = C*EGL;
%         SHat = [S(1) S(4) S(6);
%                 S(4) S(2) S(5);
%                 S(6) S(5) S(3)];
        SHat = lamda*log(detF)*cInv + mu*(eye(3) - cInv);
        S = [SHat(1,1) SHat(2,2) SHat(3,3) SHat(1,2) SHat(2,3) SHat(1,3)]';
        
        %2nd PK stress matrix in FEM style
        Sbar = [SHat zeros(3,3) zeros(3,3);
                zeros(3,3) SHat zeros(3,3);
                zeros(3,3) zeros(3,3) SHat];
        
        %Stiffness matrix and internal loadvector
        kc = kc + (BT')*(Fbar')*C*Fbar*BT*detJfem*w;
        ks = ks + (BT')*Sbar*BT*detJfem*w;
        ri = ri + -(BT')*(Fbar')*S*detJfem*w;
    end
    k = kc + ks;
    %
    %% Boundary condition
    %Fix both vertical & horizontal displacements
    DirNodes = [1 4 8 5 12 20 16 17 26];
    DirDofs = zeros(1, length(DirNodes)*3);
    for i = 1:length(DirNodes)

        DirDofs(i*3-2) = DirNodes(i)*3-2;
        DirDofs(i*3-1) = DirNodes(i)*3-1;
        DirDofs(i*3) = DirNodes(i)*3;
        
    end

    %Apply BCs
    allDofs = [1:length(coords)*3];
    NonDirDofs = setdiff(allDofs,DirDofs);
    %% Simplify tangent stiffness matrix after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        for j = i:length(NonDirDofs)

            kNonDir(i,j) = k(NonDirDofs(i),NonDirDofs(j));
            kNonDir(j,i) = k(NonDirDofs(i),NonDirDofs(j));

        end

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        riNonDir(i) = ri(NonDirDofs(i));    
        reIncrNonDir(i) = reIncr(NonDirDofs(i));

    end
    
    %% Solution
    duNonDir = kNonDir\(reIncrNonDir+riNonDir)';

    %% Get back a complete vector du after the iteration
    
    for i = 1:length(NonDirDofs)

        du(NonDirDofs(i)) = duNonDir(i);

    end
    dcoords = reshape(du, [], numNodes)';
    coordsCur = coordsCur + dcoords; 
    %% The current config coordsCur is updated for:
    % 1. Entering the residual procedure:
         %If unsatisfied 
            % => used for the next iteration with the same loadstep
         %Otherwise 
            % => used as the initial guess for the next loadstep
      
    %% Check the residual after the completion of the latest iteration
    for i = 1:nGaQuadSolid
        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i) N10(i) N11(i) N12(i) N13(i) N14(i) N15(i) N16(i) N17(i) N18(i) N19(i) N20(i) N21(i) N22(i) N23(i) N24(i) N25(i) N26(i) N27(i)];
        w = GaussQuadraticSolid(i,4);
        % Partial derivatives of the shape functions evaluated at Gauss point
        dNr = [dN1r(i) dN2r(i) dN3r(i) dN4r(i) dN5r(i) dN6r(i) dN7r(i) dN8r(i) dN9r(i) dN10r(i) dN11r(i) dN12r(i) dN13r(i) dN14r(i) dN15r(i) dN16r(i) dN17r(i) dN18r(i) dN19r(i) dN20r(i) dN21r(i) dN22r(i) dN23r(i) dN24r(i) dN25r(i) dN26r(i) dN27r(i)];
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i) dN10s(i) dN11s(i) dN12s(i) dN13s(i) dN14s(i) dN15s(i) dN16s(i) dN17s(i) dN18s(i) dN19s(i) dN20s(i) dN21s(i) dN22s(i) dN23s(i) dN24s(i) dN25s(i) dN26s(i) dN27s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i) dN10t(i) dN11t(i) dN12t(i) dN13t(i) dN14t(i) dN15t(i) dN16t(i) dN17t(i) dN18t(i) dN19t(i) dN20t(i) dN21t(i) dN22t(i) dN23t(i) dN24t(i) dN25t(i) dN26t(i) dN27t(i)];

        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1) coords(ele(eleID,5),1) coords(ele(eleID,6),1) coords(ele(eleID,7),1) coords(ele(eleID,8),1) coords(ele(eleID,9),1) coords(ele(eleID,10),1) coords(ele(eleID,11),1) coords(ele(eleID,12),1) coords(ele(eleID,13),1) coords(ele(eleID,14),1) coords(ele(eleID,15),1) coords(ele(eleID,16),1) coords(ele(eleID,17),1) coords(ele(eleID,18),1) coords(ele(eleID,19),1) coords(ele(eleID,20),1) coords(ele(eleID,21),1) coords(ele(eleID,22),1) coords(ele(eleID,23),1) coords(ele(eleID,24),1) coords(ele(eleID,25),1) coords(ele(eleID,26),1) coords(ele(eleID,27),1)]';
        Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2) coords(ele(eleID,5),2) coords(ele(eleID,6),2) coords(ele(eleID,7),2) coords(ele(eleID,8),2) coords(ele(eleID,9),2) coords(ele(eleID,10),2) coords(ele(eleID,11),2) coords(ele(eleID,12),2) coords(ele(eleID,13),2) coords(ele(eleID,14),2) coords(ele(eleID,15),2) coords(ele(eleID,16),2) coords(ele(eleID,17),2) coords(ele(eleID,18),2) coords(ele(eleID,19),2) coords(ele(eleID,20),2) coords(ele(eleID,21),2) coords(ele(eleID,22),2) coords(ele(eleID,23),2) coords(ele(eleID,24),2) coords(ele(eleID,25),2) coords(ele(eleID,26),2) coords(ele(eleID,27),2)]';        
        Zcoords = [coords(ele(eleID,1),3) coords(ele(eleID,2),3) coords(ele(eleID,3),3) coords(ele(eleID,4),3) coords(ele(eleID,5),3) coords(ele(eleID,6),3) coords(ele(eleID,7),3) coords(ele(eleID,8),3) coords(ele(eleID,9),3) coords(ele(eleID,10),3) coords(ele(eleID,11),3) coords(ele(eleID,12),3) coords(ele(eleID,13),3) coords(ele(eleID,14),3) coords(ele(eleID,15),3) coords(ele(eleID,16),3) coords(ele(eleID,17),3) coords(ele(eleID,18),3) coords(ele(eleID,19),3) coords(ele(eleID,20),3) coords(ele(eleID,21),3) coords(ele(eleID,22),3) coords(ele(eleID,23),3) coords(ele(eleID,24),3) coords(ele(eleID,25),3) coords(ele(eleID,26),3) coords(ele(eleID,27),3)]';
        x0 = N*Xcoords;
        y0 = N*Ycoords;
        z0 = N*Zcoords;
        %
        Jfem11 = dNr*Xcoords;
        Jfem12 = dNs*Xcoords;
        Jfem13 = dNt*Xcoords;
        Jfem21 = dNr*Ycoords;
        Jfem22 = dNs*Ycoords;
        Jfem23 = dNt*Ycoords;
        Jfem31 = dNr*Zcoords;
        Jfem32 = dNs*Zcoords;
        Jfem33 = dNt*Zcoords;
        
        Jfem = [Jfem11 Jfem12 Jfem13;Jfem21 Jfem22 Jfem23;Jfem31 Jfem32 Jfem33];
        detJfem = det(Jfem);

        %% Update the position of the current configuration
        XcoordsCur = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1) coordsCur(ele(eleID,5),1) coordsCur(ele(eleID,6),1) coordsCur(ele(eleID,7),1) coordsCur(ele(eleID,8),1) coordsCur(ele(eleID,9),1) coordsCur(ele(eleID,10),1) coordsCur(ele(eleID,11),1) coordsCur(ele(eleID,12),1) coordsCur(ele(eleID,13),1) coordsCur(ele(eleID,14),1) coordsCur(ele(eleID,15),1) coordsCur(ele(eleID,16),1) coordsCur(ele(eleID,17),1) coordsCur(ele(eleID,18),1) coordsCur(ele(eleID,19),1) coordsCur(ele(eleID,20),1) coordsCur(ele(eleID,21),1) coordsCur(ele(eleID,22),1) coordsCur(ele(eleID,23),1) coordsCur(ele(eleID,24),1) coordsCur(ele(eleID,25),1) coordsCur(ele(eleID,26),1) coordsCur(ele(eleID,27),1)]';
        YcoordsCur = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2) coordsCur(ele(eleID,5),2) coordsCur(ele(eleID,6),2) coordsCur(ele(eleID,7),2) coordsCur(ele(eleID,8),2) coordsCur(ele(eleID,9),2) coordsCur(ele(eleID,10),2) coordsCur(ele(eleID,11),2) coordsCur(ele(eleID,12),2) coordsCur(ele(eleID,13),2) coordsCur(ele(eleID,14),2) coordsCur(ele(eleID,15),2) coordsCur(ele(eleID,16),2) coordsCur(ele(eleID,17),2) coordsCur(ele(eleID,18),2) coordsCur(ele(eleID,19),2) coordsCur(ele(eleID,20),2) coordsCur(ele(eleID,21),2) coordsCur(ele(eleID,22),2) coordsCur(ele(eleID,23),2) coordsCur(ele(eleID,24),2) coordsCur(ele(eleID,25),2) coordsCur(ele(eleID,26),2) coordsCur(ele(eleID,27),2)]';        
        ZcoordsCur = [coordsCur(ele(eleID,1),3) coordsCur(ele(eleID,2),3) coordsCur(ele(eleID,3),3) coordsCur(ele(eleID,4),3) coordsCur(ele(eleID,5),3) coordsCur(ele(eleID,6),3) coordsCur(ele(eleID,7),3) coordsCur(ele(eleID,8),3) coordsCur(ele(eleID,9),3) coordsCur(ele(eleID,10),3) coordsCur(ele(eleID,11),3) coordsCur(ele(eleID,12),3) coordsCur(ele(eleID,13),3) coordsCur(ele(eleID,14),3) coordsCur(ele(eleID,15),3) coordsCur(ele(eleID,16),3) coordsCur(ele(eleID,17),3) coordsCur(ele(eleID,18),3) coordsCur(ele(eleID,19),3) coordsCur(ele(eleID,20),3) coordsCur(ele(eleID,21),3) coordsCur(ele(eleID,22),3) coordsCur(ele(eleID,23),3) coordsCur(ele(eleID,24),3) coordsCur(ele(eleID,25),3) coordsCur(ele(eleID,26),3) coordsCur(ele(eleID,27),3)]';
        xCur = N*XcoordsCur;
        yCur = N*YcoordsCur;
        zCur = N*ZcoordsCur;

        Jfem11Cur = dNr*XcoordsCur; %dxCur/dr
        Jfem12Cur = dNs*XcoordsCur; %dxCur/ds
        Jfem13Cur = dNt*XcoordsCur; %dxCur/dt
        Jfem21Cur = dNr*YcoordsCur;
        Jfem22Cur = dNs*YcoordsCur;
        Jfem23Cur = dNt*YcoordsCur;
        Jfem31Cur = dNr*ZcoordsCur;
        Jfem32Cur = dNs*ZcoordsCur;
        Jfem33Cur = dNt*ZcoordsCur;
        
        JfemCur = [Jfem11Cur Jfem12Cur Jfem13Cur;Jfem21Cur Jfem22Cur Jfem23Cur;Jfem31Cur Jfem32Cur Jfem33Cur];
        detJfemCur = det(JfemCur);

        %calculate Fp & Fbar
        dxCurdx0dy0dz0 = inv(Jfem)'*[Jfem11Cur Jfem12Cur Jfem13Cur]';
        dyCurdx0dy0dz0 = inv(Jfem)'*[Jfem21Cur Jfem22Cur Jfem23Cur]';
        dzCurdx0dy0dz0 = inv(Jfem)'*[Jfem31Cur Jfem32Cur Jfem33Cur]';
        %
        F = [dxCurdx0dy0dz0';
             dyCurdx0dy0dz0';
             dzCurdx0dy0dz0'];
        Fbar = [diag(dxCurdx0dy0dz0)                  diag(dyCurdx0dy0dz0)                  diag(dzCurdx0dy0dz0);
                dxCurdx0dy0dz0(2) dxCurdx0dy0dz0(1) 0 dyCurdx0dy0dz0(2) dyCurdx0dy0dz0(1) 0 dzCurdx0dy0dz0(2) dzCurdx0dy0dz0(1) 0;
                0 dxCurdx0dy0dz0(3) dxCurdx0dy0dz0(2) 0 dyCurdx0dy0dz0(3) dyCurdx0dy0dz0(2) 0 dzCurdx0dy0dz0(3) dzCurdx0dy0dz0(2);
                dxCurdx0dy0dz0(3) 0 dxCurdx0dy0dz0(1) dyCurdx0dy0dz0(3) 0 dyCurdx0dy0dz0(1) dzCurdx0dy0dz0(3) 0 dzCurdx0dy0dz0(1)];
        detF = det(F);

        %left Cauchy Green tensor
%         c = F'*F;
        b = F*F';
%         EGLHat = 0.5*(c-eye(3));
%         EGL = [EGLHat(1,1) EGLHat(2,2) EGLHat(3,3) 2*EGLHat(1,2) 2*EGLHat(2,3) 2*EGLHat(3,1)]';
            
        sigmaHat = (lamda/detF)*log(detF)*eye(3) + (mu/detF)*(b-eye(3));
        sigma = [sigmaHat(1,1) sigmaHat(2,2) sigmaHat(3,3) sigmaHat(1,2) sigmaHat(2,3) sigmaHat(1,3)]';
        
        %calculate BLT
        BLT = [];
        for Nid = 1:27
            dNidxCurdyCurdzCur = inv(JfemCur)'*[dNr(Nid) dNs(Nid) dNt(Nid)]';
            BLT_Ni = [diag(dNidxCurdyCurdzCur);
                      dNidxCurdyCurdzCur(2) dNidxCurdyCurdzCur(1) 0;
                      0 dNidxCurdyCurdzCur(3) dNidxCurdyCurdzCur(2);
                      dNidxCurdyCurdzCur(3) 0 dNidxCurdyCurdzCur(1)];
            BLT = [BLT BLT_Ni]; 
        end
        
        riRes = riRes + (BLT')*sigma*detJfemCur*w;

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        riResNonDir(i) = riRes(NonDirDofs(i));    
%         riNonDir(i) = ri(NonDirDofs(i));
    end
    normRes = norm(riResNonDir-reIncrNonDir);
    conv = (normRes)/(1+norm(reIncrNonDir))
    
%     normRes2 = norm(riNonDir-reIncrNonDir);
%     conv2 = (normRes2)/(1+norm(reIncrNonDir));
end
%
    if numIter > maxIter
    
        disp(sprintf('The loadstep number %d is NOT converged',loadIncr))

    end
end


[plotLineDef, plotPointDef] = MeshDraw3D(coordsCur,ele,'msquare','-.m');

xlim auto
ylim auto



