%% Description: calculation of the constitutive tensor for the compressible NeoHookean material
% cInv: the inverse of the right Cauchy-Green strain tensor
% detF: determinant of the deformation gradient matrix
function [S, Sbar, C] = NeoHookeanCompressibleMatertial3D(detF, c, lamda,mu)
    cInv = inv(c);
    % 2nd Piola Kirchhoff stress tensor
    SHat = lamda*log(detF)*cInv + mu*(eye(3) - cInv);
    % Voight's notation vector
    S = [SHat(1,1) SHat(2,2) SHat(3,3) SHat(1,2) SHat(2,3) SHat(1,3)]';
    % FEM notation matrix
    Sbar = [SHat zeros(3,3) zeros(3,3);
            zeros(3,3) SHat zeros(3,3);
            zeros(3,3) zeros(3,3) SHat];
    
    %Constitutive tensor
    C11 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,1)^2;
    C12 = (2*mu - 2*log(detF)*lamda)*cInv(1,2)^2 + lamda*cInv(1,1)*cInv(2,2);
    C13 = (2*mu - 2*log(detF)*lamda)*cInv(3,1)^2 + lamda*cInv(1,1)*cInv(3,3);
    C14 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(1,1);
    C15 = lamda*cInv(1,1)*cInv(2,3) + 2*(mu - log(detF)*lamda)*cInv(1,2)*cInv(3,1);
    C16 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,1)*cInv(3,1);
    %
    C21 = C12;
    C22 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,2)^2;
    C23 = (2*mu - 2*log(detF)*lamda)*cInv(2,3)^2 + lamda*cInv(2,2)*cInv(3,3);
    C24 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(2,2);
    C25 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,2)*cInv(2,3);
    C26 = 2*(mu - log(detF)*lamda)*cInv(1,2)*cInv(2,3) + lamda*cInv(2,2)*cInv(3,1);
    %
    C31 = C13;
    C32 = C23;
    C33 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(3,3)^2;
    C34 = 2*(mu - log(detF)*lamda)*cInv(2,3)*cInv(3,1) + lamda*cInv(1,2)*cInv(3,3);
    C35 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(2,3)*cInv(3,3);
    C36 = (-2*log(detF)*lamda + lamda + 2*mu)*cInv(3,1)*cInv(3,3);
    %
    C41 = C14;
    C42 = C24;
    C43 = C34;
    C44 = (-log(detF)*lamda + lamda + mu)*cInv(1,2)^2 + (mu - log(detF)*lamda)*cInv(1,1)*cInv(2,2);
    C45 = (-log(detF)*lamda + lamda + mu)*cInv(1,2)*cInv(2,3) + (mu - log(detF)*lamda)*cInv(2,2)*cInv(3,1);
    C46 = (mu - log(detF)*lamda)*cInv(1,1)*cInv(2,3) + (-log(detF)*lamda + lamda + mu)*cInv(1,2)*cInv(3,1);
    %
    C51 = C15;
    C52 = C25;
    C53 = C35;
    C54 = C45;
    C55 = (-log(detF)*lamda + lamda + mu)*cInv(2,3)^2 + (mu - log(detF)*lamda)*cInv(2,2)*cInv(3,3);
    C56 = (-log(detF)*lamda + lamda + mu)*cInv(2,3)*cInv(3,1) + (mu - log(detF)*lamda)*cInv(1,2)*cInv(3,3);
    %
    C61 = C16;
    C62 = C26;
    C63 = C36;
    C64 = C46;
    C65 = C56;
    C66 = (-log(detF)*lamda + lamda + mu)*cInv(3,1)^2 + (mu - log(detF)*lamda)*cInv(1,1)*cInv(3,3);
    %
    C = [C11 C12 C13 C14 C15 C16;
         C21 C22 C23 C24 C25 C26;
         C31 C32 C33 C34 C35 C36;
         C41 C42 C43 C44 C45 C46;
         C51 C52 C53 C54 C55 C56;
         C61 C62 C63 C64 C65 C66];

end