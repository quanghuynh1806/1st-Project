%% Description: draw the mesh: nodes and elements
%% Variable description
%% Input
    % coords/coordsCur: coordinate of nodes
    % ele: a matrix with each row containing the ids of all nodes belonged
           % to the element. The row index is also the element id.
    % pointStyle & lineStyle: nodes and elements' edges visualization style
%% Output
    % plotLine: a plot contains lines representing elements' edges
    % plotPoint: a plot contains points representing elements' nodes
function [plotLine, plotPoint] = MeshDraw(coords,ele,pointStyle,lineStyle)

    [numNodes,dofNode] = size(coords);
    [numEle,NodesInElement] = size(ele);
    
    %Plot nodes
    for nodID=1:numNodes
        hold on
        plotPoint = plot(coords(nodID,1),coords(nodID,2),pointStyle,'MarkerSize', 2);
%         text(coords(nodID,1),coords(nodID,2),sprintf('%d',nodID));
    end
    
    %Plot elements
    for eleId = 1:numEle
    xCoordsPlot = [coords(ele(eleId,1),1); coords(ele(eleId,5),1); coords(ele(eleId,2),1);coords(ele(eleId,6),1);coords(ele(eleId,3),1);coords(ele(eleId,7),1);coords(ele(eleId,4),1);coords(ele(eleId,8),1);coords(ele(eleId,1),1)];
    hold on
    yCoordsPlot = [coords(ele(eleId,1),2); coords(ele(eleId,5),2); coords(ele(eleId,2),2);coords(ele(eleId,6),2);coords(ele(eleId,3),2);coords(ele(eleId,7),2);coords(ele(eleId,4),2);coords(ele(eleId,8),2);coords(ele(eleId,1),2)];
    plotLine = plot(xCoordsPlot,yCoordsPlot,lineStyle,'LineWidth',1);
    end
    
end