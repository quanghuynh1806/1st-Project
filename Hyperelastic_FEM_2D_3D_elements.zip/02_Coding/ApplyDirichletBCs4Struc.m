%% Description: Apply Dirichlet boudary condition to matrix and vector
function [KtNonDir,RiNonDir,ReIncrNonDir,KtDir,RiDir] = ApplyDirichletBCs4Struc(DirDofs,NonDirDofs,Kt,Ri,ReIncr)

for i = 1:length(NonDirDofs)

    RiNonDir(i) = Ri(NonDirDofs(i));    
    ReIncrNonDir(i) = ReIncr(NonDirDofs(i));

    for j = i:length(NonDirDofs)

        KtNonDir(i,j) = Kt(NonDirDofs(i),NonDirDofs(j));
        KtNonDir(j,i) = Kt(NonDirDofs(i),NonDirDofs(j));

    end

end

end