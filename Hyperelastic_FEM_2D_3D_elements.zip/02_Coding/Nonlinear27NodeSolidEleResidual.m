%% Description: Calculation of an internal force vector for one element with id "eleID"
%% Variable description
%% Input
        % eleID: the id of element whose stiffness matrix and load vector are
                % calculated
        % coords: a matix with each row containing x & y & z coordinates of the
                % node in the undeformed state. The row index is also the node id
        % coordsCur: a matix with each row containing x & y & z coordinates of the
                % node in the DEFORMED state. The row index is also the node id
        % ele: a matrix with each row containing the ids of all nodes belonged
                % to the element. The row index is also the element id.          
 
%% Output
        % riRes: the elemental internal load vector for the convergence
            % check
        % indx: indices of element's dofs of associated nodes
        % sigma: cauchy stress tensor

function [riRes,indx,sigma] = Nonlinear27NodeSolidEleResidual(eleID,ele,coords,coordsCur,E,nu,MAT)

lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
indx = [ele(eleID,1)*3-2 ele(eleID,1)*3-1 ele(eleID,1)*3 ele(eleID,2)*3-2 ele(eleID,2)*3-1 ele(eleID,2)*3 ele(eleID,3)*3-2 ele(eleID,3)*3-1 ele(eleID,3)*3 ele(eleID,4)*3-2 ele(eleID,4)*3-1 ele(eleID,4)*3 ele(eleID,5)*3-2 ele(eleID,5)*3-1 ele(eleID,5)*3 ele(eleID,6)*3-2 ele(eleID,6)*3-1 ele(eleID,6)*3 ele(eleID,7)*3-2 ele(eleID,7)*3-1 ele(eleID,7)*3 ele(eleID,8)*3-2 ele(eleID,8)*3-1 ele(eleID,8)*3 ele(eleID,9)*3-2 ele(eleID,9)*3-1 ele(eleID,9)*3 ele(eleID,10)*3-2 ele(eleID,10)*3-1 ele(eleID,10)*3 ele(eleID,11)*3-2 ele(eleID,11)*3-1 ele(eleID,11)*3 ele(eleID,12)*3-2 ele(eleID,12)*3-1 ele(eleID,12)*3 ele(eleID,13)*3-2 ele(eleID,13)*3-1 ele(eleID,13)*3 ele(eleID,14)*3-2 ele(eleID,14)*3-1 ele(eleID,14)*3 ele(eleID,15)*3-2 ele(eleID,15)*3-1 ele(eleID,15)*3 ele(eleID,16)*3-2 ele(eleID,16)*3-1 ele(eleID,16)*3 ele(eleID,17)*3-2 ele(eleID,17)*3-1 ele(eleID,17)*3 ele(eleID,18)*3-2 ele(eleID,18)*3-1 ele(eleID,18)*3 ele(eleID,19)*3-2 ele(eleID,19)*3-1 ele(eleID,19)*3 ele(eleID,20)*3-2 ele(eleID,20)*3-1 ele(eleID,20)*3 ele(eleID,21)*3-2 ele(eleID,21)*3-1 ele(eleID,21)*3 ele(eleID,22)*3-2 ele(eleID,22)*3-1 ele(eleID,22)*3 ele(eleID,23)*3-2 ele(eleID,23)*3-1 ele(eleID,23)*3 ele(eleID,24)*3-2 ele(eleID,24)*3-1 ele(eleID,24)*3 ele(eleID,25)*3-2 ele(eleID,25)*3-1 ele(eleID,25)*3 ele(eleID,26)*3-2 ele(eleID,26)*3-1 ele(eleID,26)*3 ele(eleID,27)*3-2 ele(eleID,27)*3-1 ele(eleID,27)*3]; 
%Gauss Quadrature 3D
GaussQuadraticSolid = [-0.774597 -0.774597 -0.774597 0.171468; %1
                       -0.774597 -0.774597  0        0.274348; %2
                       -0.774597 -0.774597  0.774597 0.171468; %3
                       -0.774597  0        -0.774597 0.274348; %4
                       -0.774597  0         0        0.438957; %5
                       -0.774597  0         0.774597 0.274348; %6
                       -0.774597  0.774597 -0.774597 0.171468; %7
                       -0.774597  0.774597  0        0.274348; %8
                       -0.774597  0.774597  0.774597 0.171468; %9
                        0        -0.774597 -0.774597 0.274348; %10
                        0        -0.774597  0        0.438957; %11
                        0        -0.774597  0.774597 0.274348; %12
                        0         0        -0.774597 0.438957; %13
                        0         0         0        0.702332; %14
                        0         0         0.774597 0.438957; %15
                        0         0.774597 -0.774597 0.274348; %16
                        0         0.774597  0        0.438957; %17
                        0         0.774597  0.774597 0.274348; %18
                        0.774597 -0.774597 -0.774597 0.171468; %19
                        0.774597 -0.774597  0        0.274348; %20
                        0.774597 -0.774597  0.774597 0.171468; %21
                        0.774597  0        -0.774597 0.274348; %22
                        0.774597  0         0        0.438957; %23
                        0.774597  0         0.774597 0.274348; %24
                        0.774597  0.774597 -0.774597 0.171468; %25
                        0.774597  0.774597  0        0.274348; %26
                        0.774597  0.774597  0.774597 0.171468  %27
                       ];
[nGaQuadSolid, m]=size(GaussQuadraticSolid);

%% Initialization of shape functions and partial derivatives
N1=zeros(nGaQuadSolid,1);
N2=zeros(nGaQuadSolid,1);
N3=zeros(nGaQuadSolid,1);
N4=zeros(nGaQuadSolid,1);
N5=zeros(nGaQuadSolid,1);
N6=zeros(nGaQuadSolid,1);
N7=zeros(nGaQuadSolid,1);
N8=zeros(nGaQuadSolid,1);
N9=zeros(nGaQuadSolid,1);
N10=zeros(nGaQuadSolid,1);
N11=zeros(nGaQuadSolid,1);
N12=zeros(nGaQuadSolid,1);
N13=zeros(nGaQuadSolid,1);
N14=zeros(nGaQuadSolid,1);
N15=zeros(nGaQuadSolid,1);
N16=zeros(nGaQuadSolid,1);
N17=zeros(nGaQuadSolid,1);
N18=zeros(nGaQuadSolid,1);
N19=zeros(nGaQuadSolid,1);
N20=zeros(nGaQuadSolid,1);
N21=zeros(nGaQuadSolid,1);
N22=zeros(nGaQuadSolid,1);
N23=zeros(nGaQuadSolid,1);
N24=zeros(nGaQuadSolid,1);
N25=zeros(nGaQuadSolid,1);
N26=zeros(nGaQuadSolid,1);
N27=zeros(nGaQuadSolid,1);
%
dN1r=zeros(nGaQuadSolid,1);
dN2r=zeros(nGaQuadSolid,1);
dN3r=zeros(nGaQuadSolid,1);
dN4r=zeros(nGaQuadSolid,1);
dN5r=zeros(nGaQuadSolid,1);
dN6r=zeros(nGaQuadSolid,1);
dN7r=zeros(nGaQuadSolid,1);
dN8r=zeros(nGaQuadSolid,1);
dN9r=zeros(nGaQuadSolid,1);
dN10r=zeros(nGaQuadSolid,1);
dN11r=zeros(nGaQuadSolid,1);
dN12r=zeros(nGaQuadSolid,1);
dN13r=zeros(nGaQuadSolid,1);
dN14r=zeros(nGaQuadSolid,1);
dN15r=zeros(nGaQuadSolid,1);
dN16r=zeros(nGaQuadSolid,1);
dN17r=zeros(nGaQuadSolid,1);
dN18r=zeros(nGaQuadSolid,1);
dN19r=zeros(nGaQuadSolid,1);
dN20r=zeros(nGaQuadSolid,1);
dN21r=zeros(nGaQuadSolid,1);
dN22r=zeros(nGaQuadSolid,1);
dN23r=zeros(nGaQuadSolid,1);
dN24r=zeros(nGaQuadSolid,1);
dN25r=zeros(nGaQuadSolid,1);
dN26r=zeros(nGaQuadSolid,1);
dN27r=zeros(nGaQuadSolid,1);
%
dN1s=zeros(nGaQuadSolid,1);
dN2s=zeros(nGaQuadSolid,1);
dN3s=zeros(nGaQuadSolid,1);
dN4s=zeros(nGaQuadSolid,1);
dN5s=zeros(nGaQuadSolid,1);
dN6s=zeros(nGaQuadSolid,1);
dN7s=zeros(nGaQuadSolid,1);
dN8s=zeros(nGaQuadSolid,1);
dN9s=zeros(nGaQuadSolid,1);
dN10s=zeros(nGaQuadSolid,1);
dN11s=zeros(nGaQuadSolid,1);
dN12s=zeros(nGaQuadSolid,1);
dN13s=zeros(nGaQuadSolid,1);
dN14s=zeros(nGaQuadSolid,1);
dN15s=zeros(nGaQuadSolid,1);
dN16s=zeros(nGaQuadSolid,1);
dN17s=zeros(nGaQuadSolid,1);
dN18s=zeros(nGaQuadSolid,1);
dN19s=zeros(nGaQuadSolid,1);
dN20s=zeros(nGaQuadSolid,1);
dN21s=zeros(nGaQuadSolid,1);
dN22s=zeros(nGaQuadSolid,1);
dN23s=zeros(nGaQuadSolid,1);
dN24s=zeros(nGaQuadSolid,1);
dN25s=zeros(nGaQuadSolid,1);
dN26s=zeros(nGaQuadSolid,1);
dN27s=zeros(nGaQuadSolid,1);
%
dN1t=zeros(nGaQuadSolid,1);
dN2t=zeros(nGaQuadSolid,1);
dN3t=zeros(nGaQuadSolid,1);
dN4t=zeros(nGaQuadSolid,1);
dN5t=zeros(nGaQuadSolid,1);
dN6t=zeros(nGaQuadSolid,1);
dN7t=zeros(nGaQuadSolid,1);
dN8t=zeros(nGaQuadSolid,1);
dN9t=zeros(nGaQuadSolid,1);
dN10t=zeros(nGaQuadSolid,1);
dN11t=zeros(nGaQuadSolid,1);
dN12t=zeros(nGaQuadSolid,1);
dN13t=zeros(nGaQuadSolid,1);
dN14t=zeros(nGaQuadSolid,1);
dN15t=zeros(nGaQuadSolid,1);
dN16t=zeros(nGaQuadSolid,1);
dN17t=zeros(nGaQuadSolid,1);
dN18t=zeros(nGaQuadSolid,1);
dN19t=zeros(nGaQuadSolid,1);
dN20t=zeros(nGaQuadSolid,1);
dN21t=zeros(nGaQuadSolid,1);
dN22t=zeros(nGaQuadSolid,1);
dN23t=zeros(nGaQuadSolid,1);
dN24t=zeros(nGaQuadSolid,1);
dN25t=zeros(nGaQuadSolid,1);
dN26t=zeros(nGaQuadSolid,1);
dN27t=zeros(nGaQuadSolid,1);

%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaQuadSolid
    
    r = GaussQuadraticSolid(i,1);
    s = GaussQuadraticSolid(i,2);
    t = GaussQuadraticSolid(i,3);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.125*r*(r-1)*s*(s-1)*t*(t-1); 
    N2(i) = 0.125*r*(r+1)*s*(s-1)*t*(t-1); 
    N3(i) = 0.125*r*(r+1)*s*(s+1)*t*(t-1); 
    N4(i) = 0.125*r*(r-1)*s*(s+1)*t*(t-1);
    N5(i) = 0.125*r*(r-1)*s*(s-1)*t*(t+1);
    N6(i) = 0.125*r*(r+1)*s*(s-1)*t*(t+1);
    N7(i) = 0.125*r*(r+1)*s*(s+1)*t*(t+1);
    N8(i) = 0.125*r*(r-1)*s*(s+1)*t*(t+1);
    N9(i) = 0.25*(1-r^2)*s*(s-1)*t*(t-1);
    N10(i) = 0.25*r*(r+1)*(1-s^2)*t*(t-1);
    N11(i) = 0.25*(1-r^2)*s*(s+1)*t*(t-1);
    N12(i) = 0.25*r*(r-1)*(1-s^2)*t*(t-1);
    N13(i) = 0.25*(1-r^2)*s*(s-1)*t*(t+1);
    N14(i) = 0.25*r*(r+1)*(1-s^2)*t*(t+1);
    N15(i) = 0.25*(1-r^2)*s*(s+1)*t*(t+1);
    N16(i) = 0.25*r*(r-1)*(1-s^2)*t*(t+1);
    N17(i) = 0.25*r*(r-1)*s*(s-1)*(1-t^2);
    N18(i) = 0.25*r*(r+1)*s*(s-1)*(1-t^2);
    N19(i) = 0.25*r*(r+1)*s*(s+1)*(1-t^2);
    N20(i) = 0.25*r*(r-1)*s*(s+1)*(1-t^2);
    N21(i) = 0.5*(1-r^2)*(1-s^2)*t*(t-1);
    N22(i) = 0.5*(1-r^2)*(1-s^2)*t*(t+1);
    N23(i) = 0.5*(1-r^2)*s*(s-1)*(1-t^2);
    N24(i) = 0.5*r*(r+1)*(1-s^2)*(1-t^2);
    N25(i) = 0.5*(1-r^2)*s*(s+1)*(1-t^2);
    N26(i) = 0.5*r*(r-1)*(1-s^2)*(1-t^2);
    N27(i) = (1-r^2)*(1-s^2)*(1-t^2);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN2r(i) = 0.25*(0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN3r(i) = 0.25*(0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN4r(i) = 0.25*(-0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN5r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*t*(1+t);
    dN6r(i) = 0.25*(0.5+1*r)*(-1+s)*s*t*(1+t);
    dN7r(i) = 0.25*(0.5+1*r)*s*(1+s)*t*(1+t);
    dN8r(i) = 0.25*(-0.5+1*r)*s*(1+s)*t*(1+t);
    dN9r(i) = -0.5*r*(-1+s)*s*(-1+t)*t;
    dN10r(i) = -0.5*(0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN11r(i) = -0.5*r*s*(1+s)*(-1+t)*t;
    dN12r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN13r(i) = -0.5*r*(-1+s)*s*t*(1+t);
    dN14r(i) = -0.5*(0.5+1*r)*(-1+s^2)*t*(1+t);
    dN15r(i) = -0.5*r*s*(1+s)*t*(1+t);
    dN16r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*t*(1+t);
    dN17r(i) = -0.5*(-0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN18r(i) = -0.5*(0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN19r(i) = -0.5*(0.5+1*r)*s*(1+s)*(-1+t^2);
    dN20r(i) = -0.5*(-0.5+1*r)*s*(1+s)*(-1+t^2);
    dN21r(i) = 1*r*(-1+s^2)*(-1+t)*t;
    dN22r(i) = 1*r*(-1+s^2)*t*(1+t);
    dN23r(i) = 1*r*(-1+s)*s*(-1+t^2);
    dN24r(i) = 1*(0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN25r(i) = 1*r*s*(1+s)*(-1+t^2);
    dN26r(i) = 1*(-0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN27r(i) = -2*r*(-1+s^2)*(-1+t^2);
    %
    dN1s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*(-1+t)*t;
    dN2s(i) = 0.25*r*(1+r)*(-0.5+1*s)*(-1+t)*t;
    dN3s(i) = 0.25*r*(1+r)*(0.5+1*s)*(-1+t)*t;
    dN4s(i) = 0.25*(-1+r)*r*(0.5+1*s)*(-1+t)*t;
    dN5s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*t*(1+t);
    dN6s(i) = 0.25*r*(1+r)*(-0.5+1*s)*t*(1+t);
    dN7s(i) = 0.25*r*(1+r)*(0.5+1*s)*t*(1+t);
    dN8s(i) = 0.25*(-1+r)*r*(0.5+1*s)*t*(1+t);
    dN9s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*(-1+t)*t;
    dN10s(i) = -0.5*r*(1+r)*s*(-1+t)*t;
    dN11s(i) = -0.5*(-1+r^2)*(0.5+1*s)*(-1+t)*t;
    dN12s(i) = -0.5*(-1+r)*r*s*(-1+t)*t;
    dN13s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*t*(1+t);
    dN14s(i) = -0.5*r*(1+r)*s*t*(1+t);
    dN15s(i) = -0.5*(-1+r^2)*(0.5+1*s)*t*(1+t);
    dN16s(i) = -0.5*(-1+r)*r*s*t*(1+t);
    dN17s(i) = -0.5*(-1+r)*r*(-0.5+1*s)*(-1+t^2);
    dN18s(i) = -0.5*r*(1+r)*(-0.5+1*s)*(-1+t^2);
    dN19s(i) = -0.5*r*(1+r)*(0.5+1*s)*(-1+t^2);
    dN20s(i) = -0.5*(-1+r)*r*(0.5+1*s)*(-1+t^2);
    dN21s(i) = 1*(-1+r^2)*s*(-1+t)*t;
    dN22s(i) = 1*(-1+r^2)*s*t*(1+t);
    dN23s(i) = 1*(-1+r^2)*(-0.5+1*s)*(-1+t^2);
    dN24s(i) = 1*r*(1+r)*s*(-1+t^2);
    dN25s(i) = 1*(-1+r^2)*(0.5+1*s)*(-1+t^2);
    dN26s(i) = 1*(-1+r)*r*s*(-1+t^2);
    dN27s(i) = -2*(-1+r^2)*s*(-1+t^2);
    %
    dN1t(i) = 0.25*(-1+r)*r*(-1+s)*s*(-0.5+1*t);
    dN2t(i) = 0.25*r*(1+r)*(-1+s)*s*(-0.5+1*t);
    dN3t(i) = 0.25*r*(1+r)*s*(1+s)*(-0.5+1*t);
    dN4t(i) = 0.25*(-1+r)*r*s*(1+s)*(-0.5+1*t);
    dN5t(i) = 0.25*(-1+r)*r*(-1+s)*s*(0.5+1*t);
    dN6t(i) = 0.25*r*(1+r)*(-1+s)*s*(0.5+1*t);
    dN7t(i) = 0.25*r*(1+r)*s*(1+s)*(0.5+1*t);
    dN8t(i) = 0.25*(-1+r)*r*s*(1+s)*(0.5+1*t);
    dN9t(i) = -0.5*(-1+r^2)*(-1+s)*s*(-0.5+1*t);
    dN10t(i) = -0.5*r*(1+r)*(-1+s^2)*(-0.5+1*t);
    dN11t(i) = -0.5*(-1+r^2)*s*(1+s)*(-0.5+1*t);
    dN12t(i) = -0.5*(-1+r)*r*(-1+s^2)*(-0.5+1*t);
    dN13t(i) = -0.5*(-1+r^2)*(-1+s)*s*(0.5+1*t);
    dN14t(i) = -0.5*r*(1+r)*(-1+s^2)*(0.5+1*t);
    dN15t(i) = -0.5*(-1+r^2)*s*(1+s)*(0.5+1*t);
    dN16t(i) = -0.5*(-1+r)*r*(-1+s^2)*(0.5+1*t);
    dN17t(i) = -0.5*(-1+r)*r*(-1+s)*s*t;
    dN18t(i) = -0.5*r*(1+r)*(-1+s)*s*t;
    dN19t(i) = -0.5*r*(1+r)*s*(1+s)*t;
    dN20t(i) = -0.5*(-1+r)*r*s*(1+s)*t;
    dN21t(i) = 1*(-1+r^2)*(-1+s^2)*(-0.5+1*t);
    dN22t(i) = 1*(-1+r^2)*(-1+s^2)*(0.5+1*t);
    dN23t(i) = 1*(-1+r^2)*(-1+s)*s*t;
    dN24t(i) = 1*r*(1+r)*(-1+s^2)*t;
    dN25t(i) = 1*(-1+r^2)*s*(1+s)*t;
    dN26t(i) = 1*(-1+r)*r*(-1+s^2)*t;
    dN27t(i) = -2*(-1+r^2)*(-1+s^2)*t;
end

%Initialization of the variables
%mapping from initial to master
Jfem = zeros(3);
%mapping from current to master
JfemCur = zeros(3);
%planar deformation gradient tensor
F = zeros(3);
%deformation gradient matrix in FEM style
Fbar = zeros(6,9);
%strain matrix
BT = zeros(9,27*3);
%internal force vector for residual check
riRes = zeros(27*3,1);

for i = 1:nGaQuadSolid
    % Shape functions evaluated at Gauss point i
    N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i) N10(i) N11(i) N12(i) N13(i) N14(i) N15(i) N16(i) N17(i) N18(i) N19(i) N20(i) N21(i) N22(i) N23(i) N24(i) N25(i) N26(i) N27(i)];
    w = GaussQuadraticSolid(i,4);

    % Partial derivatives of the shape functions evaluated at Gauss point
    dNr = [dN1r(i) dN2r(i) dN3r(i) dN4r(i) dN5r(i) dN6r(i) dN7r(i) dN8r(i) dN9r(i) dN10r(i) dN11r(i) dN12r(i) dN13r(i) dN14r(i) dN15r(i) dN16r(i) dN17r(i) dN18r(i) dN19r(i) dN20r(i) dN21r(i) dN22r(i) dN23r(i) dN24r(i) dN25r(i) dN26r(i) dN27r(i)];
    dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i) dN10s(i) dN11s(i) dN12s(i) dN13s(i) dN14s(i) dN15s(i) dN16s(i) dN17s(i) dN18s(i) dN19s(i) dN20s(i) dN21s(i) dN22s(i) dN23s(i) dN24s(i) dN25s(i) dN26s(i) dN27s(i)];
    dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i) dN10t(i) dN11t(i) dN12t(i) dN13t(i) dN14t(i) dN15t(i) dN16t(i) dN17t(i) dN18t(i) dN19t(i) dN20t(i) dN21t(i) dN22t(i) dN23t(i) dN24t(i) dN25t(i) dN26t(i) dN27t(i)];

    % Initial Configuration's quantities evaluated at Gauss point
    % The FEM mapping
    Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1) coords(ele(eleID,5),1) coords(ele(eleID,6),1) coords(ele(eleID,7),1) coords(ele(eleID,8),1) coords(ele(eleID,9),1) coords(ele(eleID,10),1) coords(ele(eleID,11),1) coords(ele(eleID,12),1) coords(ele(eleID,13),1) coords(ele(eleID,14),1) coords(ele(eleID,15),1) coords(ele(eleID,16),1) coords(ele(eleID,17),1) coords(ele(eleID,18),1) coords(ele(eleID,19),1) coords(ele(eleID,20),1) coords(ele(eleID,21),1) coords(ele(eleID,22),1) coords(ele(eleID,23),1) coords(ele(eleID,24),1) coords(ele(eleID,25),1) coords(ele(eleID,26),1) coords(ele(eleID,27),1)]';
    Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2) coords(ele(eleID,5),2) coords(ele(eleID,6),2) coords(ele(eleID,7),2) coords(ele(eleID,8),2) coords(ele(eleID,9),2) coords(ele(eleID,10),2) coords(ele(eleID,11),2) coords(ele(eleID,12),2) coords(ele(eleID,13),2) coords(ele(eleID,14),2) coords(ele(eleID,15),2) coords(ele(eleID,16),2) coords(ele(eleID,17),2) coords(ele(eleID,18),2) coords(ele(eleID,19),2) coords(ele(eleID,20),2) coords(ele(eleID,21),2) coords(ele(eleID,22),2) coords(ele(eleID,23),2) coords(ele(eleID,24),2) coords(ele(eleID,25),2) coords(ele(eleID,26),2) coords(ele(eleID,27),2)]';        
    Zcoords = [coords(ele(eleID,1),3) coords(ele(eleID,2),3) coords(ele(eleID,3),3) coords(ele(eleID,4),3) coords(ele(eleID,5),3) coords(ele(eleID,6),3) coords(ele(eleID,7),3) coords(ele(eleID,8),3) coords(ele(eleID,9),3) coords(ele(eleID,10),3) coords(ele(eleID,11),3) coords(ele(eleID,12),3) coords(ele(eleID,13),3) coords(ele(eleID,14),3) coords(ele(eleID,15),3) coords(ele(eleID,16),3) coords(ele(eleID,17),3) coords(ele(eleID,18),3) coords(ele(eleID,19),3) coords(ele(eleID,20),3) coords(ele(eleID,21),3) coords(ele(eleID,22),3) coords(ele(eleID,23),3) coords(ele(eleID,24),3) coords(ele(eleID,25),3) coords(ele(eleID,26),3) coords(ele(eleID,27),3)]';
%     x0 = N*Xcoords;
%     y0 = N*Ycoords;
%     z0 = N*Zcoords;

    Jfem11 = dNr*Xcoords;
    Jfem12 = dNs*Xcoords;
    Jfem13 = dNt*Xcoords;
    Jfem21 = dNr*Ycoords;
    Jfem22 = dNs*Ycoords;
    Jfem23 = dNt*Ycoords;
    Jfem31 = dNr*Zcoords;
    Jfem32 = dNs*Zcoords;
    Jfem33 = dNt*Zcoords;

    Jfem = [Jfem11 Jfem12 Jfem13;
            Jfem21 Jfem22 Jfem23;
            Jfem31 Jfem32 Jfem33];
    detJfem = det(Jfem);

    %% Update the position of the current configuration
    XcoordsCur = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1) coordsCur(ele(eleID,5),1) coordsCur(ele(eleID,6),1) coordsCur(ele(eleID,7),1) coordsCur(ele(eleID,8),1) coordsCur(ele(eleID,9),1) coordsCur(ele(eleID,10),1) coordsCur(ele(eleID,11),1) coordsCur(ele(eleID,12),1) coordsCur(ele(eleID,13),1) coordsCur(ele(eleID,14),1) coordsCur(ele(eleID,15),1) coordsCur(ele(eleID,16),1) coordsCur(ele(eleID,17),1) coordsCur(ele(eleID,18),1) coordsCur(ele(eleID,19),1) coordsCur(ele(eleID,20),1) coordsCur(ele(eleID,21),1) coordsCur(ele(eleID,22),1) coordsCur(ele(eleID,23),1) coordsCur(ele(eleID,24),1) coordsCur(ele(eleID,25),1) coordsCur(ele(eleID,26),1) coordsCur(ele(eleID,27),1)]';
    YcoordsCur = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2) coordsCur(ele(eleID,5),2) coordsCur(ele(eleID,6),2) coordsCur(ele(eleID,7),2) coordsCur(ele(eleID,8),2) coordsCur(ele(eleID,9),2) coordsCur(ele(eleID,10),2) coordsCur(ele(eleID,11),2) coordsCur(ele(eleID,12),2) coordsCur(ele(eleID,13),2) coordsCur(ele(eleID,14),2) coordsCur(ele(eleID,15),2) coordsCur(ele(eleID,16),2) coordsCur(ele(eleID,17),2) coordsCur(ele(eleID,18),2) coordsCur(ele(eleID,19),2) coordsCur(ele(eleID,20),2) coordsCur(ele(eleID,21),2) coordsCur(ele(eleID,22),2) coordsCur(ele(eleID,23),2) coordsCur(ele(eleID,24),2) coordsCur(ele(eleID,25),2) coordsCur(ele(eleID,26),2) coordsCur(ele(eleID,27),2)]';        
    ZcoordsCur = [coordsCur(ele(eleID,1),3) coordsCur(ele(eleID,2),3) coordsCur(ele(eleID,3),3) coordsCur(ele(eleID,4),3) coordsCur(ele(eleID,5),3) coordsCur(ele(eleID,6),3) coordsCur(ele(eleID,7),3) coordsCur(ele(eleID,8),3) coordsCur(ele(eleID,9),3) coordsCur(ele(eleID,10),3) coordsCur(ele(eleID,11),3) coordsCur(ele(eleID,12),3) coordsCur(ele(eleID,13),3) coordsCur(ele(eleID,14),3) coordsCur(ele(eleID,15),3) coordsCur(ele(eleID,16),3) coordsCur(ele(eleID,17),3) coordsCur(ele(eleID,18),3) coordsCur(ele(eleID,19),3) coordsCur(ele(eleID,20),3) coordsCur(ele(eleID,21),3) coordsCur(ele(eleID,22),3) coordsCur(ele(eleID,23),3) coordsCur(ele(eleID,24),3) coordsCur(ele(eleID,25),3) coordsCur(ele(eleID,26),3) coordsCur(ele(eleID,27),3)]';
%     xCur = N*XcoordsCur;
%     yCur = N*YcoordsCur;
%     zCur = N*ZcoordsCur;

    Jfem11Cur = dNr*XcoordsCur; %dxCur/dr
    Jfem12Cur = dNs*XcoordsCur; %dxCur/ds
    Jfem13Cur = dNt*XcoordsCur; %dxCur/dt
    Jfem21Cur = dNr*YcoordsCur;
    Jfem22Cur = dNs*YcoordsCur;
    Jfem23Cur = dNt*YcoordsCur;
    Jfem31Cur = dNr*ZcoordsCur;
    Jfem32Cur = dNs*ZcoordsCur;
    Jfem33Cur = dNt*ZcoordsCur;

    JfemCur = [Jfem11Cur Jfem12Cur Jfem13Cur;
               Jfem21Cur Jfem22Cur Jfem23Cur;
               Jfem31Cur Jfem32Cur Jfem33Cur];
    detJfemCur = det(JfemCur);

    %% calculate F  & Fbar
    dxCurdx0dy0dz0 = inv(Jfem)'*[Jfem11Cur Jfem12Cur Jfem13Cur]';
    dyCurdx0dy0dz0 = inv(Jfem)'*[Jfem21Cur Jfem22Cur Jfem23Cur]';
    dzCurdx0dy0dz0 = inv(Jfem)'*[Jfem31Cur Jfem32Cur Jfem33Cur]';
    %deformation gradient
    F = [dxCurdx0dy0dz0';
         dyCurdx0dy0dz0';
         dzCurdx0dy0dz0'];
    Fbar = [diag(dxCurdx0dy0dz0)                  diag(dyCurdx0dy0dz0)                  diag(dzCurdx0dy0dz0);
            dxCurdx0dy0dz0(2) dxCurdx0dy0dz0(1) 0 dyCurdx0dy0dz0(2) dyCurdx0dy0dz0(1) 0 dzCurdx0dy0dz0(2) dzCurdx0dy0dz0(1) 0;
            0 dxCurdx0dy0dz0(3) dxCurdx0dy0dz0(2) 0 dyCurdx0dy0dz0(3) dyCurdx0dy0dz0(2) 0 dzCurdx0dy0dz0(3) dzCurdx0dy0dz0(2);
            dxCurdx0dy0dz0(3) 0 dxCurdx0dy0dz0(1) dyCurdx0dy0dz0(3) 0 dyCurdx0dy0dz0(1) dzCurdx0dy0dz0(3) 0 dzCurdx0dy0dz0(1)];
    detF = det(F);
    
    if strcmp(MAT,'NeoHookean') == 1
    %% Hyperelastic
        %left Cauchy Green tensor
        b = F*F';
        traceBBar = trace(b)/(detF^(2/3))
        sigmaHat = (lamda/detF)*log(detF)*eye(3) + (mu/detF)*(b-eye(3));
        sigma = [sigmaHat(1,1) sigmaHat(2,2) sigmaHat(3,3) sigmaHat(1,2) sigmaHat(2,3) sigmaHat(1,3)]';
    end
    
    %calculate BLT
    BLT = [];
    for Nid = 1:27
        dNidxCurdyCurdzCur = inv(JfemCur)'*[dNr(Nid) dNs(Nid) dNt(Nid)]';
        BLT_Ni = [diag(dNidxCurdyCurdzCur);
                  dNidxCurdyCurdzCur(2) dNidxCurdyCurdzCur(1) 0;
                  0 dNidxCurdyCurdzCur(3) dNidxCurdyCurdzCur(2);
                  dNidxCurdyCurdzCur(3) 0 dNidxCurdyCurdzCur(1)];
        BLT = [BLT BLT_Ni]; 
    end

    riRes = riRes + (BLT')*sigma*detJfemCur*w;

end


end