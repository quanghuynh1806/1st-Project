%% Description: draw the mesh: nodes and elements
%% Variable description
%% Input
    % coords/coordsCur: coordinate of nodes
    % ele: a matrix with each row containing the ids of all nodes belonged
           % to the element. The row index is also the element id.
    % pointStyle & lineStyle: nodes and elements' edges visualization style
%% Output
    % plotLine: a plot contains lines representing elements' edges
    % plotPoint: a plot contains points representing elements' nodes
function [plotLine, plotPoint] = MeshDraw3D(coords,ele,pointStyle,lineStyle)

    [numNodes,dofNode] = size(coords);
    [numEle,NodesInElement] = size(ele);
    
    %Plot nodes
    for nodID=1:numNodes
        hold on
        plotPoint = plot3(coords(nodID,1),coords(nodID,2),coords(nodID,3),pointStyle,'MarkerSize', 10);
%         text(coords(nodID,1),coords(nodID,2),coords(nodID,3),sprintf('%d',nodID));
    end
    
    %Plot elements
    for eleId = 1:numEle
    hold on
    xCoordsPlot1 = [coords(ele(eleId,1),1); coords(ele(eleId,9),1); coords(ele(eleId,2),1);coords(ele(eleId,10),1);coords(ele(eleId,3),1);coords(ele(eleId,11),1);coords(ele(eleId,4),1);coords(ele(eleId,12),1);coords(ele(eleId,1),1)];
    yCoordsPlot1 = [coords(ele(eleId,1),2); coords(ele(eleId,9),2); coords(ele(eleId,2),2);coords(ele(eleId,10),2);coords(ele(eleId,3),2);coords(ele(eleId,11),2);coords(ele(eleId,4),2);coords(ele(eleId,12),2);coords(ele(eleId,1),2)];
    zCoordsPlot1 = [coords(ele(eleId,1),3); coords(ele(eleId,9),3); coords(ele(eleId,2),3);coords(ele(eleId,10),3);coords(ele(eleId,3),3);coords(ele(eleId,11),3);coords(ele(eleId,4),3);coords(ele(eleId,12),3);coords(ele(eleId,1),3)];
    plotLine1 = plot3(xCoordsPlot1,yCoordsPlot1,zCoordsPlot1,lineStyle,'LineWidth',2); 
    xCoordsPlot2 = [coords(ele(eleId,5),1); coords(ele(eleId,13),1); coords(ele(eleId,6),1);coords(ele(eleId,14),1);coords(ele(eleId,7),1);coords(ele(eleId,15),1);coords(ele(eleId,8),1);coords(ele(eleId,16),1);coords(ele(eleId,5),1)];
    yCoordsPlot2 = [coords(ele(eleId,5),2); coords(ele(eleId,13),2); coords(ele(eleId,6),2);coords(ele(eleId,14),2);coords(ele(eleId,7),2);coords(ele(eleId,15),2);coords(ele(eleId,8),2);coords(ele(eleId,16),2);coords(ele(eleId,5),2)];
    zCoordsPlot2 = [coords(ele(eleId,5),3); coords(ele(eleId,13),3); coords(ele(eleId,6),3);coords(ele(eleId,14),3);coords(ele(eleId,7),3);coords(ele(eleId,15),3);coords(ele(eleId,8),3);coords(ele(eleId,16),3);coords(ele(eleId,5),3)];
    plotLine2 = plot3(xCoordsPlot2,yCoordsPlot2,zCoordsPlot2,lineStyle,'LineWidth',2);
    xCoordsPlot3 = [coords(ele(eleId,1),1); coords(ele(eleId,9),1); coords(ele(eleId,2),1);coords(ele(eleId,18),1);coords(ele(eleId,6),1);coords(ele(eleId,13),1);coords(ele(eleId,5),1);coords(ele(eleId,17),1);coords(ele(eleId,1),1)];
    yCoordsPlot3 = [coords(ele(eleId,1),2); coords(ele(eleId,9),2); coords(ele(eleId,2),2);coords(ele(eleId,18),2);coords(ele(eleId,6),2);coords(ele(eleId,13),2);coords(ele(eleId,5),2);coords(ele(eleId,17),2);coords(ele(eleId,1),2)];
    zCoordsPlot3 = [coords(ele(eleId,1),3); coords(ele(eleId,9),3); coords(ele(eleId,2),3);coords(ele(eleId,18),3);coords(ele(eleId,6),3);coords(ele(eleId,13),3);coords(ele(eleId,5),3);coords(ele(eleId,17),3);coords(ele(eleId,1),3)];
    plotLine3 = plot3(xCoordsPlot3,yCoordsPlot3,zCoordsPlot3,lineStyle,'LineWidth',2);
    xCoordsPlot4 = [coords(ele(eleId,2),1); coords(ele(eleId,10),1); coords(ele(eleId,3),1);coords(ele(eleId,19),1);coords(ele(eleId,7),1)];
    yCoordsPlot4 = [coords(ele(eleId,2),2); coords(ele(eleId,10),2); coords(ele(eleId,3),2);coords(ele(eleId,19),2);coords(ele(eleId,7),2)];
    zCoordsPlot4 = [coords(ele(eleId,2),3); coords(ele(eleId,10),3); coords(ele(eleId,3),3);coords(ele(eleId,19),3);coords(ele(eleId,7),3)];
    plotLine4 = plot3(xCoordsPlot4,yCoordsPlot4,zCoordsPlot4,lineStyle,'LineWidth',2);
    xCoordsPlot5 = [coords(ele(eleId,4),1); coords(ele(eleId,20),1); coords(ele(eleId,8),1)];
    yCoordsPlot5 = [coords(ele(eleId,4),2); coords(ele(eleId,20),2); coords(ele(eleId,8),2)];
    zCoordsPlot5 = [coords(ele(eleId,4),3); coords(ele(eleId,20),3); coords(ele(eleId,8),3)];
    plotLine5 = plot3(xCoordsPlot5,yCoordsPlot5,zCoordsPlot5,lineStyle,'LineWidth',2);
  
    plotLine = [plotLine1 plotLine2 plotLine3 plotLine4 plotLine5];
    end
    
end