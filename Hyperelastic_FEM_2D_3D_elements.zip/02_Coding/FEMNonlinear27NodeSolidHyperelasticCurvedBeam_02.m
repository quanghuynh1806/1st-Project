clc
clear all
%% Material's properties
Bulk = 120.291;
Shear = 80.194;
nu = (3*Bulk-2*Shear)/(2*Shear + 6*Bulk);
E = 3*Bulk*(1-2*nu);
MAT = 'NeoHookean';
% MAT = 'StVenant';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Geometry & Mesh & Dirichlet and Neumann nodes
% Thickness can be differed from "1" for the solid
h = 1;
% R1 and R2 which define the geometry of the curve beam
R1 = 9;
R2 = 10;
% number of nodes on circumferencial and radial directions
numNodesCir = 21;
numNodesThic = 4;
GeomMeshBcNodes = CurveBeamMesh3D(R1,R2,h,numNodesCir,numNodesThic);
%
%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
Re = zeros(numNodes*3,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*3,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
% qx = 0.5/sqrt(2);
% qy = -0.5/sqrt(2);
% qz = 0;
qx = 0;
qy = 0;
qz = -0.5;
% compute and then add the external distributed load vector into the
% external
Re = rqFaceLoad(Re,qx,qy,qz,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*3);
for i = 1:length(DirNodes)

    DirDofs(i*3-2) = DirNodes(i)*3-2;
    DirDofs(i*3-1) = DirNodes(i)*3-1;
    DirDofs(i*3) = DirNodes(i)*3;

end
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 25;
tol = 0.001;
maxIter = 15;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;
node4plot =ele((numNodesThic-2)*(numNodesCir-1)+1,8);
%For planar case from the paper
% "An efficient reduced basis approach using enhanced meshfree and combined approximation for large deformation"
PaperDataReactionForce = [-0.024390244	0.170731707	0.463414634	0.804878049	1.243902439	1.87804878	2.609756098	3.585365854	4.756097561	6.097560976	7.414634146	8.658536585	9.780487805	10.70731707	11.51219512	12.17073171	12.80487805	13.29268293	13.7804878	14.12195122	14.48780488	14.7804878	15	15.26829268	15.46341463	15.63414634;
                                    0	0.014693878	0.027755102	0.04244898	0.056326531	0.071020408	0.085714286	0.099591837	0.113469388	0.127346939	0.142040816	0.155918367	0.169795918	0.182857143	0.19755102	0.210612245	0.225306122	0.239183673	0.254693878	0.267755102	0.28244898	0.296326531	0.310204082	0.325714286	0.339591837	0.353469388];
%
%Data for out-of-plane case from the Abaqus simulation "curved_beam_solid_OutOfPlaneLoad" 
AbaqusDataReactionForce = [0	0.335977465	0.671411932	1.171094775	1.905653596	2.954038858	4.34641552	5.525556564	6.503808975	7.311477184	7.981332779	8.539647102	9.010723114	9.412234306	9.757916451	10.05843353	10.32206821	10.55529499	10.76321411	10.9498806	11.12335968	11.2718401	11.4131279	11.54326534	11.5621109;
                           0	0.005000001	0.010000009	0.017500013	0.028749991	0.045624979	0.070625015	0.095625103	0.120625019	0.145624995	0.170625031	0.195625007	0.220625103	0.245624959	0.270624995	0.295624942	0.320624888	0.345625103	0.370624959	0.395624965	0.420624971	0.445625216	0.470624954	0.495625108	0.500000119];
%
ToComparison = struct('node4plot',node4plot,'ComparisonData',AbaqusDataReactionForce);

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement3D(matProps,GeomMeshBcNodes,Load_n_BCs,NewtonSolParam,ToComparison);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')
% subplot(2,2,1)
xlim ([min([min(coords(:,1)) min(coordsCur(:,1))]) max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([min([min(coords(:,2)) min(coordsCur(:,2))]) max([max(coords(:,2)) max(coordsCur(:,2))])])

%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw3D(coords,ele,'bo','b')
% %% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw3D(coordsCur,ele,'go','--g')
% subplot(2,2,2)
% plotDisplacementU = drawDisplacement3D(coords, coordsCur, ele, 'x')
% subplot(2,2,3)
% plotDisplacementV = drawDisplacement3D(coords, coordsCur, ele, 'y')
% subplot(2,2,4)
% plotDisplacementW = drawDisplacement3D(coords, coordsCur, ele, 'z')
%% Plot stress
figure('Name','Stress Visualization')
plot = drawStressNodalExpo3D(coords, coordsCur, ele,E,nu,MAT);

%% Plot the field of displacement u
figure('Name','Displacement_X')
plotDisplacementU = drawDisplacement3D(coords, coordsCur, ele, 'x')

%% Plot the field of displacement v
figure('Name','Displacement_Y')
plotDisplacementV = drawDisplacement3D(coords, coordsCur, ele, 'y')

%% Plot the field of displacement w
figure('Name','Displacement_Z')
plotDisplacementW = drawDisplacement3D(coords, coordsCur, ele, 'z')