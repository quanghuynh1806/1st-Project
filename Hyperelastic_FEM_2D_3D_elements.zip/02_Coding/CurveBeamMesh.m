%% Description: Generation of the mesh from curve beam geometry and related quantites
%% Variable description
%% Input
    % R1: the inner radius
    % R2 : the outer radius
    % numNodesCir:  number of nodes on the inner and outer circumferences
    % numNodesThic: number of nodes on the radial edges
%% Output
% Mesh related:
    % coords: a matix with each row containing x & y coordinates of the
            % node in the undeformed state. The row index is also the node id
    % ele: a matrix with each row containing the ids of all nodes belonged
            % to the element. The row index is also the element id.
% Other related quantites:
    % nodesOnLineLoad: all nodes at the LEFT vertical radial edge are applied with the
                     % distributed load
    % DirNodes: all nodes on the RIGHT horizontal radial edge are displacement-constrained
    % numNodes: the total number of nodes generated
    % numEle: the total number of elements generated
%% Note:
    % all the variables above are grouped into a struct
    % "CurveBeamMeshOutput"
%% main code
function CurveBeamMeshOutput = CurveBeamMesh(R1,R2,numNodesCir,numNodesThic)

numIntervalCir = numNodesCir-1;
numIntervalThic = numNodesThic-1;
deltaH = (R2-R1)/(numIntervalThic);
deltaAl = (pi/2)/(numIntervalCir);
coords = [];
k = 1;
for i = 0:numIntervalThic
    
    for j = 0:numIntervalCir
        
        coords = [coords; (R1+i*deltaH)*cos(pi/2 - j*deltaAl) (R1+i*deltaH)*sin(pi/2 - j*deltaAl)]
%         plot(coords(k,1),coords(k,2),'bo','MarkerSize', 10);
         %text(coords(k,1),coords(k,2),sprintf('n%d',k));
        k = k + 1; 
    end
    
end

% Generate 1st order element (4 nodes)
ele = [];
k = 1;
for i = 1:numIntervalThic

    for j = 1:numIntervalCir

        ele(k,1) = (numIntervalCir+1)*(i-1) + j;
        ele(k,2) = (numIntervalCir+1)*(i-1) + j + 1;
        ele(k,3) = (numIntervalCir+1)*(i-1) + j + 1 + numIntervalCir + 1;
        ele(k,4) = (numIntervalCir+1)*(i-1) + j + numIntervalCir + 1;
        ele(k,5) = 0;
        ele(k,6) = 0;
        ele(k,7) = 0;
        ele(k,8) = 0;
        ele(k,9) = 0;
%         xElePlot = [coords(ele(k,1),1) coords(ele(k,2),1) coords(ele(k,3),1) coords(ele(k,4),1) coords(ele(k,1),1)];
%         yElePlot = [coords(ele(k,1),2) coords(ele(k,2),2) coords(ele(k,3),2) coords(ele(k,4),2) coords(ele(k,1),2)];
%         plot(xElePlot,yElePlot,'k','LineWidth',1)

        k = k+1;

    end
end

    %% Upgrade 1st order elements - 4 nodes into 2nd order - 9 nodes
    [numEle,m] = size(ele);
    eleID = 1;
    for i = 1:numIntervalThic

        for j = 1:numIntervalCir

        [numNodes,m] = size(coords);

        if i == 1 
            numNodes = numNodes + 1;
            nod5 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1))/2, (coords(ele(eleID,1),2)+coords(ele(eleID,2),2))/2];
            ele(eleID,5) = numNodes;
            coords = [coords; nod5];
        else

            ele(eleID,5) = ele(eleID-numIntervalCir,7);

        end
        numNodes = numNodes + 1;
        nod6 = [(coords(ele(eleID,2),1)+ coords(ele(eleID,3),1))/2, (coords(ele(eleID,2),2)+coords(ele(eleID,3),2))/2];
        ele(eleID,6) = numNodes;
        coords = [coords; nod6];

        numNodes = numNodes + 1;
        nod7 = [(coords(ele(eleID,3),1)+ coords(ele(eleID,4),1))/2, (coords(ele(eleID,3),2)+coords(ele(eleID,4),2))/2];
        ele(eleID,7) = numNodes;
        coords = [coords; nod7];

        if j == 1
            numNodes = numNodes + 1;
            nod8 = [(coords(ele(eleID,4),1)+ coords(ele(eleID,1),1))/2, (coords(ele(eleID,4),2)+coords(ele(eleID,1),2))/2]
            ele(eleID,8) = numNodes;
            coords = [coords; nod8];
        else
            ele(eleID,8) = ele(eleID-1,6);
        end
        %
        numNodes = numNodes + 1;
        nod9 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1) + coords(ele(eleID,3),1) + coords(ele(eleID,4),1))/4, (coords(ele(eleID,1),2)+ coords(ele(eleID,2),2) + coords(ele(eleID,3),2) + coords(ele(eleID,4),2))/4];    
        ele(eleID,9) = numNodes;
        coords = [coords; nod9];
        %
        eleID = eleID + 1;
        end

    end
    
    %% Collect nodes lying on Dirichlet boundary
    DirNodes = [ele(numIntervalCir,2)  ele(numIntervalCir,3) ele(numIntervalCir,6)];
    for i = 1:numIntervalThic

        DirNodes = [DirNodes setdiff([ele(i*numIntervalCir,2) ele(i*numIntervalCir,3) ele(i*numIntervalCir,6)],DirNodes)];

    end
    
    %% Collect nodes lying on distributed-load edge
    nodesOnLineLoad = zeros(numIntervalThic,3);
    for i = 0:(numIntervalThic-1)

        nodesOnLineLoad(i+1,:) = [ele(1+i*numIntervalCir,4) ele(1+i*numIntervalCir,1) ele(1+i*numIntervalCir,8)];

    end
    CurveBeamMeshOutput = struct('coords',coords,'ele',ele,'nodesOnLineLoad',nodesOnLineLoad,'DirNodes',DirNodes,'numNodes',numNodes,'numEle',numEle);
end
