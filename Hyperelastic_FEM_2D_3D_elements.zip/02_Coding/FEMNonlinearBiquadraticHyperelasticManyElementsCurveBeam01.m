clc
clear all
%% Material's properties
Bulk = 120.291;
Shear = 80.194;
nu = (3*Bulk-2*Shear)/(2*Shear + 6*Bulk);
E = 3*Bulk*(1-2*nu);
MAT = 'NeoHookean';
%
matProps = struct('MAT',MAT,'E',E,'nu',nu);

%% Analysis type
nDproblem = 'plane stress';
% Initial thickness
h = 1; 
    % For the plane strain problem, h must be 1 - the representative thickness. 
    % In case of plane stress, h can be the real thickness
AnalysisType = struct('Problem',nDproblem,'Thickness',h);

%% Geometry & Mesh & Dirichlet and Neumann nodes
% R1 and R2 which define the geometry of the curve beam
R1 = 9;
R2 = 10;
% number of nodes on circumferencial and radial directions
numNodesCir = 51;
numNodesThic = 6;
% nodes on Dirichlet BCs (left edge)and 
% nodes on the line of distributed load (right edge) 
% are also determined
GeomMeshBcNodes = CurveBeamMesh(R1,R2,numNodesCir,numNodesThic);

%% Initialize the external structural load vector
numNodes = GeomMeshBcNodes.numNodes;
% Global external nodal load vector
Re = zeros(numNodes*2,1);
% External concentrated (nodal) load vector
RC = zeros(numNodes*2,1);
%
% add the external concentrated load into the external structural load
% vector
Re = Re + RC;

%% External Line distributed load
qn = -0.5/sqrt(2);
qt =  0.5/sqrt(2);
% compute the nodal equivalent load vector and 
% add it into the global load vector
Re = rqLineLoad(Re,qn,qt,AnalysisType,GeomMeshBcNodes);
%% Dirichlet nodes and corresponding Dofs
%Determine Dirichlet Dofs
%Fix both vertical & horizontal displacements
DirNodes = GeomMeshBcNodes.DirNodes;
DirDofs = zeros(1, length(DirNodes)*2);
for i = 1:length(DirNodes)

    DirDofs(i*2-1) = DirNodes(i)*2-1;
    DirDofs(i*2) = DirNodes(i)*2;

end
%
Load_n_BCs = struct('Re',Re,'DirDofs',DirDofs);

%% Load increments for Newton Raphson solution
numLoadIncr = 50;
tol = 0.001;
maxIter = 15;
coords = GeomMeshBcNodes.coords;
coordsCurIniGuess = coords;
%
%
NewtonSolParam = struct('numLoadIncr',numLoadIncr,'tol',tol,'maxIter',maxIter,'coordsCurInitialGuess',coordsCurIniGuess);

%% To be compared with the data from paper
% The corresponding node in simulation
numEle = GeomMeshBcNodes.numEle;
ele = GeomMeshBcNodes.ele;
% Choosing the node to be compared in terms of force-displacement curve
node4plot = ele((numNodesThic-2)*(numNodesCir-1)+1,4);
% Data of Cook's membrane from the paper 
% "An efficient reduced basis approach using enhanced meshfree and combined approximation for large deformation"
PaperDataReactionForce = [-0.024390244	0.170731707	0.463414634	0.804878049	1.243902439	1.87804878	2.609756098	3.585365854	4.756097561	6.097560976	7.414634146	8.658536585	9.780487805	10.70731707	11.51219512	12.17073171	12.80487805	13.29268293	13.7804878	14.12195122	14.48780488	14.7804878	15	15.26829268	15.46341463	15.63414634;
                                    0	0.014693878	0.027755102	0.04244898	0.056326531	0.071020408	0.085714286	0.099591837	0.113469388	0.127346939	0.142040816	0.155918367	0.169795918	0.182857143	0.19755102	0.210612245	0.225306122	0.239183673	0.254693878	0.267755102	0.28244898	0.296326531	0.310204082	0.325714286	0.339591837	0.353469388];
%
ToComparison = struct('node4plot',node4plot,'PaperData',PaperDataReactionForce);

%% Execution of Newton solution for the loadcase
[conv,coordsCur] = NewtonLoadIncrement(matProps,GeomMeshBcNodes,AnalysisType,Load_n_BCs,NewtonSolParam,ToComparison);
% Note: the reaction force vs displacement curve is plotted inside the function "NewtonLoadIncrement" 

%% Overlay of the initial and final configuration
figure('Name','Undeformed vs Deformed Configurations')

%% Plot nodes and elements in the undeformed state
[plotLineUndeformed, plotPointUndeformed] = MeshDraw(coords,ele,'bo','b')

%% Plot nodes and elements in the deformed state
[plotLineDeformed, plotPointDeformed] = MeshDraw(coordsCur,ele,'go','--g')

%% Graph's properties
legend([plotLineUndeformed plotLineDeformed],'Undeformed','Deformed - Biquadratic')
xlim ([min([min(coords(:,1)) min(coordsCur(:,1))]) max([max(coords(:,1)) max(coordsCur(:,1))])])
ylim ([min([min(coords(:,2)) min(coordsCur(:,2))]) max([max(coords(:,2)) max(coordsCur(:,2))])])

%% Plot the field of resultant displacement
figure('Name','Displacement_R')
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'resultant')

%% Plot the field of displacement u
figure('Name','Displacement_X')
plotDisplacementU = drawDisplacement(coords, coordsCur, ele, 'x')

%% Plot the field of displacement v
figure('Name','Displacement_Y')
plotDisplacementV = drawDisplacement(coords, coordsCur, ele, 'y')

%%
figure('Name','Nodal stresses extrapolated from Gauss points')
[plotStressNodalExpoXX,plotStressNodalExpoYY,plotStressNodalExpoXY] = drawStressNodalExpo(coords, coordsCur, ele,E,nu,nDproblem,MAT);

disp(['The maximum vertical displacement is at the top right corner : v = ', num2str(coordsCur(node4plot,2) - coords(node4plot,2)),' mm']);
