%% Description: Calculation of convergence parameter for a structure after one iteration
%% Variable description
%% Input
    % ReIncrNonDir: the loadstep increment in Newton Raphson procedure
    % coords: an arrray contains coordinates of all nodes of the structure at
    %         initial configuration.
    % coordsCur: an arrray contains coordinates of all nodes of the structure at
    %         current configuration after the previous iteration.
    % NonDirDofs: an array contains all unconstrained dofs
%% Output
    % conv: the convergence criterion computed at the final load-step
    % normRes: the norm of the residual (the difference between internal
    % and external load vectors
function [conv,normRes] = Nonlinear27NodeSolidStrucResidual(ReIncrNonDir,NonDirDofs,ele,coords,coordsCur,E,nu,MAT)
[numNodes,m] = size(coords);
[numEle,m] = size(ele);
%% Check the residual after the completion of the latest iteration

    RiRes = zeros(numNodes*3,1);
    for eleID = 1:numEle

        [riRes,indx,sigma] = Nonlinear27NodeSolidEleResidual(eleID,ele,coords,coordsCur,E,nu,MAT);
        RiRes(indx) = RiRes(indx) + riRes;

    end

    %% Simplify load vector R after imposing Dirichlet BCs
    for i = 1:length(NonDirDofs)

        RiResNonDir(i) = RiRes(NonDirDofs(i));

    end

    %% Calculation of the convergence parameter
    normRes = norm(RiResNonDir-ReIncrNonDir);
    conv = (normRes)/(1+norm(ReIncrNonDir));
end