%% Description: Generation of the equivalent nodal load vector from uniformly distributed load on elements' face
%% Variable description
%% Input
    % Re: the global external nodal load vector BEFORE the addition of the
        % equivalent nodal load vector
    % qx: x-component of the uniformly distributed load vector on
        % element edge
    % qy: y-component of the uniformly distributed load vector on
        % element edge
    % qz: z-component of the uniformly distributed load vector on
        % element edge
    % GeomMeshBcNodes: a struct containing the infor about mesh and nodes
        % applied with boundary condition
%% Output
    % Re: the global external nodal load vector AFTER the addition of the
        % equivalent nodal load vector 
function Re = rqFaceLoad(Re,qx,qy,qz,GeomMeshBcNodes)

nodesOnFaceLoad = GeomMeshBcNodes.nodesOnFaceLoad;
coords = GeomMeshBcNodes.coords;
%Gauss Quadrature 2D
GaussBiquadratic = [-0.774597 -0.774597 0.308642;%1
                    -0.774597  0        0.493827;%2
                    -0.774597  0.774597 0.308642;%3
                     0        -0.774597 0.493827;%4
                     0         0        0.790123;%5
                     0         0.774597 0.493827;%6
                     0.774597 -0.774597 0.308642;%7
                     0.774597  0        0.493827;%8
                     0.774597  0.774597 0.308642];%9
[nGaBiQuad, m]=size(GaussBiquadratic);
%
[numFaces,m] = size(nodesOnFaceLoad);
for face = 1:numFaces
    
    dofsOnFaceLoad = [nodesOnFaceLoad(face,1)*3-2 nodesOnFaceLoad(face,1)*3-1 nodesOnFaceLoad(face,1)*3 nodesOnFaceLoad(face,2)*3-2 nodesOnFaceLoad(face,2)*3-1 nodesOnFaceLoad(face,2)*3 nodesOnFaceLoad(face,3)*3-2 nodesOnFaceLoad(face,3)*3-1 nodesOnFaceLoad(face,3)*3 nodesOnFaceLoad(face,4)*3-2 nodesOnFaceLoad(face,4)*3-1 nodesOnFaceLoad(face,4)*3 nodesOnFaceLoad(face,5)*3-2 nodesOnFaceLoad(face,5)*3-1 nodesOnFaceLoad(face,5)*3 nodesOnFaceLoad(face,6)*3-2 nodesOnFaceLoad(face,6)*3-1 nodesOnFaceLoad(face,6)*3 nodesOnFaceLoad(face,7)*3-2 nodesOnFaceLoad(face,7)*3-1 nodesOnFaceLoad(face,7)*3 nodesOnFaceLoad(face,8)*3-2 nodesOnFaceLoad(face,8)*3-1 nodesOnFaceLoad(face,8)*3 nodesOnFaceLoad(face,9)*3-2 nodesOnFaceLoad(face,9)*3-1 nodesOnFaceLoad(face,9)*3];
    rq_dofsOnFaceLoad = zeros(9*3,1);
    
    for i = 1:nGaBiQuad
        a = GaussBiquadratic(i,1);
        b = GaussBiquadratic(i,2);
        w = GaussBiquadratic(i,3);
        
        Nface = [0.25*(-1+a)*a*(-1+b)*b;
                 0.25*a*(1+a)*(-1+b)*b;
                 0.25*a*(1+a)*b*(1+b);
                 0.25*(-1+a)*a*b*(1+b);
                 0.5*(1-a^2)*(-1+b)*b;
                 0.5*a*(1+a)*(1-b^2);
                 0.5*(1-a^2)*b*(1+b);
                 0.5*(-1+a)*a*(1-b^2);
                 1.*(1-a^2)*(1-b^2)];
        %
        dNfaceda = [
                0.5*(-0.5+1*a)*(-1+b)*b;
                0.5*(0.5+1*a)*(-1+b)*b;
                0.5*(0.5+1*a)*b*(1+b);
                0.5*(-0.5+1*a)*b*(1+b);
                -1*a*(-1+b)*b;
                0.5-0.5*b^2+a*(1-1*b^2);
                -1*a*b*(1+b);
                -0.5+0.5*b^2+a*(1-1*b^2);
                2.*a*(-1+b^2)
                    ];
        %
        dNfacedb = [
                0.5*(-1+a)*a*(-0.5+1*b);
                0.5*a*(1+a)*(-0.5+1*b);
                0.5*a*(1+a)*(0.5+1*b);
                0.5*(-1+a)*a*(0.5+1*b);
                -0.5+a^2*(0.5-1*b)+1*b;
                -1*a*(1+a)*b;
                0.5+a^2*(-0.5-1*b)+1*b;
                -1*(-1+a)*a*b;
                2.*(-1+a^2)*b
                    ];
        %
        nod1 = nodesOnFaceLoad(face,1);
        nod2 = nodesOnFaceLoad(face,2);
        nod3 = nodesOnFaceLoad(face,3);
        nod4 = nodesOnFaceLoad(face,4);
        nod5 = nodesOnFaceLoad(face,5);
        nod6 = nodesOnFaceLoad(face,6);
        nod7 = nodesOnFaceLoad(face,7);
        nod8 = nodesOnFaceLoad(face,8);
        nod9 = nodesOnFaceLoad(face,9);
        
        XcoordsFace = [coords(nod1,1) coords(nod2,1) coords(nod3,1) coords(nod4,1) coords(nod5,1) coords(nod6,1) coords(nod7,1) coords(nod8,1) coords(nod9,1)]';
        YcoordsFace = [coords(nod1,2) coords(nod2,2) coords(nod3,2) coords(nod4,2) coords(nod5,2) coords(nod6,2) coords(nod7,2) coords(nod8,2) coords(nod9,2)]';        
        ZcoordsFace = [coords(nod1,3) coords(nod2,3) coords(nod3,3) coords(nod4,3) coords(nod5,3) coords(nod6,3) coords(nod7,3) coords(nod8,3) coords(nod9,3)]';

        dxFaceda = dNfaceda'*XcoordsFace;
        dxFacedb = dNfacedb'*XcoordsFace;
        dyFaceda = dNfaceda'*YcoordsFace;
        dyFacedb = dNfacedb'*YcoordsFace;
        dzFaceda = dNfaceda'*ZcoordsFace;
        dzFacedb = dNfacedb'*ZcoordsFace;
        
        v1 = [dxFaceda dyFaceda dzFaceda]';
        v2 = [dxFacedb dyFacedb dzFacedb]';
        
        Js = norm(cross(v1,v2),2);
        
        NfacePt = [Nface(1) 0           0;
                   0        Nface(1)    0;
                   0        0           Nface(1);
                   Nface(2) 0           0;
                   0        Nface(2)    0;
                   0        0           Nface(2);
                   Nface(3) 0           0;
                   0        Nface(3)    0;
                   0        0           Nface(3);
                   Nface(4) 0           0;
                   0        Nface(4)    0;
                   0        0           Nface(4);
                   Nface(5) 0           0;
                   0        Nface(5)    0;
                   0        0           Nface(5);
                   Nface(6) 0           0;
                   0        Nface(6)    0;
                   0        0           Nface(6);
                   Nface(7) 0           0;
                   0        Nface(7)    0;
                   0        0           Nface(7);
                   Nface(8) 0           0;
                   0        Nface(8)    0;
                   0        0           Nface(8);
                   Nface(9) 0           0;
                   0        Nface(9)    0;
                   0        0           Nface(9)];
               
        rq_dofsOnFaceLoad = rq_dofsOnFaceLoad + w*Js*NfacePt*[qx qy qz]'; %This is still second order => 2 Gauss points are enough

    end
    %
    %% Complete external load vector
    Re(dofsOnFaceLoad) = Re(dofsOnFaceLoad)+rq_dofsOnFaceLoad;

end