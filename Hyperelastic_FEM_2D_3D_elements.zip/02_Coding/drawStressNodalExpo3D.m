%% Description: draw stress fields
%% Variable description
%% Input
    % coords: coordinates of nodes in the UNDEFORMED state
    % coordsCur: coordinates of nodes in the DEFORMED state
    % ele: a matrix with each row containing the ids of all nodes belonged
         % to the element. The row index is also the element id.
%% Output
    % plotStressNodalExpoXX + YY + XY : plots contain Cauchy stress fields:
    % XX / YY / / ZZ / XY / YZ / XZ
function plot = drawStressNodalExpo3D(coords, coordsCur, ele,E,nu,MAT)
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
[numEle,m] = size(ele);
%% X and Y coordinates of all nodes
XcoordsCur = coordsCur(:,1)
YcoordsCur = coordsCur(:,2);
ZcoordsCur = coordsCur(:,3);
%
%Gauss Quadrature 3D
GaussQuadraticSolid = [-0.774597 -0.774597 -0.774597 0.171468; %1
                       -0.774597 -0.774597  0        0.274348; %2
                       -0.774597 -0.774597  0.774597 0.171468; %3
                       -0.774597  0        -0.774597 0.274348; %4
                       -0.774597  0         0        0.438957; %5
                       -0.774597  0         0.774597 0.274348; %6
                       -0.774597  0.774597 -0.774597 0.171468; %7
                       -0.774597  0.774597  0        0.274348; %8
                       -0.774597  0.774597  0.774597 0.171468; %9
                        0        -0.774597 -0.774597 0.274348; %10
                        0        -0.774597  0        0.438957; %11
                        0        -0.774597  0.774597 0.274348; %12
                        0         0        -0.774597 0.438957; %13
                        0         0         0        0.702332; %14
                        0         0         0.774597 0.438957; %15
                        0         0.774597 -0.774597 0.274348; %16
                        0         0.774597  0        0.438957; %17
                        0         0.774597  0.774597 0.274348; %18
                        0.774597 -0.774597 -0.774597 0.171468; %19
                        0.774597 -0.774597  0        0.274348; %20
                        0.774597 -0.774597  0.774597 0.171468; %21
                        0.774597  0        -0.774597 0.274348; %22
                        0.774597  0         0        0.438957; %23
                        0.774597  0         0.774597 0.274348; %24
                        0.774597  0.774597 -0.774597 0.171468; %25
                        0.774597  0.774597  0        0.274348; %26
                        0.774597  0.774597  0.774597 0.171468  %27
                       ];
[nGaQuadSolid, m]=size(GaussQuadraticSolid);
%     for gptID=1:nGaQuadSolid
%         hold on
%         plotPoint = plot3(GaussQuadraticSolid(gptID,1),GaussQuadraticSolid(gptID,2),GaussQuadraticSolid(gptID,3),'o','MarkerSize', 10);
%         text(GaussQuadraticSolid(gptID,1),GaussQuadraticSolid(gptID,2),GaussQuadraticSolid(gptID,3),sprintf('%d',gptID));
%     end
%% Initialization of shape functions and partial derivatives
N1=zeros(nGaQuadSolid,1);
N2=zeros(nGaQuadSolid,1);
N3=zeros(nGaQuadSolid,1);
N4=zeros(nGaQuadSolid,1);
N5=zeros(nGaQuadSolid,1);
N6=zeros(nGaQuadSolid,1);
N7=zeros(nGaQuadSolid,1);
N8=zeros(nGaQuadSolid,1);
N9=zeros(nGaQuadSolid,1);
N10=zeros(nGaQuadSolid,1);
N11=zeros(nGaQuadSolid,1);
N12=zeros(nGaQuadSolid,1);
N13=zeros(nGaQuadSolid,1);
N14=zeros(nGaQuadSolid,1);
N15=zeros(nGaQuadSolid,1);
N16=zeros(nGaQuadSolid,1);
N17=zeros(nGaQuadSolid,1);
N18=zeros(nGaQuadSolid,1);
N19=zeros(nGaQuadSolid,1);
N20=zeros(nGaQuadSolid,1);
N21=zeros(nGaQuadSolid,1);
N22=zeros(nGaQuadSolid,1);
N23=zeros(nGaQuadSolid,1);
N24=zeros(nGaQuadSolid,1);
N25=zeros(nGaQuadSolid,1);
N26=zeros(nGaQuadSolid,1);
N27=zeros(nGaQuadSolid,1);
%
dN1r=zeros(nGaQuadSolid,1);
dN2r=zeros(nGaQuadSolid,1);
dN3r=zeros(nGaQuadSolid,1);
dN4r=zeros(nGaQuadSolid,1);
dN5r=zeros(nGaQuadSolid,1);
dN6r=zeros(nGaQuadSolid,1);
dN7r=zeros(nGaQuadSolid,1);
dN8r=zeros(nGaQuadSolid,1);
dN9r=zeros(nGaQuadSolid,1);
dN10r=zeros(nGaQuadSolid,1);
dN11r=zeros(nGaQuadSolid,1);
dN12r=zeros(nGaQuadSolid,1);
dN13r=zeros(nGaQuadSolid,1);
dN14r=zeros(nGaQuadSolid,1);
dN15r=zeros(nGaQuadSolid,1);
dN16r=zeros(nGaQuadSolid,1);
dN17r=zeros(nGaQuadSolid,1);
dN18r=zeros(nGaQuadSolid,1);
dN19r=zeros(nGaQuadSolid,1);
dN20r=zeros(nGaQuadSolid,1);
dN21r=zeros(nGaQuadSolid,1);
dN22r=zeros(nGaQuadSolid,1);
dN23r=zeros(nGaQuadSolid,1);
dN24r=zeros(nGaQuadSolid,1);
dN25r=zeros(nGaQuadSolid,1);
dN26r=zeros(nGaQuadSolid,1);
dN27r=zeros(nGaQuadSolid,1);
%
dN1s=zeros(nGaQuadSolid,1);
dN2s=zeros(nGaQuadSolid,1);
dN3s=zeros(nGaQuadSolid,1);
dN4s=zeros(nGaQuadSolid,1);
dN5s=zeros(nGaQuadSolid,1);
dN6s=zeros(nGaQuadSolid,1);
dN7s=zeros(nGaQuadSolid,1);
dN8s=zeros(nGaQuadSolid,1);
dN9s=zeros(nGaQuadSolid,1);
dN10s=zeros(nGaQuadSolid,1);
dN11s=zeros(nGaQuadSolid,1);
dN12s=zeros(nGaQuadSolid,1);
dN13s=zeros(nGaQuadSolid,1);
dN14s=zeros(nGaQuadSolid,1);
dN15s=zeros(nGaQuadSolid,1);
dN16s=zeros(nGaQuadSolid,1);
dN17s=zeros(nGaQuadSolid,1);
dN18s=zeros(nGaQuadSolid,1);
dN19s=zeros(nGaQuadSolid,1);
dN20s=zeros(nGaQuadSolid,1);
dN21s=zeros(nGaQuadSolid,1);
dN22s=zeros(nGaQuadSolid,1);
dN23s=zeros(nGaQuadSolid,1);
dN24s=zeros(nGaQuadSolid,1);
dN25s=zeros(nGaQuadSolid,1);
dN26s=zeros(nGaQuadSolid,1);
dN27s=zeros(nGaQuadSolid,1);
%
dN1t=zeros(nGaQuadSolid,1);
dN2t=zeros(nGaQuadSolid,1);
dN3t=zeros(nGaQuadSolid,1);
dN4t=zeros(nGaQuadSolid,1);
dN5t=zeros(nGaQuadSolid,1);
dN6t=zeros(nGaQuadSolid,1);
dN7t=zeros(nGaQuadSolid,1);
dN8t=zeros(nGaQuadSolid,1);
dN9t=zeros(nGaQuadSolid,1);
dN10t=zeros(nGaQuadSolid,1);
dN11t=zeros(nGaQuadSolid,1);
dN12t=zeros(nGaQuadSolid,1);
dN13t=zeros(nGaQuadSolid,1);
dN14t=zeros(nGaQuadSolid,1);
dN15t=zeros(nGaQuadSolid,1);
dN16t=zeros(nGaQuadSolid,1);
dN17t=zeros(nGaQuadSolid,1);
dN18t=zeros(nGaQuadSolid,1);
dN19t=zeros(nGaQuadSolid,1);
dN20t=zeros(nGaQuadSolid,1);
dN21t=zeros(nGaQuadSolid,1);
dN22t=zeros(nGaQuadSolid,1);
dN23t=zeros(nGaQuadSolid,1);
dN24t=zeros(nGaQuadSolid,1);
dN25t=zeros(nGaQuadSolid,1);
dN26t=zeros(nGaQuadSolid,1);
dN27t=zeros(nGaQuadSolid,1);

%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaQuadSolid
    
    r = GaussQuadraticSolid(i,1);
    s = GaussQuadraticSolid(i,2);
    t = GaussQuadraticSolid(i,3);

    % Shape functions evaluated at Gauss point
    N1(i) = 0.125*r*(r-1)*s*(s-1)*t*(t-1); 
    N2(i) = 0.125*r*(r+1)*s*(s-1)*t*(t-1); 
    N3(i) = 0.125*r*(r+1)*s*(s+1)*t*(t-1); 
    N4(i) = 0.125*r*(r-1)*s*(s+1)*t*(t-1);
    N5(i) = 0.125*r*(r-1)*s*(s-1)*t*(t+1);
    N6(i) = 0.125*r*(r+1)*s*(s-1)*t*(t+1);
    N7(i) = 0.125*r*(r+1)*s*(s+1)*t*(t+1);
    N8(i) = 0.125*r*(r-1)*s*(s+1)*t*(t+1);
    N9(i) = 0.25*(1-r^2)*s*(s-1)*t*(t-1);
    N10(i) = 0.25*r*(r+1)*(1-s^2)*t*(t-1);
    N11(i) = 0.25*(1-r^2)*s*(s+1)*t*(t-1);
    N12(i) = 0.25*r*(r-1)*(1-s^2)*t*(t-1);
    N13(i) = 0.25*(1-r^2)*s*(s-1)*t*(t+1);
    N14(i) = 0.25*r*(r+1)*(1-s^2)*t*(t+1);
    N15(i) = 0.25*(1-r^2)*s*(s+1)*t*(t+1);
    N16(i) = 0.25*r*(r-1)*(1-s^2)*t*(t+1);
    N17(i) = 0.25*r*(r-1)*s*(s-1)*(1-t^2);
    N18(i) = 0.25*r*(r+1)*s*(s-1)*(1-t^2);
    N19(i) = 0.25*r*(r+1)*s*(s+1)*(1-t^2);
    N20(i) = 0.25*r*(r-1)*s*(s+1)*(1-t^2);
    N21(i) = 0.5*(1-r^2)*(1-s^2)*t*(t-1);
    N22(i) = 0.5*(1-r^2)*(1-s^2)*t*(t+1);
    N23(i) = 0.5*(1-r^2)*s*(s-1)*(1-t^2);
    N24(i) = 0.5*r*(r+1)*(1-s^2)*(1-t^2);
    N25(i) = 0.5*(1-r^2)*s*(s+1)*(1-t^2);
    N26(i) = 0.5*r*(r-1)*(1-s^2)*(1-t^2);
    N27(i) = (1-r^2)*(1-s^2)*(1-t^2);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN2r(i) = 0.25*(0.5+1*r)*(-1+s)*s*(-1+t)*t;
    dN3r(i) = 0.25*(0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN4r(i) = 0.25*(-0.5+1*r)*s*(1+s)*(-1+t)*t;
    dN5r(i) = 0.25*(-0.5+1*r)*(-1+s)*s*t*(1+t);
    dN6r(i) = 0.25*(0.5+1*r)*(-1+s)*s*t*(1+t);
    dN7r(i) = 0.25*(0.5+1*r)*s*(1+s)*t*(1+t);
    dN8r(i) = 0.25*(-0.5+1*r)*s*(1+s)*t*(1+t);
    dN9r(i) = -0.5*r*(-1+s)*s*(-1+t)*t;
    dN10r(i) = -0.5*(0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN11r(i) = -0.5*r*s*(1+s)*(-1+t)*t;
    dN12r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*(-1+t)*t;
    dN13r(i) = -0.5*r*(-1+s)*s*t*(1+t);
    dN14r(i) = -0.5*(0.5+1*r)*(-1+s^2)*t*(1+t);
    dN15r(i) = -0.5*r*s*(1+s)*t*(1+t);
    dN16r(i) = -0.5*(-0.5+1*r)*(-1+s^2)*t*(1+t);
    dN17r(i) = -0.5*(-0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN18r(i) = -0.5*(0.5+1*r)*(-1+s)*s*(-1+t^2);
    dN19r(i) = -0.5*(0.5+1*r)*s*(1+s)*(-1+t^2);
    dN20r(i) = -0.5*(-0.5+1*r)*s*(1+s)*(-1+t^2);
    dN21r(i) = 1*r*(-1+s^2)*(-1+t)*t;
    dN22r(i) = 1*r*(-1+s^2)*t*(1+t);
    dN23r(i) = 1*r*(-1+s)*s*(-1+t^2);
    dN24r(i) = 1*(0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN25r(i) = 1*r*s*(1+s)*(-1+t^2);
    dN26r(i) = 1*(-0.5+1*r)*(-1+s^2)*(-1+t^2);
    dN27r(i) = -2*r*(-1+s^2)*(-1+t^2);
    %
    dN1s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*(-1+t)*t;
    dN2s(i) = 0.25*r*(1+r)*(-0.5+1*s)*(-1+t)*t;
    dN3s(i) = 0.25*r*(1+r)*(0.5+1*s)*(-1+t)*t;
    dN4s(i) = 0.25*(-1+r)*r*(0.5+1*s)*(-1+t)*t;
    dN5s(i) = 0.25*(-1+r)*r*(-0.5+1*s)*t*(1+t);
    dN6s(i) = 0.25*r*(1+r)*(-0.5+1*s)*t*(1+t);
    dN7s(i) = 0.25*r*(1+r)*(0.5+1*s)*t*(1+t);
    dN8s(i) = 0.25*(-1+r)*r*(0.5+1*s)*t*(1+t);
    dN9s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*(-1+t)*t;
    dN10s(i) = -0.5*r*(1+r)*s*(-1+t)*t;
    dN11s(i) = -0.5*(-1+r^2)*(0.5+1*s)*(-1+t)*t;
    dN12s(i) = -0.5*(-1+r)*r*s*(-1+t)*t;
    dN13s(i) = -0.5*(-1+r^2)*(-0.5+1*s)*t*(1+t);
    dN14s(i) = -0.5*r*(1+r)*s*t*(1+t);
    dN15s(i) = -0.5*(-1+r^2)*(0.5+1*s)*t*(1+t);
    dN16s(i) = -0.5*(-1+r)*r*s*t*(1+t);
    dN17s(i) = -0.5*(-1+r)*r*(-0.5+1*s)*(-1+t^2);
    dN18s(i) = -0.5*r*(1+r)*(-0.5+1*s)*(-1+t^2);
    dN19s(i) = -0.5*r*(1+r)*(0.5+1*s)*(-1+t^2);
    dN20s(i) = -0.5*(-1+r)*r*(0.5+1*s)*(-1+t^2);
    dN21s(i) = 1*(-1+r^2)*s*(-1+t)*t;
    dN22s(i) = 1*(-1+r^2)*s*t*(1+t);
    dN23s(i) = 1*(-1+r^2)*(-0.5+1*s)*(-1+t^2);
    dN24s(i) = 1*r*(1+r)*s*(-1+t^2);
    dN25s(i) = 1*(-1+r^2)*(0.5+1*s)*(-1+t^2);
    dN26s(i) = 1*(-1+r)*r*s*(-1+t^2);
    dN27s(i) = -2*(-1+r^2)*s*(-1+t^2);
    %
    dN1t(i) = 0.25*(-1+r)*r*(-1+s)*s*(-0.5+1*t);
    dN2t(i) = 0.25*r*(1+r)*(-1+s)*s*(-0.5+1*t);
    dN3t(i) = 0.25*r*(1+r)*s*(1+s)*(-0.5+1*t);
    dN4t(i) = 0.25*(-1+r)*r*s*(1+s)*(-0.5+1*t);
    dN5t(i) = 0.25*(-1+r)*r*(-1+s)*s*(0.5+1*t);
    dN6t(i) = 0.25*r*(1+r)*(-1+s)*s*(0.5+1*t);
    dN7t(i) = 0.25*r*(1+r)*s*(1+s)*(0.5+1*t);
    dN8t(i) = 0.25*(-1+r)*r*s*(1+s)*(0.5+1*t);
    dN9t(i) = -0.5*(-1+r^2)*(-1+s)*s*(-0.5+1*t);
    dN10t(i) = -0.5*r*(1+r)*(-1+s^2)*(-0.5+1*t);
    dN11t(i) = -0.5*(-1+r^2)*s*(1+s)*(-0.5+1*t);
    dN12t(i) = -0.5*(-1+r)*r*(-1+s^2)*(-0.5+1*t);
    dN13t(i) = -0.5*(-1+r^2)*(-1+s)*s*(0.5+1*t);
    dN14t(i) = -0.5*r*(1+r)*(-1+s^2)*(0.5+1*t);
    dN15t(i) = -0.5*(-1+r^2)*s*(1+s)*(0.5+1*t);
    dN16t(i) = -0.5*(-1+r)*r*(-1+s^2)*(0.5+1*t);
    dN17t(i) = -0.5*(-1+r)*r*(-1+s)*s*t;
    dN18t(i) = -0.5*r*(1+r)*(-1+s)*s*t;
    dN19t(i) = -0.5*r*(1+r)*s*(1+s)*t;
    dN20t(i) = -0.5*(-1+r)*r*s*(1+s)*t;
    dN21t(i) = 1*(-1+r^2)*(-1+s^2)*(-0.5+1*t);
    dN22t(i) = 1*(-1+r^2)*(-1+s^2)*(0.5+1*t);
    dN23t(i) = 1*(-1+r^2)*(-1+s)*s*t;
    dN24t(i) = 1*r*(1+r)*(-1+s^2)*t;
    dN25t(i) = 1*(-1+r^2)*s*(1+s)*t;
    dN26t(i) = 1*(-1+r)*r*(-1+s^2)*t;
    dN27t(i) = -2*(-1+r^2)*(-1+s^2)*t;
end
%Initialization of the variables
%mapping from initial to master
Jfem = zeros(3);
%mapping from current to master
JfemCur = zeros(3);
%planar deformation gradient tensor
F = zeros(3);
%deformation gradient matrix in FEM style
Fbar = zeros(6,9);
%strain matrix
BT = zeros(9,27*3);
%internal force vector for residual check
riRes = zeros(27*3,1);
%stresses at Gauss points
sigmaEleGpt = zeros(27,6);
%% Preparation for the extrapolation of stresses from Gauss points to nodes
% Extrapolation functions associated with gauss points
Ngpt1  =zeros(nGaQuadSolid,1);
Ngpt2  =zeros(nGaQuadSolid,1);
Ngpt3  =zeros(nGaQuadSolid,1);
Ngpt4  =zeros(nGaQuadSolid,1);
Ngpt5  =zeros(nGaQuadSolid,1);
Ngpt6  =zeros(nGaQuadSolid,1);
Ngpt7  =zeros(nGaQuadSolid,1);
Ngpt8  =zeros(nGaQuadSolid,1);
Ngpt9  =zeros(nGaQuadSolid,1);
Ngpt10 =zeros(nGaQuadSolid,1);
Ngpt11 =zeros(nGaQuadSolid,1);
Ngpt12 =zeros(nGaQuadSolid,1);
Ngpt13 =zeros(nGaQuadSolid,1);
Ngpt14 =zeros(nGaQuadSolid,1);
Ngpt15 =zeros(nGaQuadSolid,1);
Ngpt16 =zeros(nGaQuadSolid,1);
Ngpt17 =zeros(nGaQuadSolid,1);
Ngpt18 =zeros(nGaQuadSolid,1);
Ngpt19 =zeros(nGaQuadSolid,1);
Ngpt20 =zeros(nGaQuadSolid,1);
Ngpt21 =zeros(nGaQuadSolid,1);
Ngpt22 =zeros(nGaQuadSolid,1);
Ngpt23 =zeros(nGaQuadSolid,1);
Ngpt24 =zeros(nGaQuadSolid,1);
Ngpt25 =zeros(nGaQuadSolid,1);
Ngpt26 =zeros(nGaQuadSolid,1);
Ngpt27 =zeros(nGaQuadSolid,1);
%
rGptMax = (1/0.774597);
sGptMax = (1/0.774597);
tGptMax = (1/0.774597);
sigmaXXatNodes = zeros(27,1);
sigmaYYatNodes = zeros(27,1);
sigmaZZatNodes = zeros(27,1);
sigmaXYatNodes = zeros(27,1);
sigmaYZatNodes = zeros(27,1);
sigmaXZatNodes = zeros(27,1);

%% Natural coordinates of nodes in Gauss-element coordinate system
NodesByGpt = [-rGptMax -sGptMax -tGptMax;
               rGptMax -sGptMax -tGptMax;
               rGptMax  sGptMax -tGptMax;
              -rGptMax  sGptMax -tGptMax;
              -rGptMax -sGptMax  tGptMax;
               rGptMax -sGptMax  tGptMax;
               rGptMax  sGptMax  tGptMax;
              -rGptMax  sGptMax  tGptMax;
                     0 -sGptMax -tGptMax;
               rGptMax        0 -tGptMax;
                     0  sGptMax -tGptMax;
              -rGptMax        0 -tGptMax;
                     0 -sGptMax  tGptMax;
               rGptMax        0  tGptMax;
                     0  sGptMax  tGptMax;
              -rGptMax        0  tGptMax;
                     0        0 -tGptMax;
                     0        0  tGptMax;
              -rGptMax -sGptMax        0;
               rGptMax -sGptMax        0;
               rGptMax  sGptMax        0;
              -rGptMax  sGptMax        0;
                     0 -sGptMax        0;
               rGptMax        0        0;
                     0  sGptMax        0;
              -rGptMax        0        0;
                     0        0        0;
                                        ];
[nNodesByGpt,m] = size(NodesByGpt);
%     for nID=1:nNodesByGpt
%         hold on
%         plotPoint = plot3(NodesByGpt(nID,1),NodesByGpt(nID,2),NodesByGpt(nID,3),'o','MarkerSize', 10);
%         text(NodesByGpt(nID,1),NodesByGpt(nID,2),NodesByGpt(nID,3),sprintf('%d',nID));
%     end
for i = 1:nNodesByGpt
    rGptNode = NodesByGpt(i,1);
    sGptNode = NodesByGpt(i,2);
    tGptNode = NodesByGpt(i,3);
    
    % Gauss-point-based extrapolation functions 
    % associated with Gauss points
    % evaluated at Nodes
    Ngpt1(i)  = 0.125*rGptNode*(rGptNode-1)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode-1); 
    Ngpt2(i)  = 0.25*rGptNode*(rGptNode-1)*sGptNode*(sGptNode-1)*(1-tGptNode^2);
    Ngpt3(i)  = 0.125*rGptNode*(rGptNode-1)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode+1);
    Ngpt4(i)  = 0.25*rGptNode*(rGptNode-1)*(1-sGptNode^2)*tGptNode*(tGptNode-1);
    Ngpt5(i)  = 0.5*rGptNode*(rGptNode-1)*(1-sGptNode^2)*(1-tGptNode^2);
    Ngpt6(i)  = 0.25*rGptNode*(rGptNode-1)*(1-sGptNode^2)*tGptNode*(tGptNode+1);
    Ngpt7(i)  = 0.125*rGptNode*(rGptNode-1)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode-1);
    Ngpt8(i)  = 0.25*rGptNode*(rGptNode-1)*sGptNode*(sGptNode+1)*(1-tGptNode^2);
    Ngpt9(i)  = 0.125*rGptNode*(rGptNode-1)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode+1);
    Ngpt10(i) = 0.25*(1-rGptNode^2)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode-1);
    Ngpt11(i) = 0.5*(1-rGptNode^2)*sGptNode*(sGptNode-1)*(1-tGptNode^2);
    Ngpt12(i) = 0.25*(1-rGptNode^2)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode+1);
    Ngpt13(i) = 0.5*(1-rGptNode^2)*(1-sGptNode^2)*tGptNode*(tGptNode-1);
    Ngpt14(i) = (1-rGptNode^2)*(1-sGptNode^2)*(1-tGptNode^2);
    Ngpt15(i) = 0.5*(1-rGptNode^2)*(1-sGptNode^2)*tGptNode*(tGptNode+1);
    Ngpt16(i) = 0.25*(1-rGptNode^2)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode-1);
    Ngpt17(i) = 0.5*(1-rGptNode^2)*sGptNode*(sGptNode+1)*(1-tGptNode^2);
    Ngpt18(i) = 0.25*(1-rGptNode^2)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode+1);
    Ngpt19(i) = 0.125*rGptNode*(rGptNode+1)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode-1);  
    Ngpt20(i) = 0.25*rGptNode*(rGptNode+1)*sGptNode*(sGptNode-1)*(1-tGptNode^2);
    Ngpt21(i) = 0.125*rGptNode*(rGptNode+1)*sGptNode*(sGptNode-1)*tGptNode*(tGptNode+1);
    Ngpt22(i) = 0.25*rGptNode*(rGptNode+1)*(1-sGptNode^2)*tGptNode*(tGptNode-1);
    Ngpt23(i) = 0.5*rGptNode*(rGptNode+1)*(1-sGptNode^2)*(1-tGptNode^2);
    Ngpt24(i) = 0.25*rGptNode*(rGptNode+1)*(1-sGptNode^2)*tGptNode*(tGptNode+1);
    Ngpt25(i) = 0.125*rGptNode*(rGptNode+1)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode-1);
    Ngpt26(i) = 0.25*rGptNode*(rGptNode+1)*sGptNode*(sGptNode+1)*(1-tGptNode^2);
    Ngpt27(i) = 0.125*rGptNode*(rGptNode+1)*sGptNode*(sGptNode+1)*tGptNode*(tGptNode+1); 
end
MinXXall = 0; MaxXXall = 0;
MinYYall = 0; MaxYYall = 0;
MinZZall = 0; MaxZZall = 0;
MinXYall = 0; MaxXYall = 0;
MinYZall = 0; MaxYZall = 0;
MinXZall = 0; MaxXZall = 0;

for eleID = 1:numEle
    for i = 1:nGaQuadSolid
        % Shape functions evaluated at Gauss point i
        N = [N1(i) N2(i) N3(i) N4(i) N5(i) N6(i) N7(i) N8(i) N9(i) N10(i) N11(i) N12(i) N13(i) N14(i) N15(i) N16(i) N17(i) N18(i) N19(i) N20(i) N21(i) N22(i) N23(i) N24(i) N25(i) N26(i) N27(i)];
        w = GaussQuadraticSolid(i,4);

        % Partial derivatives of the shape functions evaluated at Gauss point
        dNr = [dN1r(i) dN2r(i) dN3r(i) dN4r(i) dN5r(i) dN6r(i) dN7r(i) dN8r(i) dN9r(i) dN10r(i) dN11r(i) dN12r(i) dN13r(i) dN14r(i) dN15r(i) dN16r(i) dN17r(i) dN18r(i) dN19r(i) dN20r(i) dN21r(i) dN22r(i) dN23r(i) dN24r(i) dN25r(i) dN26r(i) dN27r(i)];
        dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i) dN5s(i) dN6s(i) dN7s(i) dN8s(i) dN9s(i) dN10s(i) dN11s(i) dN12s(i) dN13s(i) dN14s(i) dN15s(i) dN16s(i) dN17s(i) dN18s(i) dN19s(i) dN20s(i) dN21s(i) dN22s(i) dN23s(i) dN24s(i) dN25s(i) dN26s(i) dN27s(i)];
        dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i) dN5t(i) dN6t(i) dN7t(i) dN8t(i) dN9t(i) dN10t(i) dN11t(i) dN12t(i) dN13t(i) dN14t(i) dN15t(i) dN16t(i) dN17t(i) dN18t(i) dN19t(i) dN20t(i) dN21t(i) dN22t(i) dN23t(i) dN24t(i) dN25t(i) dN26t(i) dN27t(i)];

        % Initial Configuration's quantities evaluated at Gauss point
        % The FEM mapping
        Xcoords = [coords(ele(eleID,1),1) coords(ele(eleID,2),1) coords(ele(eleID,3),1) coords(ele(eleID,4),1) coords(ele(eleID,5),1) coords(ele(eleID,6),1) coords(ele(eleID,7),1) coords(ele(eleID,8),1) coords(ele(eleID,9),1) coords(ele(eleID,10),1) coords(ele(eleID,11),1) coords(ele(eleID,12),1) coords(ele(eleID,13),1) coords(ele(eleID,14),1) coords(ele(eleID,15),1) coords(ele(eleID,16),1) coords(ele(eleID,17),1) coords(ele(eleID,18),1) coords(ele(eleID,19),1) coords(ele(eleID,20),1) coords(ele(eleID,21),1) coords(ele(eleID,22),1) coords(ele(eleID,23),1) coords(ele(eleID,24),1) coords(ele(eleID,25),1) coords(ele(eleID,26),1) coords(ele(eleID,27),1)]';
        Ycoords = [coords(ele(eleID,1),2) coords(ele(eleID,2),2) coords(ele(eleID,3),2) coords(ele(eleID,4),2) coords(ele(eleID,5),2) coords(ele(eleID,6),2) coords(ele(eleID,7),2) coords(ele(eleID,8),2) coords(ele(eleID,9),2) coords(ele(eleID,10),2) coords(ele(eleID,11),2) coords(ele(eleID,12),2) coords(ele(eleID,13),2) coords(ele(eleID,14),2) coords(ele(eleID,15),2) coords(ele(eleID,16),2) coords(ele(eleID,17),2) coords(ele(eleID,18),2) coords(ele(eleID,19),2) coords(ele(eleID,20),2) coords(ele(eleID,21),2) coords(ele(eleID,22),2) coords(ele(eleID,23),2) coords(ele(eleID,24),2) coords(ele(eleID,25),2) coords(ele(eleID,26),2) coords(ele(eleID,27),2)]';        
        Zcoords = [coords(ele(eleID,1),3) coords(ele(eleID,2),3) coords(ele(eleID,3),3) coords(ele(eleID,4),3) coords(ele(eleID,5),3) coords(ele(eleID,6),3) coords(ele(eleID,7),3) coords(ele(eleID,8),3) coords(ele(eleID,9),3) coords(ele(eleID,10),3) coords(ele(eleID,11),3) coords(ele(eleID,12),3) coords(ele(eleID,13),3) coords(ele(eleID,14),3) coords(ele(eleID,15),3) coords(ele(eleID,16),3) coords(ele(eleID,17),3) coords(ele(eleID,18),3) coords(ele(eleID,19),3) coords(ele(eleID,20),3) coords(ele(eleID,21),3) coords(ele(eleID,22),3) coords(ele(eleID,23),3) coords(ele(eleID,24),3) coords(ele(eleID,25),3) coords(ele(eleID,26),3) coords(ele(eleID,27),3)]';

        Jfem11 = dNr*Xcoords;
        Jfem12 = dNs*Xcoords;
        Jfem13 = dNt*Xcoords;
        Jfem21 = dNr*Ycoords;
        Jfem22 = dNs*Ycoords;
        Jfem23 = dNt*Ycoords;
        Jfem31 = dNr*Zcoords;
        Jfem32 = dNs*Zcoords;
        Jfem33 = dNt*Zcoords;

        Jfem = [Jfem11 Jfem12 Jfem13;
                Jfem21 Jfem22 Jfem23;
                Jfem31 Jfem32 Jfem33];
        detJfem = det(Jfem);

        %% Update the position of the current configuration
        XcoordsCurEle = [coordsCur(ele(eleID,1),1) coordsCur(ele(eleID,2),1) coordsCur(ele(eleID,3),1) coordsCur(ele(eleID,4),1) coordsCur(ele(eleID,5),1) coordsCur(ele(eleID,6),1) coordsCur(ele(eleID,7),1) coordsCur(ele(eleID,8),1) coordsCur(ele(eleID,9),1) coordsCur(ele(eleID,10),1) coordsCur(ele(eleID,11),1) coordsCur(ele(eleID,12),1) coordsCur(ele(eleID,13),1) coordsCur(ele(eleID,14),1) coordsCur(ele(eleID,15),1) coordsCur(ele(eleID,16),1) coordsCur(ele(eleID,17),1) coordsCur(ele(eleID,18),1) coordsCur(ele(eleID,19),1) coordsCur(ele(eleID,20),1) coordsCur(ele(eleID,21),1) coordsCur(ele(eleID,22),1) coordsCur(ele(eleID,23),1) coordsCur(ele(eleID,24),1) coordsCur(ele(eleID,25),1) coordsCur(ele(eleID,26),1) coordsCur(ele(eleID,27),1)]';
        YcoordsCurEle = [coordsCur(ele(eleID,1),2) coordsCur(ele(eleID,2),2) coordsCur(ele(eleID,3),2) coordsCur(ele(eleID,4),2) coordsCur(ele(eleID,5),2) coordsCur(ele(eleID,6),2) coordsCur(ele(eleID,7),2) coordsCur(ele(eleID,8),2) coordsCur(ele(eleID,9),2) coordsCur(ele(eleID,10),2) coordsCur(ele(eleID,11),2) coordsCur(ele(eleID,12),2) coordsCur(ele(eleID,13),2) coordsCur(ele(eleID,14),2) coordsCur(ele(eleID,15),2) coordsCur(ele(eleID,16),2) coordsCur(ele(eleID,17),2) coordsCur(ele(eleID,18),2) coordsCur(ele(eleID,19),2) coordsCur(ele(eleID,20),2) coordsCur(ele(eleID,21),2) coordsCur(ele(eleID,22),2) coordsCur(ele(eleID,23),2) coordsCur(ele(eleID,24),2) coordsCur(ele(eleID,25),2) coordsCur(ele(eleID,26),2) coordsCur(ele(eleID,27),2)]';        
        ZcoordsCurEle = [coordsCur(ele(eleID,1),3) coordsCur(ele(eleID,2),3) coordsCur(ele(eleID,3),3) coordsCur(ele(eleID,4),3) coordsCur(ele(eleID,5),3) coordsCur(ele(eleID,6),3) coordsCur(ele(eleID,7),3) coordsCur(ele(eleID,8),3) coordsCur(ele(eleID,9),3) coordsCur(ele(eleID,10),3) coordsCur(ele(eleID,11),3) coordsCur(ele(eleID,12),3) coordsCur(ele(eleID,13),3) coordsCur(ele(eleID,14),3) coordsCur(ele(eleID,15),3) coordsCur(ele(eleID,16),3) coordsCur(ele(eleID,17),3) coordsCur(ele(eleID,18),3) coordsCur(ele(eleID,19),3) coordsCur(ele(eleID,20),3) coordsCur(ele(eleID,21),3) coordsCur(ele(eleID,22),3) coordsCur(ele(eleID,23),3) coordsCur(ele(eleID,24),3) coordsCur(ele(eleID,25),3) coordsCur(ele(eleID,26),3) coordsCur(ele(eleID,27),3)]';

        Jfem11Cur = dNr*XcoordsCurEle; %dxCur/dr
        Jfem12Cur = dNs*XcoordsCurEle; %dxCur/ds
        Jfem13Cur = dNt*XcoordsCurEle; %dxCur/dt
        Jfem21Cur = dNr*YcoordsCurEle;
        Jfem22Cur = dNs*YcoordsCurEle;
        Jfem23Cur = dNt*YcoordsCurEle;
        Jfem31Cur = dNr*ZcoordsCurEle;
        Jfem32Cur = dNs*ZcoordsCurEle;
        Jfem33Cur = dNt*ZcoordsCurEle;

        JfemCur = [Jfem11Cur Jfem12Cur Jfem13Cur;
                   Jfem21Cur Jfem22Cur Jfem23Cur;
                   Jfem31Cur Jfem32Cur Jfem33Cur];
        detJfemCur = det(JfemCur);

        %% calculate F  & Fbar
        dxCurdx0dy0dz0 = inv(Jfem)'*[Jfem11Cur Jfem12Cur Jfem13Cur]';
        dyCurdx0dy0dz0 = inv(Jfem)'*[Jfem21Cur Jfem22Cur Jfem23Cur]';
        dzCurdx0dy0dz0 = inv(Jfem)'*[Jfem31Cur Jfem32Cur Jfem33Cur]';
        %deformation gradient
        F = [dxCurdx0dy0dz0';
             dyCurdx0dy0dz0';
             dzCurdx0dy0dz0'];
        Fbar = [diag(dxCurdx0dy0dz0)                  diag(dyCurdx0dy0dz0)                  diag(dzCurdx0dy0dz0);
                dxCurdx0dy0dz0(2) dxCurdx0dy0dz0(1) 0 dyCurdx0dy0dz0(2) dyCurdx0dy0dz0(1) 0 dzCurdx0dy0dz0(2) dzCurdx0dy0dz0(1) 0;
                0 dxCurdx0dy0dz0(3) dxCurdx0dy0dz0(2) 0 dyCurdx0dy0dz0(3) dyCurdx0dy0dz0(2) 0 dzCurdx0dy0dz0(3) dzCurdx0dy0dz0(2);
                dxCurdx0dy0dz0(3) 0 dxCurdx0dy0dz0(1) dyCurdx0dy0dz0(3) 0 dyCurdx0dy0dz0(1) dzCurdx0dy0dz0(3) 0 dzCurdx0dy0dz0(1)];
        detF = det(F);

        %left Cauchy Green tensor
        if strcmp(MAT,'NeoHookean') == 1
        %% Hyperelastic
            %left Cauchy Green tensor
            b = F*F';
            sigmaHat = (lamda/detF)*log(detF)*eye(3) + (mu/detF)*(b-eye(3));
        end
        %Note: the stresses are evaluated at Gauss point i
        sigmaEleGpt(i,:) = [sigmaHat(1,1) sigmaHat(2,2) sigmaHat(3,3) sigmaHat(1,2) sigmaHat(2,3) sigmaHat(1,3)];

    end
    
    %Rearrange stress tensor at 27 Gauss points in vector form: sigmaXX, sigmaYY sigmaXY
    sigmaXXatGpt = sigmaEleGpt(:,1);
    sigmaYYatGpt = sigmaEleGpt(:,2);
    sigmaZZatGpt = sigmaEleGpt(:,3);
    sigmaXYatGpt = sigmaEleGpt(:,4);
    sigmaYZatGpt = sigmaEleGpt(:,5);
    sigmaXZatGpt = sigmaEleGpt(:,6);
    %% Calculation of stress at nodes, following the node-order
    for i = 1:nNodesByGpt

        Ngpt = [Ngpt1(i) Ngpt2(i) Ngpt3(i) Ngpt4(i) Ngpt5(i) Ngpt6(i) Ngpt7(i) Ngpt8(i) Ngpt9(i) Ngpt10(i) Ngpt11(i) Ngpt12(i) Ngpt13(i) Ngpt14(i) Ngpt15(i) Ngpt16(i) Ngpt17(i) Ngpt18(i) Ngpt19(i) Ngpt20(i) Ngpt21(i) Ngpt22(i) Ngpt23(i) Ngpt24(i) Ngpt25(i) Ngpt26(i) Ngpt27(i)];
        sigmaXXatNodes(i) = Ngpt*sigmaXXatGpt;
        sigmaYYatNodes(i) = Ngpt*sigmaYYatGpt;
        sigmaZZatNodes(i) = Ngpt*sigmaZZatGpt;
        sigmaXYatNodes(i) = Ngpt*sigmaXYatGpt;
        sigmaYZatNodes(i) = Ngpt*sigmaYZatGpt;
        sigmaXZatNodes(i) = Ngpt*sigmaXZatGpt;
        
    end
    
    MinXXele = min(sigmaXXatNodes); MaxXXele = max(sigmaXXatNodes);
    if MinXXele < MinXXall
        MinXXall = MinXXele;
    end
    if MaxXXele > MaxXXall
        MaxXXall = MaxXXele;
    end
    
    MinYYele = min(sigmaYYatNodes); MaxYYele = max(sigmaYYatNodes);
    if MinYYele < MinYYall
        MinYYall = MinYYele;
    end
    if MaxYYele > MaxYYall
        MaxYYall = MaxYYele;
    end
    
    MinZZele = min(sigmaZZatNodes); MaxZZele = max(sigmaZZatNodes);
    if MinZZele < MinZZall
        MinZZall = MinZZele;
    end
    if MaxZZele > MaxZZall
        MaxZZall = MaxZZele;
    end
    
    MinXYele = min(sigmaXYatNodes); MaxXYele = max(sigmaXYatNodes);
    if MinXYele < MinXYall
        MinXYall = MinXYele;
    end
    if MaxXYele > MaxXYall
        MaxXYall = MaxXYele;
    end
    
    MinYZele = min(sigmaYZatNodes); MaxYZele = max(sigmaYZatNodes);
    if MinYZele < MinYZall
        MinYZall = MinYZele;
    end
    if MaxYZele > MaxYZall
        MaxYZall = MaxYZele;
    end
    
    MinXZele = min(sigmaXZatNodes); MaxXZele = max(sigmaXZatNodes);
    if MinXZele < MinXZall
        MinXZall = MinXZele;
    end
    if MaxXZele > MaxXZall
        MaxXZall = MaxXZele;
    end
    
    %Plot
    %
    XCoordsCurEleFace1 = [XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,9)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,10)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,11)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,12)) XcoordsCur(ele(eleID,1))];
    YCoordsCurEleFace1 = [YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,9)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,10)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,11)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,12)) YcoordsCur(ele(eleID,1))];
    ZCoordsCurEleFace1 = [ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,9)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,10)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,11)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,12)) ZcoordsCur(ele(eleID,1))];        
    %
    sigmaXXatNodesFace1 = [sigmaXXatNodes(1) sigmaXXatNodes(9) sigmaXXatNodes(2) sigmaXXatNodes(10) sigmaXXatNodes(3) sigmaXXatNodes(11) sigmaXXatNodes(4) sigmaXXatNodes(12) sigmaXXatNodes(1)];
    sigmaYYatNodesFace1 = [sigmaYYatNodes(1) sigmaYYatNodes(9) sigmaYYatNodes(2) sigmaYYatNodes(10) sigmaYYatNodes(3) sigmaYYatNodes(11) sigmaYYatNodes(4) sigmaYYatNodes(12) sigmaYYatNodes(1)];
	sigmaZZatNodesFace1 = [sigmaZZatNodes(1) sigmaZZatNodes(9) sigmaZZatNodes(2) sigmaZZatNodes(10) sigmaZZatNodes(3) sigmaZZatNodes(11) sigmaZZatNodes(4) sigmaZZatNodes(12) sigmaZZatNodes(1)];
    sigmaXYatNodesFace1 = [sigmaXYatNodes(1) sigmaXYatNodes(9) sigmaXYatNodes(2) sigmaXYatNodes(10) sigmaXYatNodes(3) sigmaXYatNodes(11) sigmaXYatNodes(4) sigmaXYatNodes(12) sigmaXYatNodes(1)];
    sigmaYZatNodesFace1 = [sigmaYZatNodes(1) sigmaYZatNodes(9) sigmaYZatNodes(2) sigmaYZatNodes(10) sigmaYZatNodes(3) sigmaYZatNodes(11) sigmaYZatNodes(4) sigmaYZatNodes(12) sigmaYZatNodes(1)];
    sigmaXZatNodesFace1 = [sigmaXZatNodes(1) sigmaXZatNodes(9) sigmaXZatNodes(2) sigmaXZatNodes(10) sigmaXZatNodes(3) sigmaXZatNodes(11) sigmaXZatNodes(4) sigmaXZatNodes(12) sigmaXZatNodes(1)];
    %
        %
    XCoordsCurEleFace2 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,13)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,14)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,15)) XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,16)) XcoordsCur(ele(eleID,5))];
    YCoordsCurEleFace2 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,13)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,14)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,15)) YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,16)) YcoordsCur(ele(eleID,5))];
    ZCoordsCurEleFace2 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,13)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,14)) ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,15)) ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,16)) ZcoordsCur(ele(eleID,5))];        
    %
    sigmaXXatNodesFace2 = [sigmaXXatNodes(5) sigmaXXatNodes(13) sigmaXXatNodes(6) sigmaXXatNodes(14) sigmaXXatNodes(7) sigmaXXatNodes(15) sigmaXXatNodes(8) sigmaXXatNodes(16) sigmaXXatNodes(5)];
    sigmaYYatNodesFace2 = [sigmaYYatNodes(5) sigmaYYatNodes(13) sigmaYYatNodes(6) sigmaYYatNodes(14) sigmaYYatNodes(7) sigmaYYatNodes(15) sigmaYYatNodes(8) sigmaYYatNodes(16) sigmaYYatNodes(5)];
	sigmaZZatNodesFace2 = [sigmaZZatNodes(5) sigmaZZatNodes(13) sigmaZZatNodes(6) sigmaZZatNodes(14) sigmaZZatNodes(7) sigmaZZatNodes(15) sigmaZZatNodes(8) sigmaZZatNodes(16) sigmaZZatNodes(5)];
    sigmaXYatNodesFace2 = [sigmaXYatNodes(5) sigmaXYatNodes(13) sigmaXYatNodes(6) sigmaXYatNodes(14) sigmaXYatNodes(7) sigmaXYatNodes(15) sigmaXYatNodes(8) sigmaXYatNodes(16) sigmaXYatNodes(5)];
    sigmaYZatNodesFace2 = [sigmaYZatNodes(5) sigmaYZatNodes(13) sigmaYZatNodes(6) sigmaYZatNodes(14) sigmaYZatNodes(7) sigmaYZatNodes(15) sigmaYZatNodes(8) sigmaYZatNodes(16) sigmaYZatNodes(5)];
    sigmaXZatNodesFace2 = [sigmaXZatNodes(5) sigmaXZatNodes(13) sigmaXZatNodes(6) sigmaXZatNodes(14) sigmaXZatNodes(7) sigmaXZatNodes(15) sigmaXZatNodes(8) sigmaXZatNodes(16) sigmaXZatNodes(5)];
    %
    XCoordsCurEleFace3 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,13)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,18)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,9)) XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,17)) XcoordsCur(ele(eleID,5))];
    YCoordsCurEleFace3 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,13)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,18)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,9)) YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,17)) YcoordsCur(ele(eleID,5))];
    ZCoordsCurEleFace3 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,13)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,18)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,9)) ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,17)) ZcoordsCur(ele(eleID,5))];        
    %
    sigmaXXatNodesFace3 = [sigmaXXatNodes(5) sigmaXXatNodes(13) sigmaXXatNodes(6) sigmaXXatNodes(18) sigmaXXatNodes(2) sigmaXXatNodes(9) sigmaXXatNodes(1) sigmaXXatNodes(17) sigmaXXatNodes(5)];
    sigmaYYatNodesFace3 = [sigmaYYatNodes(5) sigmaYYatNodes(13) sigmaYYatNodes(6) sigmaYYatNodes(18) sigmaYYatNodes(2) sigmaYYatNodes(9) sigmaYYatNodes(1) sigmaYYatNodes(17) sigmaYYatNodes(5)];
	sigmaZZatNodesFace3 = [sigmaZZatNodes(5) sigmaZZatNodes(13) sigmaZZatNodes(6) sigmaZZatNodes(18) sigmaZZatNodes(2) sigmaZZatNodes(9) sigmaZZatNodes(1) sigmaZZatNodes(17) sigmaZZatNodes(5)];
    sigmaXYatNodesFace3 = [sigmaXYatNodes(5) sigmaXYatNodes(13) sigmaXYatNodes(6) sigmaXYatNodes(18) sigmaXYatNodes(2) sigmaXYatNodes(9) sigmaXYatNodes(1) sigmaXYatNodes(17) sigmaXYatNodes(5)];
    sigmaYZatNodesFace3 = [sigmaYZatNodes(5) sigmaYZatNodes(13) sigmaYZatNodes(6) sigmaYZatNodes(18) sigmaYZatNodes(2) sigmaYZatNodes(9) sigmaYZatNodes(1) sigmaYZatNodes(17) sigmaYZatNodes(5)];
    sigmaXZatNodesFace3 = [sigmaXZatNodes(5) sigmaXZatNodes(13) sigmaXZatNodes(6) sigmaXZatNodes(18) sigmaXZatNodes(2) sigmaXZatNodes(9) sigmaXZatNodes(1) sigmaXZatNodes(17) sigmaXZatNodes(5)];
    %
    XCoordsCurEleFace4 = [XcoordsCur(ele(eleID,5)) XcoordsCur(ele(eleID,16)) XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,20)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,12)) XcoordsCur(ele(eleID,1)) XcoordsCur(ele(eleID,17)) XcoordsCur(ele(eleID,5))];
    YCoordsCurEleFace4 = [YcoordsCur(ele(eleID,5)) YcoordsCur(ele(eleID,16)) YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,20)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,12)) YcoordsCur(ele(eleID,1)) YcoordsCur(ele(eleID,17)) YcoordsCur(ele(eleID,5))];
    ZCoordsCurEleFace4 = [ZcoordsCur(ele(eleID,5)) ZcoordsCur(ele(eleID,16)) ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,20)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,12)) ZcoordsCur(ele(eleID,1)) ZcoordsCur(ele(eleID,17)) ZcoordsCur(ele(eleID,5))];        
    %
    sigmaXXatNodesFace4 = [sigmaXXatNodes(5) sigmaXXatNodes(16) sigmaXXatNodes(8) sigmaXXatNodes(20) sigmaXXatNodes(4) sigmaXXatNodes(12) sigmaXXatNodes(1) sigmaXXatNodes(17) sigmaXXatNodes(5)];
    sigmaYYatNodesFace4 = [sigmaYYatNodes(5) sigmaYYatNodes(16) sigmaYYatNodes(8) sigmaYYatNodes(20) sigmaYYatNodes(4) sigmaYYatNodes(12) sigmaYYatNodes(1) sigmaYYatNodes(17) sigmaYYatNodes(5)];
	sigmaZZatNodesFace4 = [sigmaZZatNodes(5) sigmaZZatNodes(16) sigmaZZatNodes(8) sigmaZZatNodes(20) sigmaZZatNodes(4) sigmaZZatNodes(12) sigmaZZatNodes(1) sigmaZZatNodes(17) sigmaZZatNodes(5)];
    sigmaXYatNodesFace4 = [sigmaXYatNodes(5) sigmaXYatNodes(16) sigmaXYatNodes(8) sigmaXYatNodes(20) sigmaXYatNodes(4) sigmaXYatNodes(12) sigmaXYatNodes(1) sigmaXYatNodes(17) sigmaXYatNodes(5)];
    sigmaYZatNodesFace4 = [sigmaYZatNodes(5) sigmaYZatNodes(16) sigmaYZatNodes(8) sigmaYZatNodes(20) sigmaYZatNodes(4) sigmaYZatNodes(12) sigmaYZatNodes(1) sigmaYZatNodes(17) sigmaYZatNodes(5)];
    sigmaXZatNodesFace4 = [sigmaXZatNodes(5) sigmaXZatNodes(16) sigmaXZatNodes(8) sigmaXZatNodes(20) sigmaXZatNodes(4) sigmaXZatNodes(12) sigmaXZatNodes(1) sigmaXZatNodes(17) sigmaXZatNodes(5)];
    %
    XCoordsCurEleFace5 = [XcoordsCur(ele(eleID,8)) XcoordsCur(ele(eleID,15)) XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,19)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,11)) XcoordsCur(ele(eleID,4)) XcoordsCur(ele(eleID,20)) XcoordsCur(ele(eleID,8))];
    YCoordsCurEleFace5 = [YcoordsCur(ele(eleID,8)) YcoordsCur(ele(eleID,15)) YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,19)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,11)) YcoordsCur(ele(eleID,4)) YcoordsCur(ele(eleID,20)) YcoordsCur(ele(eleID,8))];
    ZCoordsCurEleFace5 = [ZcoordsCur(ele(eleID,8)) ZcoordsCur(ele(eleID,15)) ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,19)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,11)) ZcoordsCur(ele(eleID,4)) ZcoordsCur(ele(eleID,20)) ZcoordsCur(ele(eleID,8))];        
    %
    sigmaXXatNodesFace5 = [sigmaXXatNodes(8) sigmaXXatNodes(15) sigmaXXatNodes(7) sigmaXXatNodes(19) sigmaXXatNodes(3) sigmaXXatNodes(11) sigmaXXatNodes(4) sigmaXXatNodes(20) sigmaXXatNodes(8)];
    sigmaYYatNodesFace5 = [sigmaYYatNodes(8) sigmaYYatNodes(15) sigmaYYatNodes(7) sigmaYYatNodes(19) sigmaYYatNodes(3) sigmaYYatNodes(11) sigmaYYatNodes(4) sigmaYYatNodes(20) sigmaYYatNodes(8)];
	sigmaZZatNodesFace5 = [sigmaZZatNodes(8) sigmaZZatNodes(15) sigmaZZatNodes(7) sigmaZZatNodes(19) sigmaZZatNodes(3) sigmaZZatNodes(11) sigmaZZatNodes(4) sigmaZZatNodes(20) sigmaZZatNodes(8)];
    sigmaXYatNodesFace5 = [sigmaXYatNodes(8) sigmaXYatNodes(15) sigmaXYatNodes(7) sigmaXYatNodes(19) sigmaXYatNodes(3) sigmaXYatNodes(11) sigmaXYatNodes(4) sigmaXYatNodes(20) sigmaXYatNodes(8)];
    sigmaYZatNodesFace5 = [sigmaYZatNodes(8) sigmaYZatNodes(15) sigmaYZatNodes(7) sigmaYZatNodes(19) sigmaYZatNodes(3) sigmaYZatNodes(11) sigmaYZatNodes(4) sigmaYZatNodes(20) sigmaYZatNodes(8)];
    sigmaXZatNodesFace5 = [sigmaXZatNodes(8) sigmaXZatNodes(15) sigmaXZatNodes(7) sigmaXZatNodes(19) sigmaXZatNodes(3) sigmaXZatNodes(11) sigmaXZatNodes(4) sigmaXZatNodes(20) sigmaXZatNodes(8)];
    %
    %
    XCoordsCurEleFace6 = [XcoordsCur(ele(eleID,7)) XcoordsCur(ele(eleID,14)) XcoordsCur(ele(eleID,6)) XcoordsCur(ele(eleID,18)) XcoordsCur(ele(eleID,2)) XcoordsCur(ele(eleID,10)) XcoordsCur(ele(eleID,3)) XcoordsCur(ele(eleID,19)) XcoordsCur(ele(eleID,7))];
    YCoordsCurEleFace6 = [YcoordsCur(ele(eleID,7)) YcoordsCur(ele(eleID,14)) YcoordsCur(ele(eleID,6)) YcoordsCur(ele(eleID,18)) YcoordsCur(ele(eleID,2)) YcoordsCur(ele(eleID,10)) YcoordsCur(ele(eleID,3)) YcoordsCur(ele(eleID,19)) YcoordsCur(ele(eleID,7))];
    ZCoordsCurEleFace6 = [ZcoordsCur(ele(eleID,7)) ZcoordsCur(ele(eleID,14)) ZcoordsCur(ele(eleID,6)) ZcoordsCur(ele(eleID,18)) ZcoordsCur(ele(eleID,2)) ZcoordsCur(ele(eleID,10)) ZcoordsCur(ele(eleID,3)) ZcoordsCur(ele(eleID,19)) ZcoordsCur(ele(eleID,7))];        
    %
    sigmaXXatNodesFace6 = [sigmaXXatNodes(7) sigmaXXatNodes(14) sigmaXXatNodes(6) sigmaXXatNodes(18) sigmaXXatNodes(2) sigmaXXatNodes(10) sigmaXXatNodes(3) sigmaXXatNodes(19) sigmaXXatNodes(7)];
    sigmaYYatNodesFace6 = [sigmaYYatNodes(7) sigmaYYatNodes(14) sigmaYYatNodes(6) sigmaYYatNodes(18) sigmaYYatNodes(2) sigmaYYatNodes(10) sigmaYYatNodes(3) sigmaYYatNodes(19) sigmaYYatNodes(7)];
	sigmaZZatNodesFace6 = [sigmaZZatNodes(7) sigmaZZatNodes(14) sigmaZZatNodes(6) sigmaZZatNodes(18) sigmaZZatNodes(2) sigmaZZatNodes(10) sigmaZZatNodes(3) sigmaZZatNodes(19) sigmaZZatNodes(7)];
    sigmaXYatNodesFace6 = [sigmaXYatNodes(7) sigmaXYatNodes(14) sigmaXYatNodes(6) sigmaXYatNodes(18) sigmaXYatNodes(2) sigmaXYatNodes(10) sigmaXYatNodes(3) sigmaXYatNodes(19) sigmaXYatNodes(7)];
    sigmaYZatNodesFace6 = [sigmaYZatNodes(7) sigmaYZatNodes(14) sigmaYZatNodes(6) sigmaYZatNodes(18) sigmaYZatNodes(2) sigmaYZatNodes(10) sigmaYZatNodes(3) sigmaYZatNodes(19) sigmaYZatNodes(7)];
    sigmaXZatNodesFace6 = [sigmaXZatNodes(7) sigmaXZatNodes(14) sigmaXZatNodes(6) sigmaXZatNodes(18) sigmaXZatNodes(2) sigmaXZatNodes(10) sigmaXZatNodes(3) sigmaXZatNodes(19) sigmaXZatNodes(7)];
    subplot(2,3,1)
    hold on
    plotStressNodalExpoXXFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaXXatNodesFace1);
    plotStressNodalExpoXXFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaXXatNodesFace2);
    plotStressNodalExpoXXFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaXXatNodesFace3);
    plotStressNodalExpoXXFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaXXatNodesFace4);
    plotStressNodalExpoXXFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaXXatNodesFace5);
    plotStressNodalExpoXXFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaXXatNodesFace6);
    subplot(2,3,2)
    hold on
    plotStressNodalExpoYYFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaYYatNodesFace1);
    plotStressNodalExpoYYFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaYYatNodesFace2);
    plotStressNodalExpoYYFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaYYatNodesFace3);
    plotStressNodalExpoYYFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaYYatNodesFace4);
    plotStressNodalExpoYYFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaYYatNodesFace5);
    plotStressNodalExpoYYFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaYYatNodesFace6);
    subplot(2,3,4)
    
    hold on
    plotStressNodalExpoZZFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaZZatNodesFace1);
    plotStressNodalExpoZZFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaZZatNodesFace2);
    plotStressNodalExpoZZFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaZZatNodesFace3);
    plotStressNodalExpoZZFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaZZatNodesFace4);
    plotStressNodalExpoZZFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaZZatNodesFace5);
    plotStressNodalExpoZZFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaZZatNodesFace6);
    
    subplot(2,3,3)
    hold on
    plotStressNodalExpoXYFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaXYatNodesFace1);
    plotStressNodalExpoXYFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaXYatNodesFace2);
    plotStressNodalExpoXYFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaXYatNodesFace3);
    plotStressNodalExpoXYFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaXYatNodesFace4);
    plotStressNodalExpoXYFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaXYatNodesFace5);
    plotStressNodalExpoXYFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaXYatNodesFace6);
    subplot(2,3,5)
    hold on
    plotStressNodalExpoYZFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaYZatNodesFace1);
    plotStressNodalExpoYZFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaYZatNodesFace2);
    plotStressNodalExpoYZFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaYZatNodesFace3);
    plotStressNodalExpoYZFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaYZatNodesFace4);
    plotStressNodalExpoYZFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaYZatNodesFace5);
    plotStressNodalExpoYZFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaYZatNodesFace6);
    subplot(2,3,6)
    hold on
    plotStressNodalExpoXZFace1 = fill3(XCoordsCurEleFace1,YCoordsCurEleFace1,ZCoordsCurEleFace1,sigmaXZatNodesFace1);
    plotStressNodalExpoXZFace2 = fill3(XCoordsCurEleFace2,YCoordsCurEleFace2,ZCoordsCurEleFace2,sigmaXZatNodesFace2);
    plotStressNodalExpoXZFace3 = fill3(XCoordsCurEleFace3,YCoordsCurEleFace3,ZCoordsCurEleFace3,sigmaXZatNodesFace3);
    plotStressNodalExpoXZFace4 = fill3(XCoordsCurEleFace4,YCoordsCurEleFace4,ZCoordsCurEleFace4,sigmaXZatNodesFace4);
    plotStressNodalExpoXZFace5 = fill3(XCoordsCurEleFace5,YCoordsCurEleFace5,ZCoordsCurEleFace5,sigmaXZatNodesFace5);
    plotStressNodalExpoXZFace6 = fill3(XCoordsCurEleFace6,YCoordsCurEleFace6,ZCoordsCurEleFace6,sigmaXZatNodesFace6);
    colorbar
    plot = [plotStressNodalExpoXXFace1 plotStressNodalExpoYYFace1 plotStressNodalExpoZZFace1 plotStressNodalExpoXYFace1 plotStressNodalExpoYZFace1 plotStressNodalExpoXZFace1;
            plotStressNodalExpoXXFace2 plotStressNodalExpoYYFace2 plotStressNodalExpoZZFace2 plotStressNodalExpoXYFace2 plotStressNodalExpoYZFace2 plotStressNodalExpoXZFace2;
            plotStressNodalExpoXXFace3 plotStressNodalExpoYYFace3 plotStressNodalExpoZZFace3 plotStressNodalExpoXYFace3 plotStressNodalExpoYZFace3 plotStressNodalExpoXZFace3;
            plotStressNodalExpoXXFace4 plotStressNodalExpoYYFace4 plotStressNodalExpoZZFace4 plotStressNodalExpoXYFace4 plotStressNodalExpoYZFace4 plotStressNodalExpoXZFace4;
            plotStressNodalExpoXXFace5 plotStressNodalExpoYYFace5 plotStressNodalExpoZZFace5 plotStressNodalExpoXYFace5 plotStressNodalExpoYZFace5 plotStressNodalExpoXZFace5;
            plotStressNodalExpoXXFace6 plotStressNodalExpoYYFace6 plotStressNodalExpoZZFace6 plotStressNodalExpoXYFace6 plotStressNodalExpoYZFace6 plotStressNodalExpoXZFace6];
end
subplot(2,3,1)
% title('Sigma-XX')
h1 = colorbar;
colormap jet
h1.Label.String = sprintf('Min = %f, Max = %f',MinXXall,MaxXXall);

subplot(2,3,2)
% title('Sigma-YY')
h2 = colorbar;
colormap jet
h2.Label.String = sprintf('Min = %f, Max = %f',MinYYall,MaxYYall);

subplot(2,3,3)
h3 = colorbar;
colormap jet
% title('Sigma-XY')

h3.Label.String = sprintf('Min = %f, Max = %f',MinZZall,MaxZZall);

subplot(2,3,4)
h4 = colorbar;
colormap jet
% title('Sigma-ZZ')
h4.Label.String = sprintf('Min = %f, Max = %f',MinXYall,MaxXYall);

subplot(2,3,5)
h5 = colorbar;
colormap jet
% title('Sigma-YZ')
h5.Label.String = sprintf('Min = %f, Max = %f',MinYZall,MaxYZall);

subplot(2,3,6)
h6 = colorbar;
colormap jet
% title('Sigma-XZ')
h6.Label.String = sprintf('Min = %f, Max = %f',MinXZall,MaxXZall);
end