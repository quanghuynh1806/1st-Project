%% Description: Generation of the mesh from the Cook's membrane geometry and related quantites
%% Variable description
%% Input
    % Vertices: 4 Vertices of the Cook's membrane (4 edges)
    % numNodesSide:  number of nodes on each edge of the membrane
%% Output
    % Mesh related:
        % coords: a matix with each row containing x & y coordinates of the
                % node in the undeformed state. The row index is also the node id
        % ele: a matrix with each row containing the ids of all nodes belonged
                % to the element. The row index is also the element id.
    % Other related quantites:
        % nodesOnLineLoad: all nodes at the RIGHT edge are applied with the
                         % distributed load
        % DirNodes: all nodes on the LEFT edge are displacement-constrained
        % numNodes: the total number of nodes generated
        % numEle: the total number of elements generated
%% Note:
        % all the variables above are grouped into a struct
        % "CookMembraneMeshOutput"   
function CookMembraneMeshOutput = CookMembraneMesh(Vertices,numNodesSide)
    numIntervals = numNodesSide-1;
    yIntervalLeft = (Vertices(4,2) - Vertices(1,2))/numIntervals;
    yIntervalRight = (Vertices(3,2) - Vertices(2,2))/numIntervals;
    xInterval = (Vertices(2,1)-Vertices(1,1))/numIntervals;
    %% Generate NODES on the domain and plot (m+1)*(n+1) nodes
    %% x and y coordinates of each node
    coords = [];
    k = 1;
%     figure(1)
    hold on
    for i = 1:numNodesSide

        for j = 1:numNodesSide

            coords(k,1) = (j-1)*xInterval;
            coords(k,2) = Vertices(1,2)+(i-1)*yIntervalLeft + (j-1)*(Vertices(2,2)+ (i-1)*yIntervalRight - Vertices(1,2) - (i-1)*yIntervalLeft)/numIntervals; ;

%             plot(coords(k,1),coords(k,2),'bo','MarkerSize', 10);
%             text(coords(k,1),coords(k,2),sprintf('n%d',k));
            k = k + 1;        
        end
    end
    %% Generate 1st order element (4 nodes)
    ele = [];
    k = 1;
    for i = 1:numIntervals

        for j = 1:numIntervals

            ele(k,1) = (numIntervals+1)*(i-1) + j;
            ele(k,2) = (numIntervals+1)*(i-1) + j + 1;
            ele(k,3) = (numIntervals+1)*(i-1) + j + 1 + numIntervals + 1;
            ele(k,4) = (numIntervals+1)*(i-1) + j + numIntervals + 1;
            ele(k,5) = 0;
            ele(k,6) = 0;
            ele(k,7) = 0;
            ele(k,8) = 0;
            ele(k,9) = 0;
%             xElePlot = [coords(ele(k,1),1) coords(ele(k,2),1) coords(ele(k,3),1) coords(ele(k,4),1) coords(ele(k,1),1)];
%             yElePlot = [coords(ele(k,1),2) coords(ele(k,2),2) coords(ele(k,3),2) coords(ele(k,4),2) coords(ele(k,1),2)];
%             plot(xElePlot,yElePlot,'k','LineWidth',1)

            k = k+1;

        end
    end

    %% Upgrade 1st order elements - 4 nodes into 2nd order - 9 nodes
    [numEle,m] = size(ele);
    eleID = 1;
    for i = 1:numIntervals

        for j = 1:numIntervals

        [numNodes,m] = size(coords);

        if i == 1 
            numNodes = numNodes + 1;
            nod5 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1))/2, (coords(ele(eleID,1),2)+coords(ele(eleID,2),2))/2];
            ele(eleID,5) = numNodes;
            coords = [coords; nod5];
        else

            ele(eleID,5) = ele(eleID-numIntervals,7);

        end
        numNodes = numNodes + 1;
        nod6 = [(coords(ele(eleID,2),1)+ coords(ele(eleID,3),1))/2, (coords(ele(eleID,2),2)+coords(ele(eleID,3),2))/2];
        ele(eleID,6) = numNodes;
        coords = [coords; nod6];

        numNodes = numNodes + 1;
        nod7 = [(coords(ele(eleID,3),1)+ coords(ele(eleID,4),1))/2, (coords(ele(eleID,3),2)+coords(ele(eleID,4),2))/2];
        ele(eleID,7) = numNodes;
        coords = [coords; nod7];

        if j == 1
            numNodes = numNodes + 1;
            nod8 = [(coords(ele(eleID,4),1)+ coords(ele(eleID,1),1))/2, (coords(ele(eleID,4),2)+coords(ele(eleID,1),2))/2];
            ele(eleID,8) = numNodes;
            coords = [coords; nod8];
        else
            ele(eleID,8) = ele(eleID-1,6);
        end
        %
        numNodes = numNodes + 1;
        nod9 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1) + coords(ele(eleID,3),1) + coords(ele(eleID,4),1))/4, (coords(ele(eleID,1),2)+ coords(ele(eleID,2),2) + coords(ele(eleID,3),2) + coords(ele(eleID,4),2))/4];    
        ele(eleID,9) = numNodes;
        coords = [coords; nod9];
        %
        eleID = eleID + 1;
        end

    end

    %% Collect nodes lying on distributed-load edge
    nodesOnLineLoad = zeros(numIntervals,3);
    for i = 1:numIntervals

        nodesOnLineLoad(i,:) = [ele(i*numIntervals,2) ele(i*numIntervals,3) ele(i*numIntervals,6)];

    end
    
    %% Collect nodes lying on Dirichlet boundary
    DirNodes = [ele(1,1)  ele(1,4) ele(1,8)];
    for i = 1:(numIntervals-1)

        DirNodes = [DirNodes setdiff([ele(1+ i*numIntervals,1) ele(1+ i*numIntervals,4) ele(1+ i*numIntervals,8)],DirNodes)];

    end
    
    CookMembraneMeshOutput = struct('coords',coords,'ele',ele,'nodesOnLineLoad',nodesOnLineLoad,'DirNodes',DirNodes,'numNodes',numNodes,'numEle',numEle);
end