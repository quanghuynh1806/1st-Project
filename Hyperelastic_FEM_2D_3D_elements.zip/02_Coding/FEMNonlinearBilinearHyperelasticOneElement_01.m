clc
clear all
%2D problem & Material's properties
E = 1000;
nu = 0.25;
lamda = nu*E/((1+nu)*(1-2*nu));
mu = E/(2*(1+nu));
h = 0.1;
nDproblem = 'plane stress';
switch nDproblem
    case 'plane stress'
        gamma = 2*mu/(lamda + 2*mu);
    case 'plane strain'
        gamma = 1; 
end

%Node
coords = [0 0;4 1;4 2;0 2];
xCoordsPlot = [coords(:,1);coords(1,1)];
yCoordsPlot = [coords(:,2);coords(2,2)];
plot(xCoordsPlot,yCoordsPlot)
hold on
%Element
ele = [1 2 3 4];

%External load vector
re = [0 0 50 0 25 0 0 0]';

%Gauss Quadrature
GaussBilinear = [-0.57735 -0.57735 1;-0.57735 0.57735 1;0.57735 -0.57735 1;0.57735 0.57735 1];
GaussBiquadratic = [-0.774597 -0.774597 0.308642;-0.774597 0 0.493827;-0.774597 0.774597 0.308642; 0 -0.774597 0.493827; 0 0 0.790123; 0 0.774597 0.493827; 0.774597 -0.774597 0.308642; 0.774597 0 0.493827; 0.774597 0.774597 0.308642];

[nGaBili, m]=size(GaussBilinear);
[nGaBiQuad, m]=size(GaussBiquadratic);

N1=zeros(4,1);
N2=zeros(4,1);
N3=zeros(4,1);
N4=zeros(4,1);

dN1s=zeros(4,1);
dN2s=zeros(4,1);
dN3s=zeros(4,1);
dN4s=zeros(4,1);

dN1t=zeros(4,1);
dN2t=zeros(4,1);
dN3t=zeros(4,1);
dN4t=zeros(4,1);


%% Preparation of Gauss points & partial derivatives values
for i = 1:nGaBili
    
    % Shape functions evaluated at Gauss point
    N1(i) = 0.25*(GaussBilinear(i,1)-1)*(GaussBilinear(i,2)-1);
    N2(i) = -0.25*(GaussBilinear(i,1)+1)*(GaussBilinear(i,2)-1);
    N3(i) = 0.25*(GaussBilinear(i,1)+1)*(GaussBilinear(i,2)+1);
    N4(i) = -0.25*(GaussBilinear(i,1)-1)*(GaussBilinear(i,2)+1);
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dN1s(i) = 0.25*(GaussBilinear(i,2)-1);
    dN2s(i) = -0.25*(GaussBilinear(i,2)-1);
    dN3s(i) = 0.25*(GaussBilinear(i,2)+1);
    dN4s(i) = -0.25*(GaussBilinear(i,2)+1);
    %
    dN1t(i) = 0.25*(GaussBilinear(i,1)-1);
    dN2t(i) = -0.25*(GaussBilinear(i,1)+1);
    dN3t(i) = 0.25*(GaussBilinear(i,1)+1);
    dN4t(i) = -0.25*(GaussBilinear(i,1)-1);
    
end



%% Later on the loop for assembly of global stiffness matrix is added here

%% Loop over gauss points, calculate and add up the matrices and solve the equation for displacement increment
coordsCur = coords;
%% Later on the the loop for Newton Raphson is added here
conv = 1;
n = 0;
while conv > 0.005
    n=n+1;
%Initialization of the variables
%displacement increment
du = zeros(length(coords)*2,1);
dcoords = [du(1) du(2);du(3) du(4);du(5) du(6);du(7) du(8)];
%mapping from initial to master
Jfem = zeros(2);
%mapping from current to master
JfemCur = zeros(2);
%planar deformation gradient tensor
Fp = zeros(2);
%deformation gradient matrix in FEM style
Fbar = zeros(3,4);
%strain matrix
BT = zeros(4,8);
%current/material stiffness matrix
kc = zeros(8);
%stress/geometric stiffness matrix
ks = zeros(8);
%tangent stiffness matrix
k = zeros(8);
%internal force vector
ri = zeros(8,1);
%internal force vector for residual check
riRes = zeros(8,1);

for i = 1:nGaBili
    
    % Shape functions evaluated at Gauss point i
    N = [N1(i) N2(i) N3(i) N4(i)];
    
    % Partial derivatives of the shape functions evaluated at Gauss point
    dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i)];
    dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i)];
    
    % Initial Configuration's quantities evaluated at Gauss point
    % The FEM mapping
    x0 = N*[coords(1,1) coords(2,1) coords(3,1) coords(4,1)]';
    y0 = N*[coords(1,2) coords(2,2) coords(3,2) coords(4,2)]';
    
    Jfem11 = dNs*[coords(1,1) coords(2,1) coords(3,1) coords(4,1)]';
    Jfem12 = dNt*[coords(1,1) coords(2,1) coords(3,1) coords(4,1)]';
    Jfem21 = dNs*[coords(1,2) coords(2,2) coords(3,2) coords(4,2)]';
    Jfem22 = dNt*[coords(1,2) coords(2,2) coords(3,2) coords(4,2)]';
    
    Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];
    
    detJfem = det(Jfem);
    %Current Configuration's quantites evaluted at Gauss point
    %% For the first iteration, take the values of the initial config for the initial guess of the Current Configuration's quantites

    xCur = N*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    yCur = N*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    
    Jfem11Cur = dNs*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    Jfem12Cur = dNt*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    Jfem21Cur = dNs*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    Jfem22Cur = dNt*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
    detJfemCur = det(JfemCur);
    
    %calculate Fp & Fbar
    Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
    Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
    Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
    Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
    Fp = [Fp11 Fp12;Fp21 Fp22];
    Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
    detFp = det(Fp);
    
    %calculate BT
    dN1x0y0 = [Jfem22*dN1s(i) - Jfem21*dN1t(i);-Jfem12*dN1s(i) + Jfem11*dN1t(i)];
    dN2x0y0 = [Jfem22*dN2s(i) - Jfem21*dN2t(i);-Jfem12*dN2s(i) + Jfem11*dN2t(i)];
    dN3x0y0 = [Jfem22*dN3s(i) - Jfem21*dN3t(i);-Jfem12*dN3s(i) + Jfem11*dN3t(i)];
    dN4x0y0 = [Jfem22*dN4s(i) - Jfem21*dN4t(i);-Jfem12*dN4s(i) + Jfem11*dN4t(i)];
    
    BT = (1/detJfem)*[dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1) 0;dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2) 0;0 dN1x0y0(1) 0 dN2x0y0(1) 0 dN3x0y0(1) 0 dN4x0y0(1);0 dN1x0y0(2) 0 dN2x0y0(2) 0 dN3x0y0(2) 0 dN4x0y0(2)];
    
    %right Cauchy-Green tensor
    c = Fp'*Fp;
    cInv = inv(c);

    %Planar 2nd PK stress tensor
    SHatp = lamda*(log(detFp^gamma))*cInv + mu*(eye(2) - cInv);
    %Planar 2nd PK stress vector
    switch nDproblem
        case 'plane stress'
            Szz = 0;
        case 'plane strain'
            Szz = lamda*(log(detFp)); 
    end
    S = [SHatp(1,1) SHatp(2,2) SHatp(1,2)]';
    %2nd PK stress matrix in FEM style
    Sbar = [SHatp zeros(2);zeros(2) SHatp];

    %Constitutive tensor
    C11 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,1)^2;
    C12 = (2*mu - 2*log(detFp^gamma)*lamda)*cInv(1,2)^2 + lamda*cInv(1,1)*cInv(2,2);
    C21 = C12;
    C22 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(2,2)^2;
    C13 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(1,1);
    C31 = C13;
    C23 = (-2*log(detFp^gamma)*lamda + lamda + 2*mu)*cInv(1,2)*cInv(2,2);
    C32 = C23;
    C33 = (-log(detFp^gamma)*lamda + lamda + mu)*cInv(1,2)^2 + (mu - log(detFp^gamma)*lamda)*cInv(1,1)*cInv(2,2);
    C = [C11 C12 C13; C21 C22 C23;C31 C32 C33];

    %Stiffness matrix and internal loadvector
    kc = kc + h*(BT')*(Fbar')*C*Fbar*BT*detJfem;
    ks = ks + h*(BT')*Sbar*BT*detJfem;
    ri = ri + -h*(BT')*(Fbar')*S*detJfem;
end
k = kc + ks
%
%% Boundary condition
%Fix both vertical & horizontal displacements
DirDofs = [1 2 7 8];

%Apply BCs
allDofs = [1:8];
NonDirDofs = setdiff(allDofs,DirDofs);
%% Simplify tangent stiffness matrix after imposing Dirichlet BCs
for i = 1:length(NonDirDofs)

    for j = i:length(NonDirDofs)
        
        kNonDir(i,j) = k(NonDirDofs(i),NonDirDofs(j));
        kNonDir(j,i) = k(NonDirDofs(i),NonDirDofs(j));
        
    end

end

%% Simplify load vector R after imposing Dirichlet BCs
for i = 1:length(NonDirDofs)
    
    riNonDir(i) = ri(NonDirDofs(i));    
    reNonDir(i) = re(NonDirDofs(i));
end

duNonDir = kNonDir\(reNonDir+riNonDir)';
%% Get back a complete vector du after the iteration
for i = 1:length(NonDirDofs)
    
    du(NonDirDofs(i)) = duNonDir(i);
    
end

dcoords = [du(1) du(2);du(3) du(4);du(5) du(6);du(7) du(8)];
coordsCur = coordsCur + dcoords;
%% Check the residual after the completion of the latest iteration
for i = 1:nGaBili
    
    % Shape functions evaluated at Gauss point i
    N = [N1(i) N2(i) N3(i) N4(i)];
    % Partial derivatives of the shape functions evaluated at Gauss point
    dNs = [dN1s(i) dN2s(i) dN3s(i) dN4s(i)];
    dNt = [dN1t(i) dN2t(i) dN3t(i) dN4t(i)];
    
    Jfem11 = dNs*[coords(1,1) coords(2,1) coords(3,1) coords(4,1)]';
    Jfem12 = dNt*[coords(1,1) coords(2,1) coords(3,1) coords(4,1)]';
    Jfem21 = dNs*[coords(1,2) coords(2,2) coords(3,2) coords(4,2)]';
    Jfem22 = dNt*[coords(1,2) coords(2,2) coords(3,2) coords(4,2)]';
    
    Jfem = [Jfem11 Jfem12;Jfem21 Jfem22];
    
    detJfem = det(Jfem);
    
    %% Update the position of the current configuration
    xCur = N*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    yCur = N*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    
    Jfem11Cur = dNs*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    Jfem12Cur = dNt*[coordsCur(1,1) coordsCur(2,1) coordsCur(3,1) coordsCur(4,1)]';
    Jfem21Cur = dNs*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    Jfem22Cur = dNt*[coordsCur(1,2) coordsCur(2,2) coordsCur(3,2) coordsCur(4,2)]';
    JfemCur = [Jfem11Cur Jfem12Cur;Jfem21Cur Jfem22Cur];
    detJfemCur = det(JfemCur);
    
    
    %calculate Fp & Fbar
    Fp11 = (1/detJfem)*(Jfem22*Jfem11Cur - Jfem21*Jfem12Cur);
    Fp12 = (1/detJfem)*(-Jfem12*Jfem11Cur + Jfem11*Jfem12Cur);
    Fp21 = (1/detJfem)*(Jfem22*Jfem21Cur - Jfem21*Jfem22Cur);
    Fp22 = (1/detJfem)*(-Jfem12*Jfem21Cur + Jfem11*Jfem22Cur);
    Fp = [Fp11 Fp12;Fp21 Fp22];
    Fbar = [Fp11 0 Fp21 0;0 Fp12 0 Fp22;Fp12 Fp11 Fp22 Fp21];
    detFp = det(Fp);
    
    %current thickness
    hCur = h*detFp^(gamma-1);
    
    %left Cauchy Green tensor
    b = Fp*Fp';
    
    %plannar Cauchy stress tensor
    sigmaHatp = (lamda/detFp^gamma)*log(detFp^gamma)*eye(2)+ (mu/detFp^gamma)*(b-eye(2));
    %Planar Cauchy stress vector
    switch nDproblem
        case 'plane stress'
            sigmazz = 0;
        case 'plane strain'
            sigmazz = (lamda/detFp)*(log(detFp)); 
    end
    sigma = [sigmaHatp(1,1) sigmaHatp(2,2) sigmaHatp(1,2)]';
    
    %calculate BLT
    dN1xCuryCur = [Jfem22Cur*dN1s(i) - Jfem21Cur*dN1t(i);-Jfem12Cur*dN1s(i) + Jfem11Cur*dN1t(i)];
    dN2xCuryCur = [Jfem22Cur*dN2s(i) - Jfem21Cur*dN2t(i);-Jfem12Cur*dN2s(i) + Jfem11Cur*dN2t(i)];
    dN3xCuryCur = [Jfem22Cur*dN3s(i) - Jfem21Cur*dN3t(i);-Jfem12Cur*dN3s(i) + Jfem11Cur*dN3t(i)];
    dN4xCuryCur = [Jfem22Cur*dN4s(i) - Jfem21Cur*dN4t(i);-Jfem12Cur*dN4s(i) + Jfem11Cur*dN4t(i)];
    
    BLT = (1/detJfemCur)*[dN1xCuryCur(1) 0 dN2xCuryCur(1) 0 dN3xCuryCur(1) 0 dN4xCuryCur(1) 0;0 dN1xCuryCur(2) 0 dN2xCuryCur(2) 0 dN3xCuryCur(2) 0 dN4xCuryCur(2);dN1xCuryCur(2) dN1xCuryCur(1)  dN2xCuryCur(2) dN2xCuryCur(1)  dN3xCuryCur(2) dN3xCuryCur(1)  dN4xCuryCur(2) dN4xCuryCur(1)];
    
    riRes = riRes + (BLT')*sigma*detJfemCur*hCur;
    
end

%% Simplify load vector R after imposing Dirichlet BCs
for i = 1:length(NonDirDofs)
    
    riResNonDir(i) = riRes(NonDirDofs(i));    

end
normRes = norm(riResNonDir-reNonDir);
conv = (normRes)/(1+norm(reNonDir))
end

conv
coordsCur-coords
coordsCur


xCoordsCurPlot = [coordsCur(:,1);coordsCur(1,1)];
yCoordsCurPlot = [coordsCur(:,2);coordsCur(2,2)];
plot(xCoordsCurPlot,yCoordsCurPlot,'-')
xlim([0 7])
ylim([0 4])