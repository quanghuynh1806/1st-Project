%% Description: executation of the Newton Raphson procedure with multi-load increment steps 
%%              to improve the convergence of the solution
%% Variable description
%% Input
    % matProps: a struct containing the infor about material type (Neo
        % Hookean), Young Modulus, poison ratio
    % AnalysisType: a struct containing the infor about the type of
        % analysis (plane stress/strain) and thickness
    % GeomMeshBcNodes: a struct containing the infor about mesh and nodes
        % applied with boundary condition
    % Load_n_BCs: a struct containing the infor about the global external
        % load vector and nodes applied with Dirichlet BC
    % NewtonSolParam: a struct containing the infor about nonlinear Newton
        % solver's parameters (number of loadsteps, maximum iterations,
        % convergence tolerance)
    % ToComparison: a struct containing the infor about paper's data to be
        % compared with
%% Output
    % conv: the convergence criterion computed at the final load-step
    % coordsCur: a matix with each row containing x & y coordinates of the
            % node in the DEFORMED state. The row index is also the node id
            % this is at the final load step
%% Note:
% For the first iteration of the first load incremet step, if the structure response starts from the stress-free position
% "coordsCurGuess" is literally equal to "coords"

function [conv,coordsCur] = NewtonLoadIncrement(matProps,GeomMeshBcNodes,AnalysisType,Load_n_BCs,NewtonSolParam,ToComparison)

MAT = matProps.MAT;
E = matProps.E;
nu = matProps.nu;
%
ele = GeomMeshBcNodes.ele;
%
nDproblem = AnalysisType.Problem;
h = AnalysisType.Thickness;
%
Re = Load_n_BCs.Re;
DirDofs = Load_n_BCs.DirDofs;
%
numLoadIncr = NewtonSolParam.numLoadIncr;
tol = NewtonSolParam.tol;
maxIter = NewtonSolParam.maxIter;
coordsCurGuess = NewtonSolParam.coordsCurInitialGuess;
%
node4plot = ToComparison.node4plot;
PaperData = ToComparison.PaperData;
%%
%
[numNodes,m] = size(coordsCurGuess);
[numEle,m] = size(ele);
allDofs = [1:numNodes*2];
NonDirDofs = setdiff(allDofs,DirDofs);

lamdaIncr = 1/numLoadIncr;
coordsCur = coordsCurGuess; %initial guess for the first load step
xPlot1 = 0;
xPlot2 = 0;
yPlot = 0;
for loadIncr = 1:numLoadIncr
    
    ReIncr = loadIncr*lamdaIncr*Re;
    conv = 1;
    numIter = 0;
    errPlotX = [];
    errPlotY = [];
    while conv > tol & numIter <= maxIter

        %% Track the number of iteration for termination
        numIter=numIter+1;
        
        %% Assembly & Apply Dirichlet BCs
        [KtNonDir,RiNonDir,ReIncrNonDir,Kt,Ri] = NonlinearBiquadStruc(ReIncr,DirDofs,ele,coordsCurGuess,coordsCur,E,nu,nDproblem,h,MAT); 
        
        %% Update current coordinate after solution
        [coordsCur,du] = solUpdate(coordsCur,KtNonDir,ReIncrNonDir,RiNonDir,NonDirDofs);
        
        %% Calculation of convergence parameter
        [conv,normRes] = NonlinearBiquadStrucResidual(ReIncrNonDir,NonDirDofs,ele,coordsCurGuess,coordsCur,E,nu,nDproblem,h,MAT)
        errPlotX = [errPlotX log(numIter)];
        errPlotY = [errPlotY log(normRes)];
    end

    plot (errPlotX,errPlotY,'-o','LineWidth',3)
    hold on
    
    if numIter > maxIter
    
        disp(sprintf('The loadstep number %d is not converged',loadIncr))
        
    end
    %% For determining and plotting reaction force at Dirichlet BCs
%     uAtLoadStep = reshape((coordsCur - coordsCurGuess).',1,[]);
    ReIncrReact = Kt*du + Ri;
    % Sort out reaction forces at Dirichlet nodes
    ReacForcesAtDiricletNodes = reshape(ReIncrReact(DirDofs),2,[])';
    %
    ReacForceX = sum(ReacForcesAtDiricletNodes(:,1));
    ReacForceY = sum(ReacForcesAtDiricletNodes(:,2));
    ReacForceTotal = sqrt(ReacForceX^2 + ReacForceY^2);
    
    %% Maxmimum vertical displacement is of the 3rd node of the final element
    maxXDispl = abs(coordsCur(node4plot,1) - coordsCurGuess(node4plot,1));
    maxYDispl = abs(coordsCur(node4plot,2) - coordsCurGuess(node4plot,2));
    xPlot1 = [xPlot1 maxXDispl];
    xPlot2 = [xPlot2 maxYDispl];
%     % For Cook's membrane
%     yPlot = [yPlot ReacForceTotal];
    % For Curved Beam
    yPlot = [yPlot abs(ReacForceY)];
    
end

%% Comparison of the reaction force vs displacement curve

figReFoX = figure('Name','Reaction Force vs X displacement');
axesfigReFoX = axes;
plot(axesfigReFoX,xPlot1,yPlot,'bo','LineWidth',3)
xlabel('Displacement [mm]') 
ylabel('Reaction Force [N]')
figReFoY = figure('Name','Reaction Force Y displacement');
axesfigReFoY = axes;
plot(axesfigReFoY,xPlot2,yPlot,'ro','LineWidth',3)
hold on
%
plot(axesfigReFoY,PaperData(1,:),PaperData(2,:),'go','LineWidth',3);
xlabel('Displacement [mm]') 
ylabel('Reaction Force [N]')
xlim
legend(axesfigReFoX,sprintf('Biquadratic-Q9-Quad - Node %d',node4plot),'Location', 'Best')
legend(axesfigReFoY,sprintf('Biquadratic-Q9-Quad - Node %d',node4plot),'RPIM - Mesh free','Location', 'Best')
title(axesfigReFoX,'Reaction Force vs X-displacement');
title(axesfigReFoY,'Reaction Force vs Y-displacement');
end