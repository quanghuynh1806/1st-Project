%% Description: Generation of the equivalent nodal load vector from uniformly distributed load on elements' edge
%% Variable description
%% Input
    % Re: the global external nodal load vector BEFORE the addition of the
        % equivalent nodal load vector
    % qn: normal component of the uniformly distributed load vector on
        % element edge
    % qt: tangential component of the uniformly distributed load vector on
        % element edge
    % AnalysisType: a struct containing the infor about the type of
        % analysis (plane stress/strain) and thickness
    % GeomMeshBcNodes: a struct containing the infor about mesh and nodes
        % applied with boundary condition
%% Output
    % Re: the global external nodal load vector AFTER the addition of the
        % equivalent nodal load vector    

function Re = rqLineLoad(Re,qn,qt,AnalysisType,GeomMeshBcNodes)
h = AnalysisType.Thickness;
nodesOnLineLoad = GeomMeshBcNodes.nodesOnLineLoad;
coords = GeomMeshBcNodes.coords;
%Gauss Quadrature Line
GaussBilinearLine = [-0.57735 1;0.57735 1];
[nGaBiliLine, m] = size(GaussBilinearLine);
%
[numSides,m] = size(nodesOnLineLoad);
for side = 1:numSides
    dofsOnLineLoad = [nodesOnLineLoad(side,1)*2-1 nodesOnLineLoad(side,1)*2 nodesOnLineLoad(side,2)*2-1 nodesOnLineLoad(side,2)*2 nodesOnLineLoad(side,3)*2-1 nodesOnLineLoad(side,3)*2];
    rq_dofsOnLineLoad = zeros(6,1);
    for i = 1:nGaBiliLine
        a = GaussBilinearLine(i,1);
        wa = GaussBilinearLine(i,2);
        Nline = 0.5*[a*(a-1) a*(a+1) 2*(1-a^2)];
        %three nodes on the edge
        nod1 = nodesOnLineLoad(side,1);
        nod2 = nodesOnLineLoad(side,2);
        nod3 = nodesOnLineLoad(side,3);
        xline = Nline*[coords(nod1,1) coords(nod2,1) coords(nod3,1)]';
        yline = Nline*[coords(nod1,2) coords(nod2,2) coords(nod3,2)]';

        dxline = 0.5*((2*a-1)*coords(nod1,1)+(2*a+1)*coords(nod2,1) - 4*a*coords(nod3,1));
        dyline = 0.5*((2*a-1)*coords(nod1,2)+(2*a+1)*coords(nod2,2) - 4*a*coords(nod3,2));
        
        %line Jacopian
        Jc = (dxline^2 + dyline^2)^(1/2);
        nx = dyline/Jc;
        ny = -dxline/Jc;
        qx = nx*qn - ny*qt;
        qy = ny*qn + nx*qt;
        Npt = [Nline(1) 0 Nline(2) 0 Nline(3) 0;0 Nline(1) 0 Nline(2) 0 Nline(3)]';
        rq_dofsOnLineLoad = rq_dofsOnLineLoad + wa*h*Jc*Npt*[qx qy]'; %This is still second order => 2 Gauss points are enough

    end
    %
    %% Complete external load vector
    Re(dofsOnLineLoad) = Re(dofsOnLineLoad)+rq_dofsOnLineLoad;

end