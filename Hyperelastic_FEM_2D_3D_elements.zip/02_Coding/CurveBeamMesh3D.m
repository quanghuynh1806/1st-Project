%% Description: Generation of the mesh from curve beam geometry and related quantites
%% Variable description
%% Input
    % R1: the inner radius
    % R2 : the outer radius
    % h : beam thickness
    % numNodesCir:  number of nodes on the inner and outer circumferences
    % numNodesThic: number of nodes on the radial edges
%% Output
% Mesh related:
    % coords: a matix with each row containing x & y coordinates of the
            % node in the undeformed state. The row index is also the node id
    % ele: a matrix with each row containing the ids of all nodes belonged
            % to the element. The row index is also the element id.
% Other related quantites:
    % nodesOnFaceLoad: all nodes at the LEFT vertical radial FACE are applied with the
                     % distributed load
    % DirNodes: all nodes on the RIGHT horizontal radial FACE are displacement-constrained
    % numNodes: the total number of nodes generated
    % numEle: the total number of elements generated
%% Note:
    % all the variables above are grouped into a struct
    % "CurveBeamMesh3DOutput"
function CurveBeamMesh3DOutput = CurveBeamMesh3D(R1,R2,h,numNodesCir,numNodesThic)
% R1 = 10;
% R2 = 15;
% numNodesCir = 4;
% numNodesThic = 3;
% h = 0.4;
numIntervalCir = numNodesCir-1;
numIntervalThic = numNodesThic-1;
deltaH = (R2-R1)/(numIntervalThic);
deltaAl = (pi/2)/(numIntervalCir);
coords = [];
k = 1;
%% First layer
for i = 0:numIntervalThic
    
    for j = 0:numIntervalCir
        
        coords = [coords; (R1+i*deltaH)*cos(pi/2 - j*deltaAl) (R1+i*deltaH)*sin(pi/2 - j*deltaAl) 0];
        hold on 
        plot(coords(k,1),coords(k,2),'bo','MarkerSize', 10);
        text(coords(k,1),coords(k,2),sprintf('n%d',k));
        k = k + 1; 
    end
    
end

% Generate 1st order element (4 nodes)
ele = [];
k = 1;
for i = 1:numIntervalThic

    for j = 1:numIntervalCir

        ele(k,1)  = (numIntervalCir+1)*(i-1) + j;
        ele(k,2)  = (numIntervalCir+1)*(i-1) + j + 1;
        ele(k,3)  = (numIntervalCir+1)*(i-1) + j + 1 + numIntervalCir + 1;
        ele(k,4)  = (numIntervalCir+1)*(i-1) + j + numIntervalCir + 1;
        ele(k,5)  = 0;
        ele(k,6)  = 0;
        ele(k,7)  = 0;
        ele(k,8)  = 0;
        ele(k,9)  = 0;
        ele(k,10) = 0;
        ele(k,11) = 0; 
        ele(k,12) = 0; 
        ele(k,13) = 0; 
        ele(k,14) = 0; 
        ele(k,15) = 0; 
        ele(k,16) = 0; 
        ele(k,17) = 0; 
        ele(k,18) = 0; 
        ele(k,19) = 0; 
        ele(k,20) = 0;
        ele(k,21) = 0; 		
        ele(k,22) = 0; 
        ele(k,23) = 0; 
        ele(k,24) = 0; 
        ele(k,25) = 0; 
        ele(k,26) = 0; 
        ele(k,27) = 0;
%         xElePlot = [coords(ele(k,1),1) coords(ele(k,2),1) coords(ele(k,3),1) coords(ele(k,4),1) coords(ele(k,1),1)];
%         yElePlot = [coords(ele(k,1),2) coords(ele(k,2),2) coords(ele(k,3),2) coords(ele(k,4),2) coords(ele(k,1),2)];
%         plot(xElePlot,yElePlot,'k','LineWidth',1)

        k = k+1;

    end
end

    %% Upgrade 1st order elements - 4 nodes into 2nd order - 9 nodes
    [numEle,m] = size(ele);
    eleID = 1;
    for i = 1:numIntervalThic

        for j = 1:numIntervalCir

        [numNodes,m] = size(coords);

        if i == 1 
            numNodes = numNodes + 1;
            nod9 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1))/2, (coords(ele(eleID,1),2)+coords(ele(eleID,2),2))/2 0];
            ele(eleID,9) = numNodes;
            coords = [coords; nod9];
        else

            ele(eleID,9) = ele(eleID-numIntervalCir,11);

        end
        numNodes = numNodes + 1;
        nod10 = [(coords(ele(eleID,2),1)+ coords(ele(eleID,3),1))/2, (coords(ele(eleID,2),2)+coords(ele(eleID,3),2))/2 0];
        ele(eleID,10) = numNodes;
        coords = [coords; nod10];

        numNodes = numNodes + 1;
        nod11 = [(coords(ele(eleID,3),1)+ coords(ele(eleID,4),1))/2, (coords(ele(eleID,3),2)+coords(ele(eleID,4),2))/2 0];
        ele(eleID,11) = numNodes;
        coords = [coords; nod11];

        if j == 1
            numNodes = numNodes + 1;
            nod12 = [(coords(ele(eleID,4),1)+ coords(ele(eleID,1),1))/2, (coords(ele(eleID,4),2)+coords(ele(eleID,1),2))/2 0];
            ele(eleID,12) = numNodes;
            coords = [coords; nod12];
        else
            ele(eleID,12) = ele(eleID-1,10);
        end
        %
        numNodes = numNodes + 1;
        nod21 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1) + coords(ele(eleID,3),1) + coords(ele(eleID,4),1))/4, (coords(ele(eleID,1),2)+ coords(ele(eleID,2),2) + coords(ele(eleID,3),2) + coords(ele(eleID,4),2))/4 0];    
        ele(eleID,21) = numNodes;
        coords = [coords; nod21];
        %
        eleID = eleID + 1;
        end

    end

    numNodes1stLayer = length(coords);
%% Second layer
for i = 0:numIntervalThic
    
    for j = 0:numIntervalCir
        
        coords = [coords; (R1+i*deltaH)*cos(pi/2 - j*deltaAl) (R1+i*deltaH)*sin(pi/2 - j*deltaAl) h];
%         plot(coords(k,1),coords(k,2),'bo','MarkerSize', 10);
%         text(coords(k,1),coords(k,2),sprintf('n%d',k));
    end
    
end
k = 1;
for i = 1:numIntervalThic

    for j = 1:numIntervalCir

        ele(k,5)  = numNodes1stLayer + (numIntervalCir+1)*(i-1) + j;
        ele(k,6)  = numNodes1stLayer + (numIntervalCir+1)*(i-1) + j + 1;
        ele(k,7)  = numNodes1stLayer + (numIntervalCir+1)*(i-1) + j + 1 + numIntervalCir + 1;
        ele(k,8)  = numNodes1stLayer + (numIntervalCir+1)*(i-1) + j + numIntervalCir + 1;
        k = k+1;
    end
end

    %% Upgrade 1st order elements - 4 nodes into 2nd order - 9 nodes
    [numEle,m] = size(ele);
    eleID = 1;
    for i = 1:numIntervalThic

        for j = 1:numIntervalCir

        [numNodes,m] = size(coords);

        if i == 1 
            numNodes = numNodes + 1;
            nod13 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1))/2, (coords(ele(eleID,1),2)+coords(ele(eleID,2),2))/2 h];
            ele(eleID,13) = numNodes;
            coords = [coords; nod13];
        else

            ele(eleID,13) = ele(eleID-numIntervalCir,15);

        end
        numNodes = numNodes + 1;
        nod14 = [(coords(ele(eleID,2),1)+ coords(ele(eleID,3),1))/2, (coords(ele(eleID,2),2)+coords(ele(eleID,3),2))/2 h];
        ele(eleID,14) = numNodes;
        coords = [coords; nod14];

        numNodes = numNodes + 1;
        nod15 = [(coords(ele(eleID,3),1)+ coords(ele(eleID,4),1))/2, (coords(ele(eleID,3),2)+coords(ele(eleID,4),2))/2 h];
        ele(eleID,15) = numNodes;
        coords = [coords; nod15];

        if j == 1
            numNodes = numNodes + 1;
            nod16 = [(coords(ele(eleID,4),1)+ coords(ele(eleID,1),1))/2, (coords(ele(eleID,4),2)+coords(ele(eleID,1),2))/2 h];
            ele(eleID,16) = numNodes;
            coords = [coords; nod16];
        else
            ele(eleID,16) = ele(eleID-1,14);
        end
        %
        numNodes = numNodes + 1;
        nod22 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1) + coords(ele(eleID,3),1) + coords(ele(eleID,4),1))/4, (coords(ele(eleID,1),2)+ coords(ele(eleID,2),2) + coords(ele(eleID,3),2) + coords(ele(eleID,4),2))/4 h];    
        ele(eleID,22) = numNodes;
        coords = [coords; nod22];
        %
        eleID = eleID + 1;
        end

    end
    numNodes2ndLayer = length(coords);
%% Third layer
for i = 0:numIntervalThic
    
    for j = 0:numIntervalCir
        
        coords = [coords; (R1+i*deltaH)*cos(pi/2 - j*deltaAl) (R1+i*deltaH)*sin(pi/2 - j*deltaAl) h/2];
%         plot(coords(k,1),coords(k,2),'bo','MarkerSize', 10);
%         text(coords(k,1),coords(k,2),sprintf('n%d',k));
    end
    
end
k = 1;
for i = 1:numIntervalThic

    for j = 1:numIntervalCir

        ele(k,17)  = numNodes2ndLayer + (numIntervalCir+1)*(i-1) + j;
        ele(k,18)  = numNodes2ndLayer + (numIntervalCir+1)*(i-1) + j + 1;
        ele(k,19)  = numNodes2ndLayer + (numIntervalCir+1)*(i-1) + j + 1 + numIntervalCir + 1;
        ele(k,20)  = numNodes2ndLayer + (numIntervalCir+1)*(i-1) + j + numIntervalCir + 1;
        k = k+1;
    end
end

    %% Upgrade 1st order elements - 4 nodes into 2nd order - 9 nodes
    [numEle,m] = size(ele);
    eleID = 1;
    for i = 1:numIntervalThic

        for j = 1:numIntervalCir

        [numNodes,m] = size(coords);

        if i == 1 
            numNodes = numNodes + 1;
            nod23 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1))/2, (coords(ele(eleID,1),2)+coords(ele(eleID,2),2))/2 h/2];
            ele(eleID,23) = numNodes;
            coords = [coords; nod23];
        else

            ele(eleID,23) = ele(eleID-numIntervalCir,25);

        end
        numNodes = numNodes + 1;
        nod24 = [(coords(ele(eleID,2),1)+ coords(ele(eleID,3),1))/2, (coords(ele(eleID,2),2)+coords(ele(eleID,3),2))/2 h/2];
        ele(eleID,24) = numNodes;
        coords = [coords; nod24];

        numNodes = numNodes + 1;
        nod25 = [(coords(ele(eleID,3),1)+ coords(ele(eleID,4),1))/2, (coords(ele(eleID,3),2)+coords(ele(eleID,4),2))/2 h/2];
        ele(eleID,25) = numNodes;
        coords = [coords; nod25];

        if j == 1
            numNodes = numNodes + 1;
            nod26 = [(coords(ele(eleID,4),1)+ coords(ele(eleID,1),1))/2, (coords(ele(eleID,4),2)+coords(ele(eleID,1),2))/2 h/2];
            ele(eleID,26) = numNodes;
            coords = [coords; nod26];
        else
            ele(eleID,26) = ele(eleID-1,24);
        end
        %
        numNodes = numNodes + 1;
        nod27 = [(coords(ele(eleID,1),1)+ coords(ele(eleID,2),1) + coords(ele(eleID,3),1) + coords(ele(eleID,4),1))/4, (coords(ele(eleID,1),2)+ coords(ele(eleID,2),2) + coords(ele(eleID,3),2) + coords(ele(eleID,4),2))/4 h/2];    
        ele(eleID,27) = numNodes;
        coords = [coords; nod27];
        %
        eleID = eleID + 1;
        end

    end
    %% Collect nodes lying on Dirichlet boundary
    DirNodes = [ele(numIntervalCir,2)  ele(numIntervalCir,3) ele(numIntervalCir,7) ele(numIntervalCir,6) ele(numIntervalCir,10) ele(numIntervalCir,19) ele(numIntervalCir,14) ele(numIntervalCir,18) ele(numIntervalCir,24)];
    for i = 1:numIntervalThic

        DirNodes = [DirNodes setdiff([ele(i*numIntervalCir,2)  ele(i*numIntervalCir,3) ele(i*numIntervalCir,7) ele(i*numIntervalCir,6) ele(i*numIntervalCir,10) ele(i*numIntervalCir,19) ele(i*numIntervalCir,14) ele(i*numIntervalCir,18) ele(i*numIntervalCir,24)],DirNodes)];

    end
%     
    %% Collect nodes lying on distributed-load edge
    nodesOnFaceLoad = zeros(numIntervalThic,9);
    for i = 0:(numIntervalThic-1)

        nodesOnFaceLoad(i+1,:) = [ele(1+i*numIntervalCir,1) ele(1+i*numIntervalCir,5) ele(1+i*numIntervalCir,8) ele(1+i*numIntervalCir,4) ele(1+i*numIntervalCir,17) ele(1+i*numIntervalCir,16) ele(1+i*numIntervalCir,20) ele(1+i*numIntervalCir,12) ele(1+i*numIntervalCir,26)];

    end
    CurveBeamMesh3DOutput = struct('coords',coords,'ele',ele,'nodesOnFaceLoad',nodesOnFaceLoad,'DirNodes',DirNodes,'numNodes',numNodes,'numEle',numEle);
end
% [plotLineUndeformed, plotPointUndeformed] = MeshDraw3D(coords,ele,'bo','b')
% CurveBeamMesh3DOutput.DirNodes
% CurveBeamMesh3DOutput.nodesOnLineLoad