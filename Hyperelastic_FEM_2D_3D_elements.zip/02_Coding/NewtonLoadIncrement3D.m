%% Description: executation of the Newton Raphson procedure with multi-load increment steps 
%%              to improve the convergence of the solution
%% Variable description
%% Input
    % matProps: a struct containing the infor about material type (Neo
        % Hookean), Young Modulus, poison ratio
    % AnalysisType: a struct containing the infor about the type of
        % analysis (plane stress/strain) and thickness
    % GeomMeshBcNodes: a struct containing the infor about mesh and nodes
        % applied with boundary condition
    % Load_n_BCs: a struct containing the infor about the global external
        % load vector and nodes applied with Dirichlet BC
    % NewtonSolParam: a struct containing the infor about nonlinear Newton
        % solver's parameters (number of loadsteps, maximum iterations,
        % convergence tolerance)
    % ToComparison: a struct containing the infor about paper's data to be
        % compared with
%% Output
    % conv: the convergence criterion computed at the final load-step
    % coordsCur: a matix with each row containing x & y coordinates of the
            % node in the DEFORMED state. The row index is also the node id
            % this is at the final load step
%% Note:
% For the first iteration of the first load incremet step, if the structure response starts from the stress-free position
% "coordsCurGuess" is literally equal to "coords"

function [conv,coordsCur] = NewtonLoadIncrement3D(matProps,GeomMeshBcNodes,Load_n_BCs,NewtonSolParam,ToComparison)

MAT = matProps.MAT;
E = matProps.E;
nu = matProps.nu;
%
ele = GeomMeshBcNodes.ele;
%
Re = Load_n_BCs.Re;
DirDofs = Load_n_BCs.DirDofs;
%
numLoadIncr = NewtonSolParam.numLoadIncr;
tol = NewtonSolParam.tol;
maxIter = NewtonSolParam.maxIter;
coordsCurGuess = NewtonSolParam.coordsCurInitialGuess;
%
%
node4plot = ToComparison.node4plot;
ComparisonData = ToComparison.ComparisonData;
%%
%
[numNodes,m] = size(coordsCurGuess);
[numEle,m] = size(ele);
allDofs = [1:numNodes*3];
NonDirDofs = setdiff(allDofs,DirDofs);

lamdaIncr = 1/numLoadIncr;
coordsCur = coordsCurGuess; %initial guess for the first load step
% For the plot of reaction vs displacement
xPlotZDispl = 0;
yPlotZDispl = 0;
xPlotYDispl = 0;
yPlotYDispl = 0;
for loadIncr = 1:numLoadIncr
    
    ReIncr = loadIncr*lamdaIncr*Re;
    conv = 1;
    numIter = 0;
    
    while conv > tol & numIter <= maxIter

        %% Track the number of iteration for termination
        numIter=numIter+1;
        
        %% Assembly & Apply Dirichlet BCs
        [KtNonDir,RiNonDir,ReIncrNonDir,Kt,Ri] = Nonlinear27NodeSolidStruc(ReIncr,DirDofs,ele,coordsCurGuess,coordsCur,E,nu,MAT); 
        
        %% Update current coordinate after solution
        [coordsCur,du] = solUpdate3D(coordsCur,KtNonDir,ReIncrNonDir,RiNonDir,NonDirDofs);
        
        %% Calculation of convergence parameter
        [conv,normRes] = Nonlinear27NodeSolidStrucResidual(ReIncrNonDir,NonDirDofs,ele,coordsCurGuess,coordsCur,E,nu,MAT)

    end
    
    if numIter > maxIter
    
        disp(sprintf('The loadstep number %d is not converged',loadIncr))
        
    end
    %% For determining and plotting reaction force at Dirichlet BCs
    
    ReIncrReact = Kt*du + Ri;
    % Sort out reaction forces at Dirichlet nodes
    ReacForcesAtDiricletNodes = reshape(ReIncrReact(DirDofs),3,[])';
    %
    ReacForceX = sum(ReacForcesAtDiricletNodes(:,1));
    ReacForceY = sum(ReacForcesAtDiricletNodes(:,2));
    ReacForceZ = sum(ReacForcesAtDiricletNodes(:,3));
    ReacForceTotal = sqrt(ReacForceX^2 + ReacForceY^2 + ReacForceZ^2);

    %% Maxmimum vertical displacement is of the 3rd node of the final element
    maxXDispl = abs(coordsCur(node4plot,1) - coordsCurGuess(node4plot,1));
    maxYDispl = abs(coordsCur(node4plot,2) - coordsCurGuess(node4plot,2));
    maxZDispl = abs(coordsCur(node4plot,3) - coordsCurGuess(node4plot,3));
    
    xPlotYDispl = [xPlotYDispl maxYDispl];
    yPlotYDispl = [yPlotYDispl abs(ReacForceY)];
    
    xPlotZDispl = [xPlotZDispl maxZDispl];
    yPlotZDispl = [yPlotZDispl abs(ReacForceZ)];
    
end

% Y-comparison
figReFoY = figure('Name','Reaction Force vs Y displacement');
axesfigReFoY = axes;
plot(axesfigReFoY,xPlotYDispl,yPlotYDispl,'ro','LineWidth',3)
xlabel('Displacement [mm]') 
ylabel('Reaction Force [N]')
hold on

% Z-comparison
figReFoZ = figure('Name','Reaction Force vs Z displacement');
axesfigReFoZ = axes;
plot(axesfigReFoZ,xPlotZDispl,yPlotZDispl,'ro','LineWidth',3)
xlabel('Displacement [mm]') 
ylabel('Reaction Force [N]')
hold on

%% Comparison of the reaction force vs displacement curve
plot(axesfigReFoZ,ComparisonData(1,:),ComparisonData(2,:),'go','LineWidth',3);
xlabel('Displacement [mm]') 
ylabel('Reaction Force [N]')
xlim
legend(axesfigReFoZ,sprintf('27-Node-Hexa',node4plot),'Abaqus: 20-Node Hexa','Location', 'Best')
title(axesfigReFoZ,'Reaction Force vs Z-displacement');
end